import { MockProduct, MockStore, MockForecast } from './models';
import { PlanningRecommendation, OperationAction } from '../types';

export function calculatePlanningScore(product: MockProduct) {
  // Simple weighted score out of 100
  const score = (
    product.similarityScore * 0.2 +
    product.lyPlcAcceleration * 0.15 +
    product.weatherFit * 0.25 +
    product.searchTrend * 0.2 +
    product.missedDemandSignal * 0.2
  );

  let decision: 'Increase' | 'Maintain' | 'Reduce' | 'Review' = 'Review';
  let recommendedQuantityChange = 0;

  if (score >= 85) {
    decision = 'Increase'; // Strong Increase
    recommendedQuantityChange = 0.3;
  } else if (score >= 70) {
    decision = 'Increase';
    recommendedQuantityChange = 0.15;
  } else if (score >= 55) {
    decision = 'Increase'; // Selective Increase
    recommendedQuantityChange = 0.05;
  } else if (score >= 40) {
    decision = 'Maintain';
    recommendedQuantityChange = 0;
  } else {
    decision = 'Reduce';
    recommendedQuantityChange = -0.2;
  }

  const rationale = `Score: ${Math.round(score)}. Based on weather (${Math.round(product.weatherFit)}%) & search trends (${Math.round(product.searchTrend)}%).`;

  const confidence = score >= 75 ? 'High' : score >= 55 ? 'Medium' : 'Low';
  const nextAction = decision === 'Increase' ? 'Allocate Budget' : decision === 'Reduce' ? 'Shift Capacity' : 'Monitor Metrics';

  return {
    score,
    decision,
    recommendedQuantity: Math.round(product.baseBuy * (1 + recommendedQuantityChange)),
    rationale,
    weatherImpact: product.weatherFit > 60 ? 12 : product.weatherFit < 40 ? -8 : 0,
    confidence,
    nextAction
  };
}

export function calculateReorderScore(product: MockProduct) {
  let score = 0;
  
  if (product.salesVelocity > 1.2 && product.stockCover < 4) {
    score += 40;
  } else if (product.salesVelocity > 1) {
    score += 20;
  }

  if (product.plcPosition < 0.5 && product.remainingSeason > product.leadTime) {
    score += 30;
  }

  if (product.stockCover < product.leadTime + 2) {
    score += 30;
  }

  let priority: 'High' | 'Medium' | 'Low' = 'Low';
  let actionStr = 'Monitor';
  let recommendedQty = 0;

  if (score >= 80) {
    priority = 'High';
    actionStr = 'Reorder';
    recommendedQty = Math.round(product.baseBuy * 0.1);
  } else if (score >= 50) {
    priority = 'Medium';
    actionStr = 'Replenish';
    recommendedQty = Math.round(product.baseBuy * 0.05);
  } else {
    priority = 'Low';
    actionStr = 'Review';
    recommendedQty = 0;
  }

  return {
    priority,
    action: actionStr,
    recommendedQty
  };
}

export function calculateWeatherImpact(forecast: MockForecast, product: MockProduct) {
  const isSummerProduct = product.productType === 'Fashion' || product.weatherSensitivity > 0.6;
  let impactScore = 0;

  if (forecast.tempShift > 2 && isSummerProduct) {
    impactScore += 20;
  } else if (forecast.tempShift < -1 && isSummerProduct) {
    impactScore -= 10;
  }

  if (forecast.rainProbability > 60) {
    impactScore -= 10;
  }

  return {
    likelyUp: impactScore > 10,
    likelyDown: impactScore < -5,
    recommendedAction: impactScore > 10 ? 'Transfer/Pull Forward' : impactScore < -5 ? 'Markdown/Review' : 'Monitor'
  };
}

export function calculateStoreBenchmark(store: MockStore, product: MockProduct) {
  let alertStr = '';
  let recommendationStr = '';

  if (store.salesIndex < 0.8 && store.stockCover > 6) {
    alertStr = 'High Stock / Low Sales';
    if (store.vmdStatus !== 'Optimized') {
      recommendationStr = 'Update VMD Status';
    } else {
      recommendationStr = 'Targeted Markdown or Transfer';
    }
  } else if (store.salesIndex > 1.2 && store.stockCover < 3) {
    alertStr = 'Fast Seller / Stockout Risk';
    recommendationStr = 'Expedite Replenishment';
  } else {
    alertStr = 'Normal Operations';
    recommendationStr = 'Maintain';
  }

  return {
    alert: alertStr,
    recommendation: recommendationStr,
    isUnderperforming: store.salesIndex < 0.8
  };
}

export function generateOperationActions(products: MockProduct[], stores: MockStore[], forecast: MockForecast[]): OperationAction[] {
  const actions: OperationAction[] = [];
  let idCounter = 1;

  for (const product of products) {
    // 1. Reorder Logic
    const reorder = calculateReorderScore(product);
    const inTwoDays = new Date(Date.now() + 2 * 86400000).toISOString().split('T')[0];
    
    if (reorder.priority === 'High' || reorder.priority === 'Medium') {
      actions.push({
        id: `act-${idCounter++}`,
        type: reorder.action as any,
        cluster: product.cluster,
        region: 'Global',
        priority: reorder.priority,
        description: `Trigger ${reorder.action.toLowerCase()} of ${reorder.recommendedQty} units due to strong sales velocity.`,
        impactMetric: `Protects $${Math.round(reorder.recommendedQty * 45)} revenue`,
        status: 'Pending',
        confidence: reorder.priority === 'High' ? 'High' : 'Medium',
        owner: 'Supply Chain',
        dueDate: inTwoDays
      });
    }

    // 2. Weather Logic
    for (const fc of forecast) {
      const weather = calculateWeatherImpact(fc, product);
      if (weather.likelyUp) {
        actions.push({
          id: `act-${idCounter++}`,
          type: 'Transfer',
          cluster: product.cluster,
          region: fc.region,
          priority: 'High',
          description: `Heatwave forecasted (+${fc.tempShift}°C). ${weather.recommendedAction}.`,
          impactMetric: 'Maximize conversion',
          status: 'Pending',
          confidence: 'High',
          owner: 'Logistics Team',
          dueDate: inTwoDays
        });
      } else if (weather.likelyDown && product.stockCover > 4) {
        actions.push({
          id: `act-${idCounter++}`,
          type: 'Markdown',
          cluster: product.cluster,
          region: fc.region,
          priority: 'Medium',
          description: `Rain/Cool forecast limits wear window. ${weather.recommendedAction}`,
          impactMetric: 'Clearance rate +12%',
          status: 'Pending',
          confidence: 'Medium',
          owner: 'Regional Manager',
          dueDate: inTwoDays
        });
      }
    }

    // 3. Store Benchmarking
    for (const store of stores) {
       const bench = calculateStoreBenchmark(store, product);
       if (bench.isUnderperforming) {
         actions.push({
            id: `act-${idCounter++}`,
            type: bench.recommendation.includes('VMD') ? 'VMD' : 'Benchmark',
            cluster: product.cluster,
            region: store.region,
            priority: 'Medium',
            description: `Store ${store.id} underperforming (${bench.alert}). ${bench.recommendation}.`,
            impactMetric: 'Capital efficiency +4%',
            status: 'Pending',
            confidence: 'Medium',
            owner: 'VMD Operations',
            dueDate: inTwoDays
         });
       } else if (bench.alert === 'Fast Seller / Stockout Risk') {
         actions.push({
            id: `act-${idCounter++}`,
            type: 'Replenish',
            cluster: product.cluster,
            region: store.region,
            priority: 'High',
            description: `Store ${store.id} stockout risk. ${bench.recommendation}.`,
            impactMetric: 'Prevents stockout',
            status: 'Pending',
            confidence: 'High',
            owner: 'Store Manager',
            dueDate: inTwoDays
         });
       }
    }
  }

  // Deduplicate and limit
  return actions.slice(0, 10);
}
