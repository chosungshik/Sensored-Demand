import { PlanningRecommendation, OperationAction } from '../types';

export interface MockProduct {
  id: string;
  cluster: string;
  baseBuy: number;
  similarityScore: number;
  lyPlcAcceleration: number;
  weatherFit: number;
  searchTrend: number;
  missedDemandSignal: number;
  productType: 'Core' | 'Fashion' | 'Basic';
  salesVelocity: number;
  stockCover: number;
  plcPosition: number; // 0-1 (e.g., 0.1 is fresh, 0.9 is end of life)
  remainingSeason: number; // weeks
  leadTime: number; // weeks
  weatherSensitivity: number; // 0-1
}

export interface MockStore {
  id: string;
  region: string;
  salesIndex: number;
  stockCover: number;
  similarStoreGroup: string;
  vmdStatus: 'Optimized' | 'Standard' | 'Outdated';
}

export interface MockForecast {
  region: string;
  tempShift: number;
  rainProbability: number;
}
