import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { fetchProducts, fetchStores, fetchForecasts, fetchPlanningRecommendations, fetchOperationActions, fetchTrendData } from './firestoreService';
import { MockProduct, MockStore, MockForecast } from './lib/models';
import { PlanningRecommendation, OperationAction, TrendData } from './types';

interface DataContextType {
  products: MockProduct[];
  stores: MockStore[];
  forecasts: MockForecast[];
  planningRecommendations: PlanningRecommendation[];
  operationActions: OperationAction[];
  trendData: TrendData[];
  loading: boolean;
  refreshData: () => Promise<void>;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export function DataProvider({ children }: { children: ReactNode }) {
  const [products, setProducts] = useState<MockProduct[]>([]);
  const [stores, setStores] = useState<MockStore[]>([]);
  const [forecasts, setForecasts] = useState<MockForecast[]>([]);
  const [planningRecommendations, setPlanningRecommendations] = useState<PlanningRecommendation[]>([]);
  const [operationActions, setOperationActions] = useState<OperationAction[]>([]);
  const [trendData, setTrendData] = useState<TrendData[]>([]);
  const [loading, setLoading] = useState(true);

  const loadData = async () => {
    setLoading(true);
    try {
      const [
        productsData,
        storesData,
        forecastsData,
        planningRecsData,
        operationActionsData,
        trendDataResult
      ] = await Promise.all([
        fetchProducts(),
        fetchStores(),
        fetchForecasts(),
        fetchPlanningRecommendations(),
        fetchOperationActions(),
        fetchTrendData()
      ]);

      setProducts(productsData);
      setStores(storesData);
      setForecasts(forecastsData);
      setPlanningRecommendations(planningRecsData);
      setOperationActions(operationActionsData);
      setTrendData(trendDataResult);
    } catch (error) {
      console.error("Error loading data:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  return (
    <DataContext.Provider
      value={{
        products,
        stores,
        forecasts,
        planningRecommendations,
        operationActions,
        trendData,
        loading,
        refreshData: loadData,
      }}
    >
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
}
