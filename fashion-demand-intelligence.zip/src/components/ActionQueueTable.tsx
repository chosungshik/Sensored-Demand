import { OperationAction } from '../types';
import { PriorityBadge } from './ui';
import { Play } from 'lucide-react';

interface Props {
  actions: OperationAction[];
  onRowClick?: (action: OperationAction) => void;
}

export function ActionQueueTable({ actions, onRowClick }: Props) {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 flex flex-col overflow-hidden w-full h-full">
      <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between shrink-0">
        <h3 className="text-sm font-bold text-slate-900">Recommended Execution Queue</h3>
        <button className="text-[10px] font-bold text-blue-700 uppercase tracking-widest flex items-center hover:text-blue-900">
          <Play className="w-3 h-3 mr-1" />
          Execute Selected
        </button>
      </div>
      <div className="overflow-x-auto flex-1">
        <table className="w-full text-left whitespace-nowrap">
          <thead className="bg-slate-50 text-[10px] font-bold text-slate-500 uppercase tracking-wider sticky top-0 z-10">
            <tr>
              <th className="px-4 py-2 border-b border-slate-200 w-10">
                <input type="checkbox" className="rounded border-slate-300 text-blue-600 focus:ring-blue-500" />
              </th>
              <th className="px-4 py-2 border-b border-slate-200 w-24">Action</th>
              <th className="px-4 py-2 border-b border-slate-200">Target</th>
              <th className="px-4 py-2 border-b border-slate-200">Confidence</th>
              <th className="px-4 py-2 border-b border-slate-200">Trigger / Reason</th>
              <th className="px-4 py-2 border-b border-slate-200">Expected Impact</th>
            </tr>
          </thead>
          <tbody className="text-xs divide-y divide-slate-100">
            {actions.map((act) => (
              <tr 
                key={act.id} 
                onClick={(e) => {
                  if ((e.target as HTMLElement).tagName !== 'INPUT') {
                    onRowClick?.(act);
                  }
                }}
                className="hover:bg-slate-50 transition-colors cursor-pointer"
              >
                <td className="px-4 py-3">
                  <input type="checkbox" className="rounded border-slate-300 text-blue-600 focus:ring-blue-500" disabled={act.status === 'Executed'} />
                </td>
                <td className="px-4 py-3 font-semibold text-slate-900 bg-blue-50/30">
                  {act.type}
                </td>
                <td className="px-4 py-3">
                  <div className="font-semibold text-slate-900">{act.cluster}</div>
                  <div className="text-[10px] text-slate-500 uppercase tracking-wider mt-0.5">{act.region}</div>
                </td>
                <td className="px-4 py-3">
                  <span className={`font-bold ${act.confidence === 'High' ? 'text-emerald-600' : 'text-amber-600'}`}>
                    {act.confidence}
                  </span>
                </td>
                <td className="px-4 py-3 text-slate-500 max-w-xs truncate" title={act.description}>{act.description}</td>
                <td className="px-4 py-3 font-bold text-blue-800">{act.impactMetric}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
