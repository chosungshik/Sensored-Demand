import { useState } from 'react';
import { X, CheckCircle2, TrendingUp, CloudRain, AlertTriangle, BarChart, Clock, Box, Map, Activity } from 'lucide-react';
import { PlanningRecommendation } from '../types';
import { DecisionBadge } from './ui';
import { LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid, ResponsiveContainer, ReferenceLine } from 'recharts';

interface Props {
  recommendation: PlanningRecommendation | null;
  onClose: () => void;
}

const TABS = ['Overview', 'PLC & Sales', 'Similar Items', 'Weather', 'Regions', 'Inventory'] as const;
type TabType = typeof TABS[number];

const SIMILAR_ITEMS = [
  { year: 2024, name: 'Light Nylon Jacket', visual: '88%', material: '92%', price: '95%', outcome: 'Stockout W6', note: 'Under-planned, missed upside' },
  { year: 2024, name: 'Rain Shell Shirt Jacket', visual: '75%', material: '85%', price: '90%', outcome: 'MD 15%', note: 'Overbought in South' },
  { year: 2023, name: 'Compact Windbreaker', visual: '82%', material: '70%', price: '85%', outcome: 'Clean clearance', note: 'Good baseline' },
  { year: 2023, name: 'Thin Utility Jacket', visual: '65%', material: '75%', price: '80%', outcome: 'High return rate', note: 'Fit issue early season' },
];

const PLC_DATA = Array.from({ length: 12 }).map((_, i) => ({
  week: `W${i + 1}`,
  current: i < 5 ? 10 + i * 8 + (Math.random() * 4) : null,
  baseline: 15 + i * 6.5,
  sim2024: 12 + i * 7,
  sim2023: 14 + i * 6,
  forecast: i >= 4 ? 10 + 4 * 7.5 + (i - 4) * 8.5 : null,
}));

const WEATHER_IMPACTS = [
  { region: 'Seville', forecast: '+4.2°C dry', impact: '-32%', rec: 'Reduce allocation' },
  { region: 'Madrid', forecast: '+2.1°C dry', impact: '-18%', rec: 'Reduce exposure' },
  { region: 'Valencia', forecast: 'warm + light rain', impact: '-5%', rec: 'Maintain' },
  { region: 'Barcelona', forecast: 'normal', impact: '+3%', rec: 'Maintain' },
  { region: 'Bilbao', forecast: 'rain + cooler', impact: '+21%', rec: 'Maintain or selective increase' },
];

const REGIONAL_DECISIONS = [
  { region: 'Seville', baseline: 2100, rec: 1300, change: -800, reason: 'heat lowers jacket demand', action: 'reduce early allocation' },
  { region: 'Madrid', baseline: 1800, rec: 1400, change: -400, reason: 'dry warm forecast', action: 'reduce exposure' },
  { region: 'Valencia', baseline: 1600, rec: 1500, change: -100, reason: 'light rain offsets heat', action: 'maintain' },
  { region: 'Barcelona', baseline: 1900, rec: 1900, change: 0, reason: 'stable tourist demand', action: 'maintain' },
  { region: 'Bilbao', baseline: 1200, rec: 1500, change: 300, reason: 'rain and cooler weather', action: 'maintain or increase' },
];

const INVENTORY_COVERS = [
  { region: 'Seville', stock: 1850, velocity: 225, woc: 8.2, risk: 'overstock risk', textClass: 'text-rose-600', rec: 'reduce replenishment' },
  { region: 'Madrid', stock: 1420, velocity: 220, woc: 6.4, risk: 'slightly high', textClass: 'text-amber-600', rec: 'reduce exposure' },
  { region: 'Valencia', stock: 860, velocity: 290, woc: 3.0, risk: 'healthy', textClass: 'text-emerald-600', rec: 'maintain' },
  { region: 'Barcelona', stock: 940, velocity: 310, woc: 3.0, risk: 'healthy', textClass: 'text-emerald-600', rec: 'maintain' },
  { region: 'Bilbao', stock: 520, velocity: 250, woc: 2.1, risk: 'watch', textClass: 'text-amber-600', rec: 'selective replenishment' },
];

function getSpecificActionLanguage(action: string) {
  if (action === 'Reduce') return "Reduce total buy, but maintain northern allocation";
  if (action === 'Increase') return "Increase buy and pull forward allocation in warm regions";
  return "Maintain total buy, shift presentation timing by +1 week";
}

export function ProductDetailDrawer({ recommendation, onClose }: Props) {
  const [activeTab, setActiveTab] = useState<TabType>('Overview');

  if (!recommendation) return null;

  const diffUnits = recommendation.recommendedBuy - recommendation.baselineBuy;
  const diffPct = ((diffUnits / recommendation.baselineBuy) * 100).toFixed(1);
  const primaryActionText = getSpecificActionLanguage(recommendation.action);

  return (
    <>
      <div 
        className="fixed inset-0 bg-slate-900/40 backdrop-blur-sm z-40 animate-in fade-in transition-opacity" 
        onClick={onClose}
      />
      
      <div className="fixed top-0 right-0 h-full w-[95vw] md:w-[850px] lg:w-[1000px] bg-white shadow-2xl z-50 flex flex-col animate-in slide-in-from-right duration-300">
        {/* Header */}
        <div className="px-6 py-5 border-b border-slate-200 bg-slate-50 flex items-center justify-between shrink-0">
          <div>
            <p className="text-[10px] items-center flex font-bold text-slate-500 uppercase tracking-widest mb-1.5">
              <Box className="w-3.5 h-3.5 mr-1.5" /> Product Decision Detail
            </p>
            <h3 className="text-2xl font-bold text-slate-900 leading-none">{recommendation.cluster}</h3>
          </div>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-slate-700 bg-white border border-slate-200 shadow-sm rounded-lg hover:bg-slate-100 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Top Summary */}
        <div className="px-6 py-5 bg-white border-b border-slate-100 shrink-0">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
             <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-2">Base vs Recommended</p>
                <div className="flex items-baseline space-x-2">
                   <span className="text-slate-400 font-medium line-through text-lg">{recommendation.baselineBuy.toLocaleString()}</span>
                   <span className="text-2xl font-black text-slate-900">{recommendation.recommendedBuy.toLocaleString()}</span>
                </div>
                <p className={`text-xs font-bold mt-1 ${diffUnits > 0 ? 'text-emerald-600' : diffUnits < 0 ? 'text-rose-600' : 'text-slate-500'}`}>
                  {diffUnits > 0 ? '+' : ''}{diffUnits.toLocaleString()} units ({diffPct}%)
                </p>
             </div>
             <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 flex flex-col justify-center">
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-2">Recommendation</p>
                <div className="mb-2 w-fit">
                  <DecisionBadge action={recommendation.action} />
                </div>
                <p className="text-[11px] text-slate-700 font-medium leading-relaxed">{primaryActionText}</p>
             </div>
             <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 flex flex-col justify-center">
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-2">Confidence</p>
                <div className="flex items-center space-x-2">
                   <span className="text-lg font-black text-slate-900">{recommendation.confidence}</span>
                   <span className="text-xs font-bold text-slate-400 bg-slate-200 px-1.5 py-0.5 rounded">88%</span>
                </div>
             </div>
             <div className="bg-slate-50 p-4 rounded-xl border border-slate-100 flex flex-col justify-center">
                <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-2">Decision Type</p>
                <p className="text-sm font-bold text-slate-900 flex items-center">
                  <Activity className="w-4 h-4 mr-2 text-blue-500" /> Weather Event Adjustment
                </p>
             </div>
          </div>
        </div>

        {/* Tabs */}
        <div className="px-6 border-b border-slate-200 bg-white flex space-x-8 shrink-0 overflow-x-auto">
          {TABS.map(tab => (
            <button 
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`py-4 text-sm font-bold border-b-2 whitespace-nowrap transition-colors ${
                activeTab === tab 
                  ? 'border-blue-600 text-blue-700' 
                  : 'border-transparent text-slate-500 hover:text-slate-800'
              }`}
            >
              {tab}
            </button>
          ))}
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto p-6 bg-slate-50/50 relative">
          
          {activeTab === 'Overview' && (
            <div className="space-y-6">
              <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
                 <h4 className="text-base font-black text-slate-900 mb-4 flex items-center">
                    <CheckCircle2 className="w-5 h-5 text-emerald-500 mr-2" />
                    Final AI Recommendation
                 </h4>
                 <p className="text-sm text-slate-700 font-medium leading-relaxed mb-6">
                   {recommendation.rationale} {primaryActionText}. This adjusts for immediate term weather volatility while securing margin in historically reliable clusters.
                 </p>
                 <ul className="space-y-4 mb-8">
                   <li className="flex items-start">
                     <div className="w-1.5 h-1.5 rounded-full bg-blue-500 mt-2 mr-3 shrink-0" />
                     <p className="text-sm text-slate-700">Similarity models show high elasticity to early season stockouts based on 2024 performance of lightweight synthetics.</p>
                   </li>
                   <li className="flex items-start">
                     <div className="w-1.5 h-1.5 rounded-full bg-blue-500 mt-2 mr-3 shrink-0" />
                     <p className="text-sm text-slate-700">Weather data predicts a +3°C heatwave accelerating summer transition by 14 days in southern EU markets.</p>
                   </li>
                   <li className="flex items-start">
                     <div className="w-1.5 h-1.5 rounded-full bg-blue-500 mt-2 mr-3 shrink-0" />
                     <p className="text-sm text-slate-700">Current baseline allocation leaves northern stores under-serviced during their peak rain season in late August.</p>
                   </li>
                 </ul>

                 <div className="bg-slate-50 border border-slate-100 rounded-lg p-4">
                    <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-1">Decision Impact Estimate</p>
                    <p className="text-sm font-bold text-slate-900">+14.2% Sell-through | -$420k Weather Markdown Risk</p>
                 </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                 <button className="px-4 py-3 bg-blue-900 text-white shadow-sm rounded-lg text-sm font-bold transition-colors hover:bg-blue-800">
                    Accept Recommendation
                 </button>
                 <button className="px-4 py-3 bg-white border border-slate-200 shadow-sm rounded-lg text-sm font-bold text-slate-700 hover:bg-slate-50 transition-colors">
                    Adjust by Region
                 </button>
                 <button className="px-4 py-3 bg-white border border-slate-200 shadow-sm rounded-lg text-sm font-bold text-slate-700 hover:bg-slate-50 transition-colors">
                    Review Later
                 </button>
                 <button className="px-4 py-3 bg-white border border-slate-200 shadow-sm rounded-lg text-sm font-bold text-rose-600 hover:bg-rose-50 transition-colors">
                    Exclude / Ignore
                 </button>
              </div>
            </div>
          )}

          {activeTab === 'PLC & Sales' && (
             <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm h-full flex flex-col">
                <h4 className="text-sm font-bold text-slate-900 uppercase tracking-wide mb-6">Product Life Cycle & Cumulative Sell-Through</h4>
                <div className="flex-1 min-h-[350px] w-full relative">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={PLC_DATA} margin={{ top: 10, right: 20, left: -20, bottom: 5 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                      <XAxis dataKey="week" axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#64748b' }} dy={10} />
                      <YAxis axisLine={false} tickLine={false} tick={{ fontSize: 10, fill: '#64748b' }} tickFormatter={val => `${val}%`} />
                      <Tooltip 
                        contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                        formatter={(value: number) => [`${value.toFixed(1)}%`, '']}
                      />
                      <ReferenceLine x="W5" stroke="#ef4444" strokeDasharray="3 3" label={{ position: 'top', value: 'Warm shift begins', fill: '#ef4444', fontSize: 10, fontWeight: 700 }} />
                      <ReferenceLine x="W8" stroke="#f59e0b" strokeDasharray="3 3" label={{ position: 'bottom', value: 'Risk window', fill: '#f59e0b', fontSize: 10, fontWeight: 700 }} />
                      
                      <Line type="monotone" dataKey="sim2023" name="2023 Avg" stroke="#cbd5e1" strokeWidth={2} dot={false} strokeDasharray="5 5" />
                      <Line type="monotone" dataKey="sim2024" name="2024 Avg" stroke="#94a3b8" strokeWidth={2} dot={false} strokeDasharray="5 5" />
                      <Line type="monotone" dataKey="baseline" name="25 Base Plan" stroke="#3b82f6" strokeWidth={2} dot={false} />
                      <Line type="monotone" dataKey="current" name="25 Actuals" stroke="#0f172a" strokeWidth={3} dot={{ r: 4 }} />
                      <Line type="monotone" dataKey="forecast" name="25 Forecast" stroke="#0f172a" strokeWidth={2} strokeDasharray="3 3" dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
                <div className="mt-6 p-4 bg-slate-50 rounded-lg border border-slate-100 flex items-start">
                  <Activity className="w-5 h-5 text-blue-500 mr-3 mt-0.5" />
                  <p className="text-sm font-medium text-slate-700">
                    Current sales are below the baseline PLC in southern regions, but northern rainy regions remain stable. The forecasted trajectory indicates a stockout point around Week 8 if unadjusted.
                  </p>
                </div>
             </div>
          )}

          {activeTab === 'Similar Items' && (
             <div className="space-y-6">
                <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                  {[
                    { label: 'Visual', val: '88%' },
                    { label: 'Material', val: '92%' },
                    { label: 'Text', val: '81%' },
                    { label: 'Price-band', val: '95%' },
                    { label: 'Customer-perc.', val: '85%' },
                  ].map(score => (
                    <div key={score.label} className="bg-white border border-slate-200 rounded-lg p-3 text-center shadow-sm">
                      <p className="text-[10px] font-bold uppercase tracking-wider text-slate-500 mb-1">{score.label}</p>
                      <p className="text-xl font-black text-slate-900">{score.val}</p>
                    </div>
                  ))}
                </div>

                <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
                   <table className="w-full text-left border-collapse">
                      <thead>
                         <tr className="bg-slate-50 border-b border-slate-200">
                            <th className="py-3 px-4 text-[10px] font-bold uppercase tracking-wider text-slate-500">Year</th>
                            <th className="py-3 px-4 text-[10px] font-bold uppercase tracking-wider text-slate-500">Similar Product</th>
                            <th className="py-3 px-4 text-[10px] font-bold uppercase tracking-wider text-slate-500">Summary Scores</th>
                            <th className="py-3 px-4 text-[10px] font-bold uppercase tracking-wider text-slate-500">Sales Outcome</th>
                            <th className="py-3 px-4 text-[10px] font-bold uppercase tracking-wider text-slate-500">Note</th>
                         </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {SIMILAR_ITEMS.map((item, i) => (
                          <tr key={i} className="hover:bg-slate-50/50 transition-colors">
                            <td className="py-3 px-4 text-sm font-bold text-slate-900">{item.year}</td>
                            <td className="py-3 px-4 text-sm font-medium text-slate-700">{item.name}</td>
                            <td className="py-3 px-4">
                               <div className="flex gap-2">
                                  <span className="text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded font-medium border border-slate-200">V:{item.visual}</span>
                                  <span className="text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded font-medium border border-slate-200">M:{item.material}</span>
                                  <span className="text-[10px] bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded font-medium border border-slate-200">P:{item.price}</span>
                               </div>
                            </td>
                            <td className="py-3 px-4"><span className="text-xs font-bold text-slate-900">{item.outcome}</span></td>
                            <td className="py-3 px-4 text-xs text-slate-500">{item.note}</td>
                          </tr>
                        ))}
                      </tbody>
                   </table>
                </div>
             </div>
          )}

          {activeTab === 'Weather' && (
             <div className="space-y-6">
                <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm">
                   <h4 className="text-sm font-bold text-slate-900 uppercase tracking-wide mb-4">Weather-Adjusted Demand Analysis</h4>
                   <ul className="space-y-3">
                     <li className="flex items-center text-sm font-medium text-slate-700">
                        <TrendingUp className="w-4 h-4 text-emerald-500 mr-2" /> Demand increases when temperature is below 22°C
                     </li>
                     <li className="flex items-center text-sm font-medium text-slate-700">
                        <TrendingUp className="w-4 h-4 text-emerald-500 mr-2" /> Demand increases when rain probability is above 35%
                     </li>
                     <li className="flex items-center text-sm font-medium text-slate-700">
                        <TrendingUp className="w-4 h-4 text-rose-500 mr-2 rotate-180" /> Demand decreases when temperature exceeds 27°C for 3 consecutive days
                     </li>
                     <li className="flex items-center text-sm font-medium text-slate-700">
                        <TrendingUp className="w-4 h-4 text-rose-500 mr-2 rotate-180" /> Demand decreases when dry warm weather continues
                     </li>
                   </ul>
                </div>

                <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
                   <table className="w-full text-left border-collapse">
                      <thead>
                         <tr className="bg-slate-50 border-b border-slate-200">
                            <th className="py-3 px-4 text-[10px] font-bold uppercase tracking-wider text-slate-500">Region</th>
                            <th className="py-3 px-4 text-[10px] font-bold uppercase tracking-wider text-slate-500">Forecast</th>
                            <th className="py-3 px-4 text-[10px] font-bold uppercase tracking-wider text-slate-500">Demand Impact</th>
                            <th className="py-3 px-4 text-[10px] font-bold uppercase tracking-wider text-slate-500">Recommendation</th>
                         </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100">
                        {WEATHER_IMPACTS.map((item, i) => (
                          <tr key={i} className="hover:bg-slate-50/50 transition-colors">
                            <td className="py-3 px-4 text-sm font-bold text-slate-900 flex items-center">
                              <Map className="w-3.5 h-3.5 mr-2 text-slate-400" /> {item.region}
                            </td>
                            <td className="py-3 px-4 text-sm font-medium text-slate-700">{item.forecast}</td>
                            <td className={`py-3 px-4 text-sm font-bold ${item.impact.startsWith('-') ? 'text-rose-600' : 'text-emerald-600'}`}>{item.impact}</td>
                            <td className="py-3 px-4 text-xs font-bold text-slate-600 uppercase tracking-wide">{item.rec}</td>
                          </tr>
                        ))}
                      </tbody>
                   </table>
                </div>
             </div>
          )}

          {activeTab === 'Regions' && (
             <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
                 <table className="w-full text-left border-collapse">
                    <thead>
                       <tr className="bg-slate-50 border-b border-slate-200">
                          <th className="py-3 px-4 text-[10px] font-bold uppercase tracking-wider text-slate-500">Region</th>
                          <th className="py-3 px-4 text-[10px] font-bold uppercase tracking-wider text-slate-500 text-right">Base Alloc.</th>
                          <th className="py-3 px-4 text-[10px] font-bold uppercase tracking-wider text-slate-500 text-right">Rec. Alloc.</th>
                          <th className="py-3 px-4 text-[10px] font-bold uppercase tracking-wider text-slate-500 text-right">Change</th>
                          <th className="py-3 px-4 text-[10px] font-bold uppercase tracking-wider text-slate-500">Reason</th>
                          <th className="py-3 px-4 text-[10px] font-bold uppercase tracking-wider text-slate-500">Action</th>
                       </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {REGIONAL_DECISIONS.map((item, i) => (
                        <tr key={i} className="hover:bg-slate-50/50 transition-colors">
                          <td className="py-4 px-4 text-sm font-bold text-slate-900">{item.region}</td>
                          <td className="py-4 px-4 text-sm font-medium text-slate-500 text-right line-through">{item.baseline.toLocaleString()}</td>
                          <td className="py-4 px-4 text-sm font-bold text-slate-900 text-right">{item.rec.toLocaleString()}</td>
                          <td className={`py-4 px-4 text-sm font-bold text-right ${item.change < 0 ? 'text-rose-600' : item.change > 0 ? 'text-emerald-600' : 'text-slate-500'}`}>
                            {item.change > 0 ? '+' : ''}{item.change.toLocaleString()}
                          </td>
                          <td className="py-4 px-4 text-xs font-medium text-slate-600">{item.reason}</td>
                          <td className="py-4 px-4 text-xs font-bold text-slate-700 uppercase tracking-wider">{item.action}</td>
                        </tr>
                      ))}
                    </tbody>
                 </table>
             </div>
          )}

          {activeTab === 'Inventory' && (
             <div className="bg-white border border-slate-200 rounded-xl overflow-hidden shadow-sm">
                 <table className="w-full text-left border-collapse">
                    <thead>
                       <tr className="bg-slate-50 border-b border-slate-200">
                          <th className="py-3 px-4 text-[10px] font-bold uppercase tracking-wider text-slate-500">Region</th>
                          <th className="py-3 px-4 text-[10px] font-bold uppercase tracking-wider text-slate-500 text-right">Current Stock</th>
                          <th className="py-3 px-4 text-[10px] font-bold uppercase tracking-wider text-slate-500 text-right">Wkly Velocity</th>
                          <th className="py-3 px-4 text-[10px] font-bold uppercase tracking-wider text-slate-500 text-right">Weeks Cover</th>
                          <th className="py-3 px-4 text-[10px] font-bold uppercase tracking-wider text-slate-500">Risk</th>
                          <th className="py-3 px-4 text-[10px] font-bold uppercase tracking-wider text-slate-500">Recommendation</th>
                       </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {INVENTORY_COVERS.map((item, i) => (
                        <tr key={i} className="hover:bg-slate-50/50 transition-colors">
                          <td className="py-4 px-4 text-sm font-bold text-slate-900">{item.region}</td>
                          <td className="py-4 px-4 text-sm font-bold text-slate-700 text-right">{item.stock.toLocaleString()}</td>
                          <td className="py-4 px-4 text-sm font-medium text-slate-600 text-right">{item.velocity}</td>
                          <td className="py-4 px-4 text-sm font-black text-slate-900 text-right">{item.woc.toFixed(1)}w</td>
                          <td className={`py-4 px-4 text-xs font-bold uppercase tracking-wider ${item.textClass}`}>{item.risk}</td>
                          <td className="py-4 px-4 text-xs font-medium text-slate-700">{item.rec}</td>
                        </tr>
                      ))}
                    </tbody>
                 </table>
             </div>
          )}

        </div>
      </div>
    </>
  );
}

