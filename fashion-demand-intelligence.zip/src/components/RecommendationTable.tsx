import { PlanningRecommendation } from '../types';
import { DecisionBadge } from './ui';

interface Props {
  recommendations: PlanningRecommendation[];
  onRowClick?: (rec: PlanningRecommendation) => void;
}

export function RecommendationTable({ recommendations, onRowClick }: Props) {
  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 flex flex-col overflow-hidden w-full h-full">
      <div className="px-4 py-3 border-b border-slate-100 flex items-center justify-between shrink-0">
        <h3 className="text-sm font-bold text-slate-900">Recommended Allocations</h3>
        <div className="flex space-x-3">
          <button className="text-[10px] font-bold text-blue-700 uppercase tracking-widest hover:text-blue-900">Export CSV</button>
          <button className="text-[10px] font-bold text-blue-700 uppercase tracking-widest hover:text-blue-900">Filter Group</button>
        </div>
      </div>
      <div className="overflow-x-auto flex-1">
        <table className="w-full text-left whitespace-nowrap">
          <thead className="bg-slate-50 text-[10px] font-bold text-slate-500 uppercase tracking-wider sticky top-0 z-10">
            <tr>
              <th className="px-4 py-2 border-b border-slate-200 w-24">Decision</th>
              <th className="px-4 py-2 border-b border-slate-200">Product Cluster</th>
              <th className="px-4 py-2 border-b border-slate-200">AI Confidence</th>
              <th className="px-4 py-2 border-b border-slate-200">Primary Reason</th>
              <th className="px-4 py-2 border-b border-slate-200 text-right">Rec. Buy</th>
              <th className="px-4 py-2 border-b border-slate-200">Next Action</th>
            </tr>
          </thead>
          <tbody className="text-xs divide-y divide-slate-100">
            {recommendations.map((rec) => (
              <tr 
                key={rec.id} 
                onClick={() => onRowClick?.(rec)}
                className="hover:bg-slate-50 transition-colors cursor-pointer"
              >
                <td className="px-4 py-3">
                  <DecisionBadge action={rec.action} />
                </td>
                <td className="px-4 py-3 font-semibold text-slate-900">{rec.cluster}</td>
                <td className="px-4 py-3">
                  <span className={`font-bold ${rec.confidence === 'High' ? 'text-emerald-600' : rec.confidence === 'Medium' ? 'text-amber-600' : 'text-slate-500'}`}>
                    {rec.confidence}
                  </span>
                </td>
                <td className="px-4 py-3 text-slate-500 italic max-w-xs truncate" title={rec.rationale}>
                  {rec.rationale}
                </td>
                <td className="px-4 py-3 text-right font-bold text-slate-900">{rec.recommendedBuy.toLocaleString()}</td>
                <td className="px-4 py-3">
                  <span className="text-[10px] uppercase font-bold text-blue-700 tracking-wider">
                    {rec.nextAction}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
