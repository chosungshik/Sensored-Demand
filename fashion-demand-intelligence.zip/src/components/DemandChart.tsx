import { CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis, Legend } from 'recharts';
import { useData } from '../DataContext';

export function DemandChart() {
  const { trendData } = useData();
  
  return (
    <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-4 flex flex-col h-full w-full">
      <div className="mb-4 pb-3 border-b border-slate-100 flex items-center justify-between">
        <div>
           <h3 className="text-sm font-bold text-slate-900">Weather-adjusted Demand</h3>
           <p className="text-[10px] text-slate-500 uppercase tracking-tighter mt-0.5">Pre-season vs Localized Weather Shift</p>
        </div>
        <div className="flex space-x-2">
           <span className="flex items-center text-[10px] font-bold text-slate-500 uppercase"><span className="w-2 h-2 rounded bg-slate-300 mr-1.5"/> Base Plan</span>
           <span className="flex items-center text-[10px] font-bold text-slate-900 uppercase"><span className="w-2 h-2 rounded bg-blue-800 mr-1.5"/> AI Forecast</span>
        </div>
      </div>
      <div className="flex-1 w-full min-h-[220px]">
        <ResponsiveContainer width="100%" height="100%">
          <LineChart data={trendData} margin={{ top: 5, right: 10, left: -20, bottom: 5 }}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
            <XAxis dataKey="month" axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 10, fontWeight: 600 }} dy={10} />
            <YAxis axisLine={false} tickLine={false} tick={{ fill: '#94a3b8', fontSize: 10, fontWeight: 600 }} dx={-10} tickFormatter={(val) => `${val / 1000}k`} />
            <Tooltip
              contentStyle={{ borderRadius: '8px', border: '1px solid #e2e8f0', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.05)', fontSize: '11px', fontWeight: 600 }}
              itemStyle={{ padding: 0 }}
              labelStyle={{ color: '#64748b', marginBottom: '4px', textTransform: 'uppercase', fontSize: '10px', letterSpacing: '0.05em' }}
            />
            <Line type="monotone" name="Baseline Plan" dataKey="baseline" stroke="#cbd5e1" strokeWidth={2} dot={false} strokeDasharray="4 4" />
            <Line type="monotone" name="Forecast (Adj)" dataKey="projected" stroke="#1e3a8a" strokeWidth={2} dot={{ r: 3, fill: '#1e3a8a', strokeWidth: 0 }} activeDot={{ r: 5, fill: '#1e40af' }} />
          </LineChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
