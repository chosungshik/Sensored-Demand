import { ArrowUpRight, ArrowDownRight, Minus } from 'lucide-react';

export function MetricCard({ title, value, change, trend = 'flat' }: { title: string, value: string | number, change?: string, trend?: 'up' | 'down' | 'flat' }) {
  const trendColor = trend === 'up' ? 'text-emerald-600' : trend === 'down' ? 'text-rose-600' : 'text-slate-500';
  
  return (
    <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex flex-col">
      <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">{title}</p>
      <div className="flex items-baseline space-x-2 mt-auto">
        <span className="text-2xl font-bold text-slate-900">{value}</span>
        {change && (
          <div className={`flex items-center text-xs font-bold ${trendColor}`}>
            {trend === 'up' && <ArrowUpRight className="w-3 h-3 mr-0.5" />}
            {trend === 'down' && <ArrowDownRight className="w-3 h-3 mr-0.5" />}
            {trend === 'flat' && <Minus className="w-3 h-3 mr-0.5" />}
            <span>{change}</span>
          </div>
        )}
      </div>
    </div>
  );
}

export function DecisionBadge({ action }: { action: 'Increase' | 'Maintain' | 'Reduce' | 'Review' }) {
  const styles = {
    Increase: 'bg-emerald-100 text-emerald-800',
    Maintain: 'bg-slate-100 text-slate-800',
    Reduce: 'bg-rose-100 text-rose-800',
    Review: 'bg-amber-100 text-amber-800'
  };

  return (
    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wide ${styles[action]}`}>
      {action}
    </span>
  );
}

export function PriorityBadge({ priority }: { priority: 'High' | 'Medium' | 'Low' }) {
  const styles = {
    High: 'bg-rose-100 text-rose-800',
    Medium: 'bg-amber-100 text-amber-800',
    Low: 'bg-slate-100 text-slate-800'
  };

  return (
    <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wide ${styles[priority]}`}>
      {priority}
    </span>
  );
}
