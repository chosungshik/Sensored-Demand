import { X, User, CalendarDays, Zap, AlertCircle, ArrowRight } from 'lucide-react';
import { OperationAction } from '../types';
import { PriorityBadge } from './ui';

interface Props {
  action: OperationAction | null;
  onClose: () => void;
}

export function ActionDetailDrawer({ action, onClose }: Props) {
  if (!action) return null;

  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed inset-0 bg-slate-900/20 backdrop-blur-sm z-40 animate-in fade-in transition-opacity" 
        onClick={onClose}
      />
      
      {/* Drawer */}
      <div className="fixed top-0 right-0 h-full w-[480px] bg-white shadow-2xl z-50 flex flex-col animate-in slide-in-from-right duration-300">
        <div className="px-6 py-4 flex items-center justify-between border-b border-slate-100 bg-slate-50/50">
          <div>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mb-1">Execution Action</p>
            <h3 className="text-lg font-bold text-slate-900 leading-none">{action.type}</h3>
          </div>
          <button onClick={onClose} className="p-2 text-slate-400 hover:text-slate-600 rounded-full hover:bg-slate-100 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-8">
          {/* Action Overview */}
          <div className="bg-slate-50 border border-slate-200 rounded-xl p-5 relative overflow-hidden">
            <div className={`absolute left-0 top-0 w-1 h-full ${
              action.priority === 'High' ? 'bg-rose-500' :
              action.priority === 'Medium' ? 'bg-amber-500' : 'bg-slate-400'
            }`} />
            
            <div className="flex items-start justify-between mb-4">
               <div>
                  <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-2">Subject</p>
                  <p className="text-sm font-bold text-slate-900">{action.cluster}</p>
                  <p className="text-xs text-slate-500 mt-1">{action.region}</p>
               </div>
               <div className="text-right">
                  <p className="text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-2">Priority</p>
                  <PriorityBadge priority={action.priority} />
               </div>
            </div>

            <div className="mt-4 pt-4 border-t border-slate-200">
               <p className="text-[10px] text-slate-500 font-bold uppercase tracking-wider mb-2">Confidence Score</p>
               <div className="flex items-center space-x-2">
                 <span className={`text-xs font-bold ${action.confidence === 'High' ? 'text-emerald-600' : 'text-amber-600'}`}>
                   {action.confidence}
                 </span>
                 <div className="flex-1 h-1 bg-slate-200 rounded-full overflow-hidden">
                   <div className={`h-full ${action.confidence === 'High' ? 'bg-emerald-500' : 'bg-amber-500'}`} style={{width: action.confidence === 'High'? '85%' : '60%'}}></div>
                 </div>
               </div>
            </div>
          </div>

          {/* Action Details */}
          <div>
            <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wide mb-4 pb-2 border-b border-slate-100 border-dashed">Execution Details</h4>
            <div className="space-y-6">
              
              <div>
                <div className="flex items-center text-xs font-bold text-slate-900 mb-2">
                  <Zap className="w-4 h-4 text-amber-500 mr-2" /> Trigger Event
                </div>
                <p className="text-[11px] text-slate-600 leading-relaxed ml-6">
                  {action.description}
                </p>
              </div>

              <div>
                <div className="flex items-center text-xs font-bold text-slate-900 mb-2">
                  <AlertCircle className="w-4 h-4 text-blue-500 mr-2" /> Expected Impact
                </div>
                <div className="ml-6 px-3 py-2 bg-blue-50 rounded border border-blue-100">
                  <p className="text-xs font-bold text-blue-900">
                    {action.impactMetric}
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="flex items-center text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">
                    <User className="w-3 h-3 mr-1" /> Owner
                  </div>
                  <p className="text-xs font-bold text-slate-900">{action.owner || 'System Auto'}</p>
                </div>
                <div>
                   <div className="flex items-center text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2">
                    <CalendarDays className="w-3 h-3 mr-1" /> Due Date
                  </div>
                  <p className="text-xs font-bold text-slate-900">{action.dueDate || 'Today'}</p>
                </div>
              </div>

            </div>
          </div>
        </div>

        {/* Action Footer */}
        <div className="p-6 border-t border-slate-200 bg-white grid grid-cols-2 gap-3 shrink-0">
          <button className="px-4 py-3 bg-white border border-slate-200 shadow-sm rounded-lg text-xs font-bold text-slate-700 hover:bg-slate-50 transition-colors">
            Reject
          </button>
          <button className="px-4 py-3 bg-emerald-600 text-white shadow-sm rounded-lg text-xs font-bold transition-colors hover:bg-emerald-700">
            Approve Execution
          </button>
          <button className="col-span-2 px-4 py-2 border border-transparent text-xs font-bold text-blue-700 hover:text-blue-900 transition-colors flex items-center justify-center mt-1">
            Delegate to {action.owner || 'Owner'} <ArrowRight className="w-3 h-3 ml-1" />
          </button>
        </div>
      </div>
    </>
  );
}
