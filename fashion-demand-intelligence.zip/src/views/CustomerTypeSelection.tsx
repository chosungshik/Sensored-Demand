import { useState } from 'react';
import { CUSTOMER_TYPES } from '../data';
import { CheckCircle2, XCircle, ArrowRight, Building2, Store, MonitorSmartphone, Globe } from 'lucide-react';
import { CustomerTypeData } from '../types';

interface Props {
  onSetupComplete: () => void;
}

export function CustomerTypeSelection({ onSetupComplete }: Props) {
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const selectedType = CUSTOMER_TYPES.find(ct => ct.id === selectedId);

  const getIcon = (id: string) => {
    switch (id) {
      case 'ct-1': return <MonitorSmartphone className="w-5 h-5 text-blue-600" />;
      case 'ct-2': return <Store className="w-5 h-5 text-blue-600" />;
      case 'ct-3': return <Globe className="w-5 h-5 text-blue-600" />;
      case 'ct-4': return <Building2 className="w-5 h-5 text-blue-600" />;
      default: return <Building2 className="w-5 h-5 text-blue-600" />;
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-500 flex flex-col items-center justify-center min-h-[calc(100vh-8rem)]">
      <div className="w-full max-w-5xl">
        <div className="mb-8 text-center">
          <h1 className="text-3xl font-light text-slate-800 tracking-tight mb-3">
            Select your <span className="font-semibold text-blue-900">Retail Organization Profile</span>
          </h1>
          <p className="text-sm text-slate-500 max-w-xl mx-auto">
            Configure Fashion Demand Intelligence for your specific business model. This will activate the appropriate decision modules and data pipelines.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {CUSTOMER_TYPES.map((type) => (
            <div
              key={type.id}
              onClick={() => setSelectedId(type.id)}
              className={`cursor-pointer rounded-xl border p-5 shadow-sm transition-all duration-200 flex flex-col h-full ${
                selectedId === type.id
                  ? 'border-blue-600 bg-blue-50/50 ring-1 ring-blue-600'
                  : 'border-slate-200 bg-white hover:border-blue-300 hover:shadow-md'
              }`}
            >
              <div className="mb-4">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center mb-3 ${selectedId === type.id ? 'bg-blue-100' : 'bg-slate-100'}`}>
                  {getIcon(type.id)}
                </div>
                <h3 className="font-bold text-slate-900 text-sm">{type.name}</h3>
                <p className="text-[10px] text-slate-500 mt-1 uppercase tracking-wider">{type.examples}</p>
              </div>
              
              <div className="mt-auto pt-4 border-t border-slate-100">
                <span className={`text-[10px] font-bold uppercase tracking-widest ${selectedId === type.id ? 'text-blue-700' : 'text-slate-400'}`}>
                  {selectedId === type.id ? 'Selected' : 'Select Profile'}
                </span>
              </div>
            </div>
          ))}
        </div>

        {selectedType && (
          <div className="bg-white border border-slate-200 rounded-xl p-6 shadow-sm animate-in slide-in-from-bottom-4 duration-300">
            <h3 className="text-sm font-bold text-slate-900 mb-6 pb-3 border-b border-slate-100">Configuration Summary</h3>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
              <div>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-3">Active Modules</p>
                <ul className="space-y-2">
                  {selectedType.activeModules.map((module, idx) => (
                    <li key={idx} className="flex items-start">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500 mr-2 mt-0.5 shrink-0" />
                      <span className="text-xs font-semibold text-slate-700">{module}</span>
                    </li>
                  ))}
                </ul>
              </div>
              
              <div>
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-3">Inactive Modules</p>
                {selectedType.inactiveModules.length > 0 ? (
                  <ul className="space-y-2">
                    {selectedType.inactiveModules.map((module, idx) => (
                      <li key={idx} className="flex items-start opacity-60">
                        <XCircle className="w-3.5 h-3.5 text-slate-400 mr-2 mt-0.5 shrink-0" />
                        <span className="text-xs font-medium text-slate-500">{module}</span>
                      </li>
                    ))}
                  </ul>
                ) : (
                  <p className="text-xs text-slate-500 italic">No modules deactivated for this profile.</p>
                )}
              </div>
              
              <div className="flex flex-col">
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-3">Next Steps</p>
                <p className="text-xs text-slate-600 mb-6 leading-relaxed">
                  Proceed to connect your baseline data sources (Sales history, Inventory, Product catalog). AI inferences will be calibrated to the <span className="font-bold text-slate-900">{selectedType.name}</span> pattern.
                </p>
                <button
                  onClick={onSetupComplete}
                  className="mt-auto bg-blue-900 hover:bg-blue-800 text-white text-xs font-bold py-2.5 px-4 rounded shadow-sm flex items-center justify-center transition-colors w-full"
                >
                  Confirm & Initialize
                  <ArrowRight className="w-3.5 h-3.5 ml-2" />
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
