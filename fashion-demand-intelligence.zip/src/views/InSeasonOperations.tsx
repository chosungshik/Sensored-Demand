import { useState } from 'react';
import { MetricCard } from '../components/ui';
import { ActionQueueTable } from '../components/ActionQueueTable';
import { ActionDetailDrawer } from '../components/ActionDetailDrawer';
import { OperationAction } from '../types';
import { useData } from '../DataContext';

export function InSeasonOperations() {
  const [selectedAction, setSelectedAction] = useState<OperationAction | null>(null);
  const { operationActions } = useData();

  return (
    <div className="space-y-6 animate-in fade-in duration-500 flex flex-col h-full relative">
      <ActionDetailDrawer action={selectedAction} onClose={() => setSelectedAction(null)} />

      <div className="h-10 bg-blue-900 text-blue-50 px-6 flex items-center shrink-0 shadow-inner rounded overflow-hidden">
        <p className="text-sm font-light truncate">
          <strong className="font-bold uppercase tracking-wider text-[10px] mr-2 opacity-80">Immediate Action Required:</strong> 
          Trigger <span className="font-semibold text-white">Mid-season Reorder</span> for <span className="font-semibold text-white">Linen Shirts</span> to prevent stockout in Seville.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 shrink-0">
        <MetricCard title="Priority Actions" value={operationActions.length} change="Requires approval" trend="flat" />
        <MetricCard title="Est. Revenue Protected" value="$210k" change="Next 7 Days" trend="up" />
        <MetricCard title="Avg Exec Time" value="4.2h" change="1.1h" trend="down" />
        <MetricCard title="Underperforming Stores" value="4" change="2 benchmkt" trend="flat" />
      </div>

      <div className="flex-1 min-h-[400px]">
        <ActionQueueTable 
          actions={operationActions} 
          onRowClick={(act) => setSelectedAction(act)}
        />
      </div>
    </div>
  );
}
