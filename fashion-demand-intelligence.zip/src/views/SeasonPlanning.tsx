import { useState } from 'react';
import { MetricCard } from '../components/ui';
import { RecommendationTable } from '../components/RecommendationTable';
import { DemandChart } from '../components/DemandChart';
import { ProductDetailDrawer } from '../components/ProductDetailDrawer';
import { PlanningRecommendation } from '../types';
import { useData } from '../DataContext';

export function SeasonPlanning() {
  const [selectedRec, setSelectedRec] = useState<PlanningRecommendation | null>(null);
  const { planningRecommendations } = useData();

  return (
    <div className="space-y-6 animate-in fade-in duration-500 flex flex-col h-full relative">
      <ProductDetailDrawer recommendation={selectedRec} onClose={() => setSelectedRec(null)} />
      
      <div className="h-10 bg-blue-900 text-blue-50 px-6 flex items-center shrink-0 shadow-inner rounded overflow-hidden">
        <p className="text-sm font-light truncate">
          <strong className="font-bold uppercase tracking-wider text-[10px] mr-2 opacity-80">Recommendation:</strong> 
          Increase budget allocation for <span className="font-semibold text-white">Linen Shirts</span> & <span className="font-semibold text-white">Lightweight Dresses</span> to capture weather-driven demand.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 shrink-0">
        <MetricCard title="Missed Demand Est." value="14.2k" change="Resolved 8k" trend="down" />
        <MetricCard title="Weather Risk Value" value="$420k" change="Protected" trend="flat" />
        <MetricCard title="Plan Accuracy vs LY" value="94.2%" change="1.2%" trend="up" />
        <MetricCard title="Pending Allocations" value="5" change="Awaiting approval" trend="flat" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 flex-1 min-h-[300px]">
        <div className="flex-1 lg:col-span-2 min-h-0 h-full">
          <RecommendationTable 
            recommendations={planningRecommendations} 
            onRowClick={(rec) => setSelectedRec(rec)} 
          />
        </div>
        <div className="flex flex-col h-full">
           <DemandChart />
        </div>
      </div>
    </div>
  );
}
