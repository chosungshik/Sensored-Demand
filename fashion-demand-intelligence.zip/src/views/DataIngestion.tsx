import { useState } from 'react';
import { Database, Settings2, Link as LinkIcon, UploadCloud, FileSpreadsheet, CheckCircle2, AlertTriangle, ArrowRight, TableProperties, Zap } from 'lucide-react';

export function DataIngestion({ onComplete }: { onComplete: () => void }) {
  const [step, setStep] = useState<'upload' | 'mapping' | 'validation' | 'activation'>('upload');
  
  return (
    <div className="flex flex-col h-full animate-in fade-in duration-500 max-w-6xl mx-auto w-full">
      <div className="mb-6">
        <h1 className="text-2xl font-light text-slate-800 tracking-tight">
          Data Integration & <span className="font-semibold text-blue-900">Feature Activation</span>
        </h1>
        <p className="text-sm text-slate-500 mt-2">Connect your data to activate Designovel's predictive models.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 flex-1 min-h-[500px]">
        {/* Left: Architecture */}
        <div className="lg:col-span-4 bg-white border border-slate-200 rounded-xl flex flex-col shadow-sm overflow-hidden">
          <div className="p-4 border-b border-slate-100 shrink-0 bg-slate-50">
            <h3 className="text-sm font-bold text-slate-900">Data Architecture</h3>
            <p className="text-[10px] text-slate-500 uppercase tracking-widest mt-0.5">System Topology</p>
          </div>
          <div className="p-5 flex-1 overflow-y-auto space-y-8">
            {/* Customer Provided */}
            <div>
              <h4 className="text-xs font-bold text-slate-900 flex items-center mb-3">
                <Database className="w-4 h-4 mr-1.5 text-blue-600" /> Customer Provided
              </h4>
              <ul className="space-y-2.5 ml-6">
                {[
                  'Product Master', 'Sales History 2023-2025', 'Inventory History',
                  'Store Master', 'Store Sales', 'Store Inventory',
                  'Baseline Buy Plan', 'Reorder History', 'Promotion / Discount History'
                ].map((item) => (
                   <li key={item} className="text-[11px] text-slate-600 font-medium flex items-center relative">
                      <div className={`absolute -left-6 top-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full ${step === 'activation' ? 'bg-emerald-500' : 'bg-amber-400'}`} />
                      {item}
                   </li>
                ))}
              </ul>
            </div>

            {/* Designovel */}
            <div>
              <h4 className="text-xs font-bold text-slate-900 flex items-center mb-3">
                 <Settings2 className="w-4 h-4 mr-1.5 text-purple-600" /> Designovel Appended
              </h4>
              <ul className="space-y-2.5 ml-6">
                {[
                  'Fashion Tagging', 'Product Similarity', 'Product Type Classification',
                  'PLC Pattern Analysis', 'Missed Demand Estimate', 'Store Cluster Analysis'
                ].map((item) => (
                   <li key={item} className="text-[11px] text-slate-500 font-medium flex items-center relative">
                      <div className={`absolute -left-6 top-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full ${step === 'activation' ? 'bg-emerald-500' : 'bg-slate-300'}`} />
                      {item}
                   </li>
                ))}
              </ul>
            </div>

            {/* External API */}
            <div>
              <h4 className="text-xs font-bold text-slate-900 flex items-center mb-3">
                <LinkIcon className="w-4 h-4 mr-1.5 text-emerald-600" /> External API Data
              </h4>
              <ul className="space-y-2.5 ml-6">
                {['Weather History', 'Weather Forecast', 'Search Trends'].map((item) => (
                   <li key={item} className="text-[11px] text-slate-600 font-medium flex items-center relative">
                      <div className={`absolute -left-6 top-1/2 -translate-y-1/2 w-1.5 h-1.5 rounded-full bg-emerald-500`} />
                      {item}
                   </li>
                ))}
              </ul>
            </div>
          </div>
        </div>

        {/* Right: Setup Flow */}
        <div className="lg:col-span-8 bg-white border border-slate-200 rounded-xl shadow-sm flex flex-col overflow-hidden">
           {/* Flow Tabs */}
           <div className="border-b border-slate-100 flex items-center bg-slate-50 shrink-0">
              <div className={`flex-1 py-3 px-4 text-center text-xs font-bold uppercase tracking-wider border-b-2 ${step === 'upload' ? 'border-blue-600 text-blue-900 bg-white' : 'border-transparent text-slate-400'}`}>1. Upload</div>
              <div className={`flex-1 py-3 px-4 text-center text-xs font-bold uppercase tracking-wider border-b-2 ${step === 'mapping' ? 'border-blue-600 text-blue-900 bg-white' : 'border-transparent text-slate-400'}`}>2. Mapping</div>
              <div className={`flex-1 py-3 px-4 text-center text-xs font-bold uppercase tracking-wider border-b-2 ${step === 'validation' ? 'border-blue-600 text-blue-900 bg-white' : 'border-transparent text-slate-400'}`}>3. Validation</div>
              <div className={`flex-1 py-3 px-4 text-center text-xs font-bold uppercase tracking-wider border-b-2 ${step === 'activation' ? 'border-blue-600 text-blue-900 bg-white' : 'border-transparent text-slate-400'}`}>4. Activation</div>
           </div>
           
           <div className="p-8 flex-1 flex flex-col overflow-y-auto">
              
              {/* === UPLOAD STEP === */}
              {step === 'upload' && (
                <div className="flex flex-col h-full animate-in fade-in">
                  <h3 className="text-sm font-bold text-slate-900 mb-6 flex items-center">
                    <FileSpreadsheet className="w-5 h-5 mr-2 text-blue-600" /> Upload Customer Data
                  </h3>
                  
                  <div className="border-2 border-dashed border-slate-300 rounded-xl bg-slate-50 flex flex-col items-center justify-center p-12 mb-6 hover:border-blue-400 hover:bg-blue-50 transition-colors cursor-pointer">
                    <UploadCloud className="w-12 h-12 text-slate-400 mb-4" />
                    <p className="text-sm font-bold text-slate-700 mb-1">Drag and drop your files here</p>
                    <p className="text-xs text-slate-500">Supports .csv, .xlsx, .xls</p>
                    <button className="mt-6 px-4 py-2 bg-white border border-slate-200 shadow-sm rounded text-xs font-bold text-slate-700 hover:bg-slate-50">Browse Files</button>
                  </div>
                  
                  <div className="flex items-center space-x-3 mb-6">
                    <div className="flex-1 h-px bg-slate-200"></div>
                    <span className="text-[10px] uppercase font-bold text-slate-400 tracking-widest">Or Connect API</span>
                    <div className="flex-1 h-px bg-slate-200"></div>
                  </div>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <button className="p-3 border border-slate-200 rounded flex items-center justify-center text-xs font-bold text-slate-600 hover:bg-slate-50">AWS S3 integration</button>
                    <button className="p-3 border border-slate-200 rounded flex items-center justify-center text-xs font-bold text-slate-600 hover:bg-slate-50">ERP API (SAP, Oracle)</button>
                  </div>
                  
                  <div className="mt-auto pt-6 flex justify-end shrink-0">
                    <button onClick={() => setStep('mapping')} className="px-6 py-2 bg-blue-900 text-white rounded text-xs font-bold flex items-center shadow-sm hover:bg-blue-800">
                      Continue to Mapping <ArrowRight className="w-4 h-4 ml-2" />
                    </button>
                  </div>
                </div>
              )}

              {/* === MAPPING STEP === */}
              {step === 'mapping' && (
                <div className="flex flex-col h-full animate-in fade-in">
                  <h3 className="text-sm font-bold text-slate-900 mb-2 flex items-center">
                    <TableProperties className="w-5 h-5 mr-2 text-blue-600" /> Column Mapping
                  </h3>
                  <p className="text-xs text-slate-500 mb-6">We detected column headers from your upload. Please confirm mapping to standard system fields.</p>
                  
                  <div className="border border-slate-200 rounded-lg overflow-hidden shrink-0">
                    <table className="w-full text-left">
                      <thead className="bg-slate-50 text-[10px] font-bold text-slate-500 uppercase tracking-widest">
                        <tr>
                          <th className="p-3 border-b border-slate-200">Detected Column (Source)</th>
                          <th className="p-3 border-b border-slate-200 w-12"></th>
                          <th className="p-3 border-b border-slate-200">System Field (Target)</th>
                        </tr>
                      </thead>
                      <tbody className="text-xs divide-y divide-slate-100 flex-1 overflow-y-auto">
                        {[
                          { src: '품번', target: 'product_id', ok: true },
                          { src: 'SKU', target: 'sku', ok: true },
                          { src: '판매수량', target: 'sales_qty', ok: true },
                          { src: '재고수량', target: 'stock_qty', ok: true },
                          { src: '매장코드', target: 'store_id', ok: true },
                          { src: '판매일자', target: 'date', ok: true },
                        ].map((row, i) => (
                          <tr key={i}>
                            <td className="p-3 font-semibold text-slate-700 bg-slate-50">{row.src}</td>
                            <td className="p-3 text-center text-slate-300"><ArrowRight className="w-4 h-4 inline" /></td>
                            <td className="p-3">
                              <select className="w-full p-2 border border-blue-200 rounded text-xs font-semibold text-blue-900 bg-blue-50 focus:outline-none focus:ring-1 focus:ring-blue-500">
                                <option>{row.target}</option>
                              </select>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>

                  <div className="mt-auto pt-6 flex justify-between shrink-0">
                    <button onClick={() => setStep('upload')} className="px-5 py-2 border border-slate-200 text-slate-600 rounded text-xs font-bold hover:bg-slate-50">Back</button>
                    <button onClick={() => setStep('validation')} className="px-6 py-2 bg-blue-900 text-white rounded text-xs font-bold flex items-center shadow-sm hover:bg-blue-800">
                      Run Validation <ArrowRight className="w-4 h-4 ml-2" />
                    </button>
                  </div>
                </div>
              )}

              {/* === VALIDATION STEP === */}
              {step === 'validation' && (
                <div className="flex flex-col h-full animate-in fade-in">
                  <h3 className="text-sm font-bold text-slate-900 mb-6 flex items-center">
                    <AlertTriangle className="w-5 h-5 mr-2 text-amber-500" /> Data Quality Report
                  </h3>
                  
                  <div className="grid grid-cols-2 gap-4 mb-8">
                    <div className="p-4 border border-rose-200 bg-rose-50 rounded-lg flex items-start">
                      <AlertTriangle className="w-5 h-5 text-rose-500 mr-3 shrink-0" />
                      <div>
                        <p className="text-xs font-bold text-rose-900">142 Missing SKUs</p>
                        <p className="text-[10px] text-rose-700 mt-1">Found in sales history but not in product master.</p>
                      </div>
                    </div>
                    <div className="p-4 border border-rose-200 bg-rose-50 rounded-lg flex items-start">
                      <AlertTriangle className="w-5 h-5 text-rose-500 mr-3 shrink-0" />
                      <div>
                        <p className="text-xs font-bold text-rose-900">12 Invalid Date Formats</p>
                        <p className="text-[10px] text-rose-700 mt-1">Found in promotion history. System standard is YYYY-MM-DD.</p>
                      </div>
                    </div>
                    <div className="p-4 border border-amber-200 bg-amber-50 rounded-lg flex items-start">
                      <AlertTriangle className="w-5 h-5 text-amber-500 mr-3 shrink-0" />
                      <div>
                        <p className="text-xs font-bold text-amber-900">54 Missing Inv Rows</p>
                        <p className="text-[10px] text-amber-700 mt-1">Gaps in daily inventory logs. Will be interpolated.</p>
                      </div>
                    </div>
                    <div className="p-4 border border-emerald-200 bg-emerald-50 rounded-lg flex items-start">
                      <CheckCircle2 className="w-5 h-5 text-emerald-500 mr-3 shrink-0" />
                      <div>
                        <p className="text-xs font-bold text-emerald-900">Store Mapping Complete</p>
                        <p className="text-[10px] text-emerald-700 mt-1">All 100% of sales match a store master location.</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="bg-slate-50 border border-slate-200 rounded-lg p-5">
                    <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2">Status</p>
                    <p className="text-sm font-semibold text-slate-900">Data quality meets minimum requirements for AI inference.</p>
                    <p className="text-xs text-slate-500 mt-1">The system will auto-patch minor discrepancies during the synthesis phase.</p>
                  </div>

                  <div className="mt-auto pt-6 flex justify-between shrink-0">
                    <button onClick={() => setStep('mapping')} className="px-5 py-2 border border-slate-200 text-slate-600 rounded text-xs font-bold hover:bg-slate-50">Back</button>
                    <button onClick={() => setStep('activation')} className="px-6 py-2 bg-emerald-600 text-white rounded text-xs font-bold flex items-center shadow-sm hover:bg-emerald-700">
                      Approve & Append Features <ArrowRight className="w-4 h-4 ml-2" />
                    </button>
                  </div>
                </div>
              )}
              
              {/* === ACTIVATION STEP === */}
              {step === 'activation' && (
                <div className="flex flex-col h-full animate-in fade-in justify-center">
                  <div className="text-center mb-10">
                    <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Zap className="w-8 h-8 text-blue-600" />
                    </div>
                    <h3 className="text-2xl font-light text-slate-900 tracking-tight">System Ready</h3>
                    <p className="text-sm text-slate-500 mt-2 max-w-sm mx-auto">
                      All data ingested. Designovel tags synthesized. External APIs connected.
                    </p>
                  </div>
                  
                  <div className="border border-slate-200 rounded-xl bg-white shadow-sm shrink-0 mb-8 max-w-md mx-auto w-full p-1">
                    <div className="flex items-center p-3">
                      <CheckCircle2 className="w-5 h-5 text-emerald-500 mr-3" />
                      <div>
                        <p className="text-xs font-bold text-slate-900">Season Planning Module</p>
                        <p className="text-[10px] text-emerald-700 mt-0.5 uppercase tracking-widest font-bold">Activated</p>
                      </div>
                    </div>
                    <div className="flex items-center p-3 border-t border-slate-100">
                      <CheckCircle2 className="w-5 h-5 text-emerald-500 mr-3" />
                      <div>
                        <p className="text-xs font-bold text-slate-900">In-Season Operations Module</p>
                        <p className="text-[10px] text-emerald-700 mt-0.5 uppercase tracking-widest font-bold">Activated</p>
                      </div>
                    </div>
                  </div>

                  <div className="mt-8 flex justify-center shrink-0">
                    <button onClick={onComplete} className="px-8 py-3 bg-slate-900 text-white rounded text-sm font-bold flex items-center shadow-lg hover:bg-slate-800 transition-colors">
                      Enter Dashboard <ArrowRight className="w-4 h-4 ml-2" />
                    </button>
                  </div>
                </div>
              )}

           </div>
        </div>
      </div>
    </div>
  );
}
