import { useState } from 'react';
import { CustomerTypeSelection } from './views/CustomerTypeSelection';
import { DataIngestion } from './views/DataIngestion';
import { SeasonPlanning } from './views/SeasonPlanning';
import { InSeasonOperations } from './views/InSeasonOperations';
import { AppMode } from './types';
import { useData } from './DataContext';
import { seedMockDataToFirestore } from './seedMockData';

export default function App() {
  const [mode, setMode] = useState<AppMode>('setup-profile');
  const { refreshData, loading } = useData();

  const handleSeedData = async () => {
    const success = await seedMockDataToFirestore();
    if (success) {
      alert("Mock data seeded successfully!");
      if (refreshData) {
        await refreshData();
      }
    } else {
      alert("Failed to seed mock data. Check console for details.");
    }
  };

  const isSetup = mode === 'setup-profile' || mode === 'setup-data';

  return (
    <div className="h-screen w-screen overflow-hidden flex flex-col bg-slate-50 font-sans text-slate-900">
      {/* Header */}
      <header className="h-14 bg-white border-b border-slate-200 px-6 flex items-center justify-between shrink-0">
        <div className="flex items-center space-x-4">
          <div className="flex flex-col">
            <h1 className="text-lg font-bold text-slate-900 leading-none">Fashion Demand Intelligence</h1>
            <p className="text-[10px] text-slate-500 font-medium tracking-tight">Decision OS for planning, reorder, weather and store actions</p>
          </div>
          <div className="h-6 w-px bg-slate-200 mx-2"></div>
          
          {/* Mode Switcher */}
          <nav className="flex bg-slate-100 p-1 rounded-md text-xs font-semibold space-x-1">
            <button
              onClick={() => setMode('setup-profile')}
              className={`px-4 py-1 rounded transition-colors ${
                isSetup
                  ? 'bg-white shadow-sm text-blue-900'
                  : 'text-slate-500 hover:text-slate-700'
              }`}
            >
              Data Setup
            </button>
            <button
              onClick={() => setMode('planning')}
              disabled={isSetup}
              className={`px-4 py-1 rounded transition-colors ${
                mode === 'planning'
                  ? 'bg-white shadow-sm text-blue-900'
                  : 'text-slate-500 hover:text-slate-700 disabled:opacity-50 disabled:cursor-not-allowed'
              }`}
            >
              Season Planning
            </button>
            <button
              onClick={() => setMode('operations')}
              disabled={isSetup}
              className={`px-4 py-1 rounded transition-colors ${
                mode === 'operations'
                  ? 'bg-white shadow-sm text-blue-900'
                  : 'text-slate-500 hover:text-slate-700 disabled:opacity-50 disabled:cursor-not-allowed'
              }`}
            >
              In-season Operations
            </button>
          </nav>
        </div>

        <div className="flex items-center space-x-6">
          <button 
            onClick={handleSeedData}
            className="px-3 py-1.5 bg-blue-600 border border-blue-700 rounded text-xs font-semibold text-white hover:bg-blue-700 flex items-center transition-colors"
          >
            Seed Mock Data to Firestore
          </button>
          <div className="flex items-center space-x-2">
            <span className={`flex h-2 w-2 rounded-full ${isSetup ? 'bg-amber-400' : 'bg-emerald-500'}`}></span>
            <span className="text-[10px] font-bold uppercase tracking-wider text-slate-600">
              {isSetup ? 'Setup Required' : 'Data Health: Healthy'}
            </span>
          </div>
          <button 
            onClick={() => setMode('setup-profile')}
            className={`px-3 py-1.5 border border-slate-200 rounded text-xs font-semibold hover:bg-slate-50 flex items-center transition-colors ${isSetup ? 'bg-slate-100' : 'bg-white'}`}
          >
            Data Setup
          </button>
          <div className="h-8 w-8 rounded-full bg-slate-800 flex items-center justify-center text-white text-[10px] font-bold tracking-widest">
            AD
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 overflow-y-auto p-6 flex flex-col space-y-6 relative">
        {loading && (
          <div className="absolute inset-0 bg-white/50 backdrop-blur-sm z-50 flex items-center justify-center pointer-events-none">
            <span className="text-sm font-semibold text-slate-500">Loading DB Data...</span>
          </div>
        )}
        {mode === 'setup-profile' && <CustomerTypeSelection onSetupComplete={() => setMode('setup-data')} />}
        {mode === 'setup-data' && <DataIngestion onComplete={() => setMode('planning')} />}
        {mode === 'planning' && <SeasonPlanning />}
        {mode === 'operations' && <InSeasonOperations />}
      </main>

      {/* Footer */}
      <footer className="h-6 bg-slate-100 border-t border-slate-200 px-6 flex items-center justify-between shrink-0">
        <div className="flex space-x-4">
          <span className="text-[9px] font-medium text-slate-400">Model: FDI-V4-ENTERPRISE</span>
          <span className="text-[9px] font-medium text-slate-400 uppercase tracking-widest">Region: Iberia Cluster</span>
        </div>
        <div className="text-[9px] font-bold text-slate-600 uppercase">
          &copy; 2026 Fashion Demand Intelligence System v2.1.4
        </div>
      </footer>
    </div>
  );
}
