export interface CustomerTypeData {
  id: string;
  name: string;
  examples: string;
  activeModules: string[];
  inactiveModules: string[];
}

export type AppMode = 'planning' | 'operations' | 'setup-profile' | 'setup-data' | 'queue';

export interface ProductCluster {
  id: string;
  name: string;
  category: string;
}

export interface PlanningRecommendation {
  id: string;
  cluster: string;
  action: 'Increase' | 'Maintain' | 'Reduce' | 'Review';
  baselineBuy: number;
  recommendedBuy: number;
  weatherImpact: number;
  rationale: string;
  confidence: 'High' | 'Medium' | 'Low';
  nextAction: string;
}

export interface OperationAction {
  id: string;
  type: 'Reorder' | 'Replenish' | 'VMD' | 'Benchmark' | 'Transfer' | 'Markdown';
  cluster: string;
  region: string;
  priority: 'High' | 'Medium' | 'Low';
  description: string;
  impactMetric: string;
  status: 'Pending' | 'Executed';
  confidence: 'High' | 'Medium' | 'Low';
  owner: string;
  dueDate: string;
}

export interface TrendData {
  month: string;
  baseline: number;
  projected: number;
}
