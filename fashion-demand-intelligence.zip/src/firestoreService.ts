import { collection, getDocs } from 'firebase/firestore';
import { db } from './firebase';
import { 
  MOCK_PRODUCTS, 
  MOCK_STORES, 
  MOCK_FORECASTS, 
  PLANNING_RECOMMENDATIONS, 
  OPERATION_ACTIONS,
  TREND_DATA
} from './data';
import { MockProduct, MockStore, MockForecast } from './lib/models';
import { PlanningRecommendation, OperationAction, TrendData } from './types';

export async function fetchProducts(): Promise<MockProduct[]> {
  try {
    const querySnapshot = await getDocs(collection(db, 'products'));
    if (!querySnapshot.empty) {
      return querySnapshot.docs.map(doc => doc.data() as MockProduct);
    }
  } catch (error) {
    console.warn('Failed to fetch from Firestore, falling back to mock data:', error);
  }
  return MOCK_PRODUCTS;
}

export async function fetchStores(): Promise<MockStore[]> {
  try {
    const querySnapshot = await getDocs(collection(db, 'stores'));
    if (!querySnapshot.empty) {
      return querySnapshot.docs.map(doc => doc.data() as MockStore);
    }
  } catch (error) {
    console.warn('Failed to fetch from Firestore, falling back to mock data:', error);
  }
  return MOCK_STORES;
}

export async function fetchForecasts(): Promise<MockForecast[]> {
  try {
    const querySnapshot = await getDocs(collection(db, 'weather_forecast'));
    if (!querySnapshot.empty) {
      return querySnapshot.docs.map(doc => doc.data() as MockForecast);
    }
  } catch (error) {
    console.warn('Failed to fetch from Firestore, falling back to mock data:', error);
  }
  return MOCK_FORECASTS;
}

export async function fetchPlanningRecommendations(): Promise<PlanningRecommendation[]> {
  try {
    const querySnapshot = await getDocs(collection(db, 'planning_recommendations'));
    if (!querySnapshot.empty) {
      return querySnapshot.docs.map(doc => doc.data() as PlanningRecommendation);
    }
  } catch (error) {
    console.warn('Failed to fetch from Firestore, falling back to mock data:', error);
  }
  return PLANNING_RECOMMENDATIONS;
}

export async function fetchOperationActions(): Promise<OperationAction[]> {
  try {
    const querySnapshot = await getDocs(collection(db, 'operation_actions'));
    if (!querySnapshot.empty) {
      const actions = querySnapshot.docs.map(doc => doc.data() as OperationAction);
      // Sort by priority if needed or just return
      return actions.sort((a, b) => {
        const pA = a.priority === 'High' ? 3 : a.priority === 'Medium' ? 2 : 1;
        const pB = b.priority === 'High' ? 3 : b.priority === 'Medium' ? 2 : 1;
        return pB - pA;
      });
    }
  } catch (error) {
    console.warn('Failed to fetch from Firestore, falling back to mock data:', error);
  }
  return OPERATION_ACTIONS;
}

export async function fetchTrendData(): Promise<TrendData[]> {
  // This wasn't strictly required to be in firestore, but returning mock for completeness.
  return TREND_DATA;
}
