import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
// import { getAnalytics } from "firebase/analytics";

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyAN2ZD_ruujAhY0Mcdu1N_TAcTA5cnmKCU",
  authDomain: "censored-demand.firebaseapp.com",
  projectId: "censored-demand",
  storageBucket: "censored-demand.firebasestorage.app",
  messagingSenderId: "855376859057",
  appId: "1:855376859057:web:d5334ee4a16f66ff327790",
  measurementId: "G-1WH4QTZT01"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
// const analytics = getAnalytics(app);
