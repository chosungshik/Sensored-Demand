import { collection, writeBatch, doc } from 'firebase/firestore';
import { db } from './firebase';
import { MOCK_PRODUCTS, MOCK_STORES, MOCK_FORECASTS, PLANNING_RECOMMENDATIONS, OPERATION_ACTIONS } from './data';

export async function seedMockDataToFirestore() {
  const batch = writeBatch(db);

  try {
    // Seed Products
    const productsRef = collection(db, 'products');
    MOCK_PRODUCTS.forEach((product) => {
      const docRef = doc(productsRef, product.id);
      batch.set(docRef, product);
    });

    // Seed Stores
    const storesRef = collection(db, 'stores');
    MOCK_STORES.forEach((store) => {
      const docRef = doc(storesRef, store.id);
      batch.set(docRef, store);
    });

    // Seed Weather Forecast
    const forecastsRef = collection(db, 'weather_forecast');
    MOCK_FORECASTS.forEach((forecast, index) => {
      const docRef = doc(forecastsRef, `forecast-${index}`);
      batch.set(docRef, forecast);
    });

    // Seed Planning Recommendations
    const recsRef = collection(db, 'planning_recommendations');
    PLANNING_RECOMMENDATIONS.forEach((rec) => {
      const docRef = doc(recsRef, rec.id);
      batch.set(docRef, rec);
    });

    // Seed Operation Actions
    const actionsRef = collection(db, 'operation_actions');
    OPERATION_ACTIONS.forEach((action) => {
      const docRef = doc(actionsRef, action.id);
      batch.set(docRef, action);
    });

    await batch.commit();
    console.log('Successfully seeded mock data to Firestore!');
    return true;
  } catch (error) {
    console.error('Error seeding data: ', error);
    return false;
  }
}
