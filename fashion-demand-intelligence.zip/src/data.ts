import { PlanningRecommendation, OperationAction, TrendData, CustomerTypeData } from './types';
import { MockProduct, MockStore, MockForecast } from './lib/models';
import { calculatePlanningScore, generateOperationActions } from './lib/engine';

export const CUSTOMER_TYPES: CustomerTypeData[] = [
  {
    id: 'ct-1',
    name: 'Online-only Brand',
    examples: 'Cafe24 / Shopify / D2C fashion brand',
    activeModules: [
      'Season Planning',
      'Reorder / Quick Response',
      'Weather & Search Demand Signal'
    ],
    inactiveModules: [
      'Store Benchmarking',
      'VMD Action',
      'Store Transfer'
    ]
  },
  {
    id: 'ct-2',
    name: 'Online + Offline Stores',
    examples: 'Mango, Zara, SPAO',
    activeModules: [
      'Season Planning',
      'Regional Allocation',
      'Store Replenishment',
      'VMD Action',
      'Reorder',
      'Store Benchmarking'
    ],
    inactiveModules: []
  },
  {
    id: 'ct-3',
    name: 'Large Basic-item Brand',
    examples: 'Uniqlo, Topten',
    activeModules: [
      'Basic item replenishment',
      'Store benchmarking',
      'Stock cover optimization',
      'Regional weather response'
    ],
    inactiveModules: []
  },
  {
    id: 'ct-4',
    name: 'Enterprise ERP-integrated Brand',
    examples: 'Global Enterprise',
    activeModules: [
      'Realtime sales/inventory sync',
      'ERP/API integration',
      'Action queue',
      'Replenishment',
      'Transfer',
      'VMD',
      'Planning'
    ],
    inactiveModules: []
  }
];

export const CLUSTERS = [
  'Ribbed Tanks',
  'Linen Shirts',
  'Lightweight Dresses',
  'Cotton Tees',
  'Light Jackets',
  'Wide Leg Pants'
];

export const REGIONS = ['Seville', 'Valencia', 'Barcelona', 'Madrid', 'Bilbao'];

export const MOCK_PRODUCTS: MockProduct[] = [
  {
    id: 'p1',
    cluster: 'Linen Shirts',
    baseBuy: 12000,
    similarityScore: 90,
    lyPlcAcceleration: 80,
    weatherFit: 95,
    searchTrend: 85,
    missedDemandSignal: 70,
    productType: 'Fashion',
    salesVelocity: 1.5,
    stockCover: 3,
    plcPosition: 0.2,
    remainingSeason: 12,
    leadTime: 4,
    weatherSensitivity: 0.8
  },
  {
    id: 'p2',
    cluster: 'Lightweight Dresses',
    baseBuy: 8000,
    similarityScore: 85,
    lyPlcAcceleration: 75,
    weatherFit: 88,
    searchTrend: 70,
    missedDemandSignal: 60,
    productType: 'Fashion',
    salesVelocity: 1.1,
    stockCover: 5,
    plcPosition: 0.4,
    remainingSeason: 10,
    leadTime: 3,
    weatherSensitivity: 0.9
  },
  {
    id: 'p3',
    cluster: 'Light Jackets',
    baseBuy: 9500,
    similarityScore: 60,
    lyPlcAcceleration: 40,
    weatherFit: 20,
    searchTrend: 30,
    missedDemandSignal: 10,
    productType: 'Basic',
    salesVelocity: 0.6,
    stockCover: 10,
    plcPosition: 0.8,
    remainingSeason: 4,
    leadTime: 5,
    weatherSensitivity: 0.4
  },
  {
    id: 'p4',
    cluster: 'Wide Leg Pants',
    baseBuy: 15000,
    similarityScore: 70,
    lyPlcAcceleration: 50,
    weatherFit: 50,
    searchTrend: 45,
    missedDemandSignal: 30,
    productType: 'Core',
    salesVelocity: 0.9,
    stockCover: 6,
    plcPosition: 0.5,
    remainingSeason: 20,
    leadTime: 6,
    weatherSensitivity: 0.2
  },
  {
    id: 'p5',
    cluster: 'Ribbed Tanks',
    baseBuy: 20000,
    similarityScore: 65,
    lyPlcAcceleration: 60,
    weatherFit: 70,
    searchTrend: 80,
    missedDemandSignal: 40,
    productType: 'Basic',
    salesVelocity: 1.3,
    stockCover: 2,
    plcPosition: 0.3,
    remainingSeason: 15,
    leadTime: 3,
    weatherSensitivity: 0.7
  }
];

export const MOCK_STORES: MockStore[] = [
  { id: 'S-SEV', region: 'Seville', salesIndex: 1.4, stockCover: 2, similarStoreGroup: 'A', vmdStatus: 'Standard' },
  { id: 'S-VAL', region: 'Valencia', salesIndex: 1.1, stockCover: 4, similarStoreGroup: 'A', vmdStatus: 'Optimized' },
  { id: 'S-MAD', region: 'Madrid', salesIndex: 1.0, stockCover: 5, similarStoreGroup: 'B', vmdStatus: 'Standard' },
  { id: 'S-BIL', region: 'Bilbao', salesIndex: 0.6, stockCover: 9, similarStoreGroup: 'C', vmdStatus: 'Outdated' },
];

export const MOCK_FORECASTS: MockForecast[] = [
  { region: 'Seville', tempShift: 4, rainProbability: 10 },    // Heatwave
  { region: 'Valencia', tempShift: 2, rainProbability: 20 },
  { region: 'Bilbao', tempShift: -2, rainProbability: 80 },    // Cool/Rain
];

export const PLANNING_RECOMMENDATIONS: PlanningRecommendation[] = MOCK_PRODUCTS.map(p => {
  const result = calculatePlanningScore(p);
  return {
    id: `rec-${p.id}`,
    cluster: p.cluster,
    action: result.decision as any,
    baselineBuy: p.baseBuy,
    recommendedBuy: result.recommendedQuantity,
    weatherImpact: result.weatherImpact,
    rationale: result.rationale,
    confidence: result.confidence as 'High' | 'Medium' | 'Low',
    nextAction: result.nextAction
  };
});

export const OPERATION_ACTIONS: OperationAction[] = generateOperationActions(MOCK_PRODUCTS, MOCK_STORES, MOCK_FORECASTS);

export const TREND_DATA: TrendData[] = [
  { month: 'Mar', baseline: 4000, projected: 4200 },
  { month: 'Apr', baseline: 6500, projected: 7100 },
  { month: 'May', baseline: 8000, projected: 9500 },
  { month: 'Jun', baseline: 12000, projected: 14000 },
  { month: 'Jul', baseline: 14000, projected: 16500 },
  { month: 'Aug', baseline: 11000, projected: 13000 },
];
