/**
 * TypeScript definitions for Fashion Demand Intelligence SaaS.
 */

export interface DataSetups {
  id: string;
  erpConnection: 'Connected' | 'Error' | 'Pending';
  wmsConnection: 'Connected' | 'Error' | 'Pending';
  posConnection: 'Connected' | 'Error' | 'Pending';
  lastSync: string;
  dataHealthScore: number;
  skusMonitored: number;
  missingAttributes: number;
  outOfStockAlerts: number;
  overstockAlerts: number;
}

export interface Scenario {
  id: string;
  name: string;
  status: 'Pending' | 'Draft' | 'Confirmed';
  budgetAllocated: number;
  targetMargin: number;
  projectedSellThrough: number;
  buyQuantityTotal: number;
  description: string;
  updatedAt: string;
}

export interface ScenarioItem {
  id: string;
  scenarioId: string;
  styleCode: string;
  name: string;
  category: string;
  price: number;
  recommendedQty: number;
  demandForecast: 'High' | 'Medium' | 'Low';
  status: 'Included' | 'Excluded';
  image: string;
}

export interface ActionPlan {
  id: string;
  title: string;
  category: string;
  potentialBenefit: number;
  skuCount: number;
}

export interface Action {
  id: string;
  title: string;
  category: string;
  status: 'Pending' | 'Sent' | 'Dismissed';
  sku: string;
  description: string;
  storeFrom: string;
  storeTo: string;
  quantity: number;
  createdAt: string;
}
