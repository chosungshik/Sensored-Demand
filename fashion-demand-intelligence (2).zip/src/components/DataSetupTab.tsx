import * as React from "react";
import { useState } from "react";
import { createFileRoute, useNavigate } from "@/lib/router-mock";
import { AppShell } from "@/components/AppShell";
import {
  Laptop,
  Store,
  Globe,
  Building2,
  Check,
  X,
  ChevronRight,
  ChevronLeft,
  UploadCloud,
  AlertTriangle,
  Info,
  Database,
  ArrowRight,
  Activity,
  Zap,
} from "lucide-react";
import { setupStore } from "@/lib/setup-store";
import { toast } from "sonner";

export const Route = createFileRoute("/data-setup")({ component: Page });

type ProfileId =
  | "Online-only Brand"
  | "Online + Offline Stores"
  | "Large Basic-item Brand"
  | "Enterprise ERP-integrated Brand";

interface ProfileItem {
  id: ProfileId;
  icon: React.ComponentType<any>;
  subtitle: string;
  desc: string;
  activeModules: string[];
  inactiveModules: string[];
}

const PROFILE_DATA: ProfileItem[] = [
  {
    id: "Online-only Brand",
    icon: Laptop,
    subtitle: "CAFE24 / SHOPIFY / D2C FASHION BRAND",
    desc: "Online-only D2C channels optimized for fast-turn pre-order, rapid markdown, and social demand signals.",
    activeModules: ["Season Planning", "Reorder / Quick Response", "Weather & Search Demand Signal"],
    inactiveModules: ["Store Benchmarking", "VMD Action", "Store Transfer"],
  },
  {
    id: "Online + Offline Stores",
    icon: Store,
    subtitle: "MANGO, ZARA, SPAO",
    desc: "Dual channels needing localized distribution, regional replenishment, physical store benchmarking, and VMD coordination.",
    activeModules: [
      "Season Planning",
      "Regional Allocation",
      "Store Replenishment",
      "VMD Action",
      "Reorder",
      "Store Benchmarking",
    ],
    inactiveModules: [],
  },
  {
    id: "Large Basic-item Brand",
    icon: Globe,
    subtitle: "UNIQLO, TOPTEN",
    desc: "Assortment built on basic/carryover styles. Specialized in high cover optimization, global planning, and weather response.",
    activeModules: [
      "Basic item replenishment",
      "Store benchmarking",
      "Stock cover optimization",
      "Regional weather response",
    ],
    inactiveModules: [],
  },
  {
    id: "Enterprise ERP-integrated Brand",
    icon: Building2,
    subtitle: "GLOBAL ENTERPRISE",
    desc: "Complex systems requiring real-time POS data pools, global API integrations, automated action queues, and full-scale planning.",
    activeModules: [
      "Realtime sales/inventory sync",
      "ERP/API integration",
      "Action queue",
      "Replenishment",
      "Transfer",
      "VMD",
      "Planning",
    ],
    inactiveModules: [],
  },
];

const customerProvidedItems = [
  "Product Master",
  "Sales History 2023-2025",
  "Inventory History",
  "Store Master",
  "Store Sales",
  "Store Inventory",
  "Baseline Buy Plan",
  "Reorder History",
  "Promotion / Discount History",
];

const designovelAppendedItems = [
  "Fashion Tagging",
  "Product Similarity",
  "Product Type Classification",
  "PLC Pattern Analysis",
  "Missed Demand Estimate",
  "Store Cluster Analysis",
];

const externalApiItems = [
  "Weather History",
  "Weather Forecast",
  "Search Trends",
];

function Page() {
  const navigate = useNavigate();
  const [selectedProfileId, setSelectedProfileId] = useState<ProfileId | null>(null);
  const [setupStep, setSetupStep] = useState<number>(0); // 0: Profile selection, 1: UPLOAD, 2: MAPPING, 3: VALIDATION, 4: ACTIVATION

  // Detect map options
  const [mappedFields, setMappedFields] = useState({
    product_id: "Product ID",
    sku: "SKU",
    sales_qty: "Sales Qty",
    stock_qty: "Stock Qty",
    store_id: "Store Code",
    date: "Sales Date",
  });

  const handleNextStep = () => {
    setSetupStep((prev) => prev + 1);
  };

  const handlePrevStep = () => {
    setSetupStep((prev) => Math.max(0, prev - 1));
  };

  const handleFinishSetup = () => {
    setupStore.setProfile(selectedProfileId || "Online + Offline Stores");
    setupStore.completeSetup(92);
    toast.success("Designovel predictive intelligence setup fully activated! Loading dashboard.");
    navigate({ to: "/" });
  };

  const selectedProfile = PROFILE_DATA.find((p) => p.id === selectedProfileId);

  // Helper to render left panel dots based on current step
  const renderDotColor = (category: "customer" | "appended" | "external") => {
    if (setupStep === 4) {
      // In Activation step, absolutely ALL elements turn active (green)!
      return "bg-emerald-500";
    }

    if (category === "customer") {
      return "bg-amber-500 animate-pulse";
    } else if (category === "appended") {
      return "bg-slate-350 bg-slate-300";
    } else {
      return "bg-emerald-500";
    }
  };

  return (
    <AppShell>
      {setupStep === 0 ? (
        // Step 0: Profile Selection screen
        <div className="mx-auto max-w-[1300px] py-10 px-4 flex flex-col items-center justify-center min-h-[calc(100vh-16rem)]">
          {/* Title and description */}
          <div className="text-center max-w-3xl mb-12 animate-in fade-in slide-in-from-top duration-300">
            <h1 className="text-3xl md:text-4xl font-semibold text-slate-900 tracking-tight leading-none">
              Select your <span className="text-[#1e40af] font-bold">Retail Organization Profile</span>
            </h1>
            <p className="mt-4 text-slate-500 text-sm md:text-base leading-relaxed animate-in fade-in duration-300 delay-100">
              Configure Fashion Demand Intelligence for your specific business model. This will activate
              the appropriate decision modules and data pipelines.
            </p>
          </div>

          {/* 4 Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 w-full max-w-[1240px] animate-in fade-in duration-300 delay-100">
            {PROFILE_DATA.map((p) => {
              const IconComponent = p.icon;
              const isSelected = selectedProfileId === p.id;

              return (
                <button
                  key={p.id}
                  onClick={() => setSelectedProfileId(p.id)}
                  className={`flex flex-col items-start text-left bg-card rounded-xl border p-6 transition-all duration-300 hover:shadow-md cursor-pointer ${
                    isSelected
                      ? "border-2 border-[#2563eb] bg-[#eff6ff]/45 shadow-sm ring-1 ring-[#2563eb]/20"
                      : "border-border hover:border-slate-300 bg-card"
                  }`}
                  style={{ minHeight: "220px" }}
                >
                  {/* Icon Container */}
                  <div
                    className={`w-11 h-11 rounded-lg flex items-center justify-center mb-5 transition-colors ${
                      isSelected
                        ? "bg-blue-100 text-[#2563eb]"
                        : "bg-slate-100/80 text-slate-600"
                    }`}
                  >
                    <IconComponent className="h-6 w-6 stroke-[2px]" />
                  </div>

                  {/* Card Info */}
                  <div className="flex-1">
                    <h3 className="text-[15px] font-bold text-slate-900 leading-snug mb-1">
                      {p.id}
                    </h3>
                    <p className="text-[10px] uppercase font-semibold text-slate-400 tracking-wider leading-relaxed">
                      {p.subtitle}
                    </p>
                  </div>

                  {/* Bottom Status text */}
                  <div className="mt-6 pt-3 border-t border-slate-100 w-full flex items-center justify-start">
                    <span
                      className={`text-xs font-bold tracking-wider transition-colors uppercase ${
                        isSelected ? "text-[#2563eb]" : "text-slate-400"
                      }`}
                    >
                      {isSelected ? "Selected" : "Select Profile"}
                    </span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Configuration Summary Section */}
          {selectedProfile && (
            <div className="mt-6 w-full max-w-[1240px] bg-card border border-border rounded-xl p-8 shadow-sm animate-in fade-in slide-in-from-bottom duration-300">
              <h2 className="text-base font-bold text-slate-900 mb-6">Configuration Summary</h2>

              <div className="grid grid-cols-1 md:grid-cols-12 gap-8 items-start">
                {/* Column 1: Active Modules (4 Cols) */}
                <div className="md:col-span-4 border-r border-slate-150 pr-4">
                  <h3 className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-4">
                    Active Modules
                  </h3>
                  <div className="space-y-3">
                    {selectedProfile.activeModules.map((m) => (
                      <div key={m} className="flex items-center gap-3 text-slate-700 text-sm">
                        <div className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-emerald-50 text-emerald-600">
                          <Check className="h-3.5 w-3.5 stroke-[2.5px]" />
                        </div>
                        <span className="font-semibold">{m}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Column 2: Inactive Modules (4 Cols) */}
                <div className="md:col-span-4 border-r border-slate-150 pr-4">
                  <h3 className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-4">
                    Inactive Modules
                  </h3>
                  {selectedProfile.inactiveModules && selectedProfile.inactiveModules.length > 0 ? (
                    <div className="space-y-3">
                      {selectedProfile.inactiveModules.map((m) => (
                        <div key={m} className="flex items-center gap-3 text-slate-400 text-sm">
                          <div className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-slate-50 text-slate-400">
                            <X className="h-3.5 w-3.5 stroke-[2.5px]" />
                          </div>
                          <span className="line-through">{m}</span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-sm italic text-slate-400 leading-relaxed font-light">
                      No modules deactivated for this profile.
                    </p>
                  )}
                </div>

                {/* Column 3: Next Steps & Confirm Button (4 Cols) */}
                <div className="md:col-span-4 pl-0 md:pl-2">
                  <h3 className="text-[11px] font-bold uppercase tracking-wider text-slate-400 mb-4">
                    Next Steps
                  </h3>
                  <p className="text-sm text-slate-600 leading-relaxed mb-6">
                    Proceed to connect your baseline data sources (Sales history, Inventory, Product
                    catalog). AI inferences will be calibrated to the{" "}
                    <strong className="font-bold text-slate-900">{selectedProfile.id}</strong>{" "}
                    pattern.
                  </p>
                  <button
                    onClick={() => setSetupStep(1)}
                    className="w-full bg-[#1e3a8a] text-white hover:bg-[#172e70] font-medium text-sm py-2.5 px-5 rounded-lg inline-flex items-center justify-center gap-2 transition-all shadow-sm hover:translate-x-0.5 duration-200 cursor-pointer"
                  >
                    Confirm & Initialize <ChevronRight className="h-4.5 w-4.5" />
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      ) : (
        // Multi-step Interactive Integration flow (Steps 1, 2, 3, 4)
        <div className="w-full max-w-[1720px] mx-auto py-6 animate-in fade-in duration-300">
          {/* Header titles */}
          <div className="mb-8">
            <h1 className="text-2xl md:text-3xl font-semibold tracking-tight text-slate-900">
              Data Integration & <span className="text-[#193cb0] font-extrabold">Feature Activation</span>
            </h1>
            <p className="mt-1 text-slate-500 text-sm">
              Connect your data to activate Designovel's predictive models.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            {/* LEFT PANEL: Data Architecture topology (3 cols out of 12) */}
            <div className="lg:col-span-3 bg-card border border-slate-200 rounded-xl overflow-hidden shadow-sm flex flex-col h-[650px]">
              <div className="bg-slate-50 border-b border-slate-200 px-5 py-4">
                <h2 className="text-[14px] font-extrabold text-slate-800 tracking-tight leading-none mb-1">
                  Data Architecture
                </h2>
                <span className="text-[9px] font-bold uppercase tracking-wider text-slate-400">
                  SYSTEM TOPOLOGY
                </span>
              </div>

              <div className="flex-1 overflow-y-auto p-5 space-y-6">
                {/* 1. Customer Provided Category */}
                <div>
                  <div className="flex items-center gap-2 text-indigo-950 font-bold text-xs uppercase tracking-wider mb-3">
                    <Database className="h-3.5 w-3.5 text-indigo-700 shrink-0" />
                    Customer Provided
                  </div>
                  <div className="space-y-2.5 pl-1.5">
                    {customerProvidedItems.map((item) => (
                      <div key={item} className="flex items-center gap-2.5">
                        <span className={`h-2 w-2 rounded-full shrink-0 transition-all ${renderDotColor("customer")}`} />
                        <span className={`text-[12px] font-medium ${setupStep === 4 ? "text-slate-850" : "text-slate-600"}`}>
                          {item}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* 2. Designovel Appended Category */}
                <div>
                  <div className="flex items-center gap-2 text-purple-950 font-bold text-xs uppercase tracking-wider mb-3">
                    <Zap className="h-3.5 w-3.5 text-purple-700 shrink-0" />
                    Designovel Appended
                  </div>
                  <div className="space-y-2.5 pl-1.5">
                    {designovelAppendedItems.map((item) => (
                      <div key={item} className="flex items-center gap-2.5">
                        <span className={`h-2 w-2 rounded-full shrink-0 transition-all ${renderDotColor("appended")}`} />
                        <span className={`text-[12px] font-medium ${setupStep === 4 ? "text-slate-850 font-medium text-emerald-750" : "text-slate-400"}`}>
                          {item}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* 3. External API Data Category */}
                <div>
                  <div className="flex items-center gap-2 text-emerald-950 font-bold text-xs uppercase tracking-wider mb-3 font-semibold">
                    <Activity className="h-3.5 w-3.5 text-emerald-700 shrink-0" />
                    External API Data
                  </div>
                  <div className="space-y-2.5 pl-1.5">
                    {externalApiItems.map((item) => (
                      <div key={item} className="flex items-center gap-2.5">
                        <span className={`h-2 w-2 rounded-full shrink-0 transition-all ${renderDotColor("external")}`} />
                        <span className={`text-[12px] font-medium ${setupStep === 4 ? "text-slate-850" : "text-slate-600"}`}>
                          {item}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* RIGHT PANEL: Steppers and workflow logic (9 cols out of 12) */}
            <div className="lg:col-span-9 bg-card border border-slate-200 rounded-xl overflow-hidden shadow-sm flex flex-col h-[650px]">
              {/* Steps Horizontal Header */}
              <div className="flex border-b border-slate-200 bg-slate-50/50">
                {[
                  { num: 1, label: "UPLOAD" },
                  { num: 2, label: "MAPPING" },
                  { num: 3, label: "VALIDATION" },
                  { num: 4, label: "ACTIVATION" },
                ].map((s) => {
                  const isActive = setupStep === s.num;
                  const isCompleted = setupStep > s.num;

                  return (
                    <div
                      key={s.num}
                      className={`flex-1 flex items-center justify-center gap-2 py-4 border-b-2 text-xs font-bold tracking-wider transition-all duration-300 ${
                        isActive
                          ? "border-[#1e40af] text-[#1e40af]"
                          : isCompleted
                          ? "border-emerald-500 text-emerald-600"
                          : "border-transparent text-slate-400 select-none pb-4"
                      }`}
                    >
                      {isCompleted ? (
                        <div className="h-4.5 w-4.5 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center text-[10px]">
                          ✓
                        </div>
                      ) : (
                        <span className="text-[11px] font-extrabold">{s.num}.</span>
                      )}
                      <span>{s.label}</span>
                    </div>
                  );
                })}
              </div>

              {/* Main Step content area */}
              <div className="flex-1 p-8 overflow-y-auto">
                {/* STEP 1: UPLOAD */}
                {setupStep === 1 && (
                  <div className="h-full flex flex-col animate-in fade-in duration-300">
                    <div className="mb-6 flex items-center gap-2.5">
                      <UploadCloud className="h-5 w-5 text-indigo-700" />
                      <h3 className="text-base font-bold text-slate-800">
                        Upload Customer Data
                      </h3>
                    </div>

                    {/* Drag & drop upload target */}
                    <div className="flex-1 border-2 border-dashed border-slate-250 border-slate-300 rounded-xl flex flex-col items-center justify-center p-8 bg-slate-50/40 hover:bg-slate-50 transition-colors">
                      <UploadCloud className="h-12 w-12 text-slate-400 mb-4 animate-bounce shrink-0" />
                      <p className="text-base font-bold text-slate-800">
                        Drag and drop your files here
                      </p>
                      <span className="text-xs text-slate-400 mt-1">
                        Supports .csv, .xlsx, .xls
                      </span>
                      <button className="mt-5 bg-white border border-slate-300 text-slate-700 text-xs font-bold py-2 px-4 rounded-lg hover:bg-slate-50 hover:shadow-sm cursor-pointer shadow-xs">
                        Browse Files
                      </button>
                    </div>

                    {/* API Dividers and platforms */}
                    <div className="my-6 flex items-center text-slate-400 text-[10px] font-bold tracking-widest uppercase">
                      <div className="flex-1 border-t border-slate-200 mr-4" />
                      or connect api
                      <div className="flex-1 border-t border-slate-200 ml-4" />
                    </div>

                    <div className="grid grid-cols-2 gap-4">
                      <button className="flex items-center justify-center gap-2 bg-white border border-slate-200 hover:border-slate-300 py-3 rounded-lg text-xs font-bold text-slate-700 cursor-pointer hover:shadow-xs transition-all">
                        AWS S3 integration
                      </button>
                      <button className="flex items-center justify-center gap-2 bg-white border border-slate-200 hover:border-slate-300 py-3 rounded-lg text-xs font-bold text-slate-700 cursor-pointer hover:shadow-xs transition-all">
                        ERP API (SAP, Oracle)
                      </button>
                    </div>

                    {/* Footer bar */}
                    <div className="mt-8 pt-4 border-t border-slate-100 flex justify-end">
                      <button
                        onClick={handleNextStep}
                        className="bg-[#1e40af] hover:bg-[#1d3557] text-white font-bold text-xs py-2.5 px-6 rounded-lg inline-flex items-center gap-2 transition-all shadow-xs cursor-pointer"
                      >
                        Continue to Mapping <ArrowRight className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                )}

                {/* STEP 2: MAPPING */}
                {setupStep === 2 && (
                  <div className="h-full flex flex-col animate-in fade-in duration-300">
                    <div className="mb-4">
                      <h3 className="text-base font-bold text-slate-800 mb-1">
                        Column Mapping
                      </h3>
                      <p className="text-xs text-slate-400 max-w-2xl font-medium">
                        We detected column headers from your upload. Please confirm mapping to standard system fields.
                      </p>
                    </div>

                    {/* Mapping Form with beautiful design */}
                    <div className="flex-1 overflow-y-auto border border-slate-200 rounded-lg divide-y divide-slate-100">
                      {/* Header row */}
                      <div className="grid grid-cols-12 bg-slate-50 px-4 py-2 font-bold text-[9px] text-slate-400 tracking-wider uppercase">
                        <div className="col-span-5">Detected Column (Source)</div>
                        <div className="col-span-2 text-center">Direction</div>
                        <div className="col-span-5">System Field (Target)</div>
                      </div>

                      {[
                        { label: "Product ID", target: "product_id" },
                        { label: "SKU", target: "sku" },
                        { label: "Sales Qty", target: "sales_qty" },
                        { label: "Stock Qty", target: "stock_qty" },
                        { label: "Store Code", target: "store_id" },
                        { label: "Sales Date", target: "date" },
                      ].map((item) => (
                        <div key={item.label} className="grid grid-cols-12 items-center px-4 py-3 text-slate-700 text-sm font-semibold">
                          <div className="col-span-5 text-slate-800 text-sm font-semibold pl-1">
                            {item.label}
                          </div>
                          <div className="col-span-2 text-center text-slate-350 text-slate-300">
                            →
                          </div>
                          <div className="col-span-5">
                            <select
                              value={item.target}
                              disabled
                              className="w-full text-xs font-semibold bg-blue-50/60 text-[#1e40af] border border-blue-200/50 rounded-md py-1.5 px-3 focus:outline-none cursor-not-allowed uppercase"
                            >
                              <option value={item.target}>{item.target}</option>
                            </select>
                          </div>
                        </div>
                      ))}
                    </div>

                    {/* Footer bar */}
                    <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
                      <button
                        onClick={handlePrevStep}
                        className="border border-slate-250 text-slate-600 bg-white hover:bg-slate-50 font-bold text-xs py-2 px-5 rounded-lg inline-flex items-center gap-1.5 transition-all cursor-pointer shadow-xs"
                      >
                        <ChevronLeft className="h-3.5 w-3.5" /> Back
                      </button>
                      <button
                        onClick={handleNextStep}
                        className="bg-[#1e40af] hover:bg-[#1d3557] text-white font-bold text-xs py-2.5 px-6 rounded-lg inline-flex items-center gap-2 transition-all shadow-xs cursor-pointer"
                      >
                        Run Validation <ArrowRight className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                )}

                {/* STEP 3: VALIDATION */}
                {setupStep === 3 && (
                  <div className="h-full flex flex-col animate-in fade-in duration-300">
                    <div className="mb-5">
                      <h3 className="text-base font-bold text-slate-800 mb-1">
                        Data Quality Report
                      </h3>
                    </div>

                    {/* Data health cards grid */}
                    <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-4 h-full overflow-y-auto">
                      {/* Card 1: Missing SKUs */}
                      <div className="border border-red-200 bg-red-50/30 p-4 rounded-xl flex items-start gap-4">
                        <div className="h-10 w-10 rounded-full bg-red-100 text-red-600 flex items-center justify-center shrink-0">
                          <AlertTriangle className="h-5 w-5" />
                        </div>
                        <div className="min-w-0">
                          <h4 className="text-sm font-extrabold text-red-900 leading-none mb-1">
                            142 Missing SKUs
                          </h4>
                          <span className="text-[11px] font-semibold text-red-700/80 leading-relaxed">
                            Found in sales history but not in product master.
                          </span>
                        </div>
                      </div>

                      {/* Card 2: Invalid Dates */}
                      <div className="border border-red-200 bg-red-50/30 p-4 rounded-xl flex items-start gap-4">
                        <div className="h-10 w-10 rounded-full bg-red-100 text-red-600 flex items-center justify-center shrink-0">
                          <AlertTriangle className="h-5 w-5" />
                        </div>
                        <div className="min-w-0">
                          <h4 className="text-sm font-extrabold text-red-900 leading-none mb-1">
                            12 Invalid Date Formats
                          </h4>
                          <span className="text-[11px] font-semibold text-red-700/80 leading-relaxed">
                            Found in promotion history. System standard is YYYY-MM-DD.
                          </span>
                        </div>
                      </div>

                      {/* Card 3: Missing Rows (Yellow Warning) */}
                      <div className="border border-amber-200 bg-amber-50/20 p-4 rounded-xl flex items-start gap-4">
                        <div className="h-10 w-10 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center shrink-0">
                          <AlertTriangle className="h-5 w-5 text-amber-600" />
                        </div>
                        <div className="min-w-0">
                          <h4 className="text-sm font-extrabold text-amber-950 leading-none mb-1">
                            54 Missing Inv Rows
                          </h4>
                          <span className="text-[11px] font-semibold text-amber-700/80 leading-relaxed">
                            Gaps in daily inventory logs. Will be interpolated.
                          </span>
                        </div>
                      </div>

                      {/* Card 4: Store Mapping (Green Success) */}
                      <div className="border border-emerald-200 bg-emerald-50/25 p-4 rounded-xl flex items-start gap-4">
                        <div className="h-10 w-10 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center shrink-0">
                          <Check className="h-5 w-5 stroke-[2.5px]" />
                        </div>
                        <div className="min-w-0">
                          <h4 className="text-sm font-extrabold text-emerald-900 leading-none mb-1">
                            Store Mapping Complete
                          </h4>
                          <span className="text-[11px] font-semibold text-emerald-700/85 leading-relaxed">
                            All 100% of sales match a store master location.
                          </span>
                        </div>
                      </div>

                      {/* Status Banner */}
                      <div className="md:col-span-2 border border-slate-200 bg-slate-50 p-5 rounded-xl flex items-start gap-3 mt-4">
                        <Info className="h-5 w-5 text-indigo-800 shrink-0 mt-0.5" />
                        <div>
                          <span className="text-[10px] uppercase font-bold tracking-wider text-slate-400 block mb-0.5">
                            STATUS
                          </span>
                          <h4 className="text-sm font-bold text-slate-800 leading-none mb-1">
                            Data quality meets minimum requirements for AI inference.
                          </h4>
                          <p className="text-xs text-slate-500 font-medium">
                            The system will auto-patch minor discrepancies during the synthesis phase.
                          </p>
                        </div>
                      </div>
                    </div>

                    {/* Footer bar */}
                    <div className="mt-6 pt-4 border-t border-slate-100 flex items-center justify-between">
                      <button
                        onClick={handlePrevStep}
                        className="border border-slate-250 text-slate-600 bg-white hover:bg-slate-50 font-bold text-xs py-2 px-5 rounded-lg inline-flex items-center gap-1.5 transition-all cursor-pointer shadow-xs"
                      >
                        <ChevronLeft className="h-3.5 w-3.5" /> Back
                      </button>
                      <button
                        onClick={handleNextStep}
                        className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs py-2.5 px-6 rounded-lg inline-flex items-center gap-2 transition-all shadow-xs cursor-pointer"
                      >
                        Approve & Append Features <ArrowRight className="h-3.5 w-3.5" />
                      </button>
                    </div>
                  </div>
                )}

                {/* STEP 4: ACTIVATION */}
                {setupStep === 4 && (
                  <div className="h-full flex flex-col items-center justify-center text-center animate-in scale-in duration-500">
                    {/* Glowing zap button */}
                    <div className="relative mb-6">
                      <div className="absolute inset-0 bg-[#3b82f6]/25 rounded-full blur-xl animate-ping opacity-60" />
                      <div className="relative h-20 w-20 rounded-full bg-blue-100 flex items-center justify-center text-[#2563eb] border-2 border-blue-200 shadow-md">
                        <Zap className="h-10 w-10 fill-[#2563eb]" />
                      </div>
                    </div>

                    <h2 className="text-2xl font-black text-slate-900 leading-none mb-2">
                      System Ready
                    </h2>
                    <p className="text-xs font-semibold text-slate-400 max-w-sm leading-relaxed mb-6">
                      All data ingested. Designovel tags synthesized. External APIs connected.
                    </p>

                    {/* Activated modules display boxes */}
                    <div className="w-full max-w-md space-y-3 mb-8">
                      <div className="flex items-center justify-between border border-emerald-150 bg-emerald-50/15 rounded-xl px-5 py-3.5 text-left shadow-[0_1px_2px_rgba(0,0,0,0.03)]">
                        <div>
                          <h4 className="text-sm font-bold text-slate-900">
                            Season Planning Module
                          </h4>
                          <p className="text-[10px] uppercase font-bold text-emerald-600 mt-0.5 tracking-wider">
                            Activated
                          </p>
                        </div>
                        <div className="h-6 w-6 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center text-xs">
                          ✓
                        </div>
                      </div>

                      <div className="flex items-center justify-between border border-emerald-150 bg-emerald-50/15 rounded-xl px-5 py-3.5 text-left shadow-[0_1px_2px_rgba(0,0,0,0.03)]">
                        <div>
                          <h4 className="text-sm font-bold text-slate-900">
                            In-Season Operations Module
                          </h4>
                          <p className="text-[10px] uppercase font-bold text-emerald-600 mt-0.5 tracking-wider">
                            Activated
                          </p>
                        </div>
                        <div className="h-6 w-6 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center text-xs">
                          ✓
                        </div>
                      </div>
                    </div>

                    {/* Master setup completion button with a back button */}
                    <div className="flex items-center justify-center gap-4">
                      <button
                        onClick={handlePrevStep}
                        className="bg-white border border-slate-300 hover:bg-slate-50 text-slate-700 font-bold text-xs py-3 px-6 rounded-lg inline-flex items-center gap-1.5 transition-all cursor-pointer shadow-xs"
                      >
                        <ChevronLeft className="h-3.5 w-3.5" /> Back
                      </button>
                      <button
                        onClick={handleFinishSetup}
                        className="bg-[#0f172a] hover:bg-[#1e293b] text-white font-bold text-sm py-3 px-10 rounded-lg inline-flex items-center gap-2.5 transition-all shadow-md hover:translate-x-0.5 duration-200 cursor-pointer"
                      >
                        Enter Dashboard <ChevronRight className="h-5 w-5" />
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </AppShell>
  );
}

export default Page;
