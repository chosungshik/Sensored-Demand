import * as React from "react";
import { useEffect, useState } from "react";
import { createFileRoute, Link } from "@/lib/router-mock";
import { useNavigate } from "@/lib/router-mock";
import { 
  Info, TrendingUp, TrendingDown, Target, ShieldCheck, ChevronRight, X, 
  MapPin, CloudSun, AlertTriangle, ShieldAlert, Award, ArrowUpRight, Check, Activity, Clock
} from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { GlobalFilters } from "@/components/GlobalFilters";
import { SignalBadge } from "@/components/SignalBadge";
import { useSetupState } from "@/lib/setup-store";
import { drawerDetailsData, ClusterDrawerDetails } from "@/data/drawer-details";
import { toast } from "sonner";

export const Route = createFileRoute("/")({
  component: Index,
});

function DecisionCard({
  icon, iconBg, title, value, valueSize, subtitle, signals,
}: { icon: React.ReactNode; iconBg: string; title: string; value: string; valueSize?: string; subtitle: string; signals: string[]; }) {
  return (
    <div className="flex h-full flex-col rounded-xl border border-border bg-card p-5 shadow-[var(--shadow-card)]">
      <div className="flex items-start gap-4">
        <div className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-full ${iconBg}`}>{icon}</div>
        <div className="min-w-0 flex-1">
          <div className="text-sm font-medium text-muted-foreground">{title}</div>
          <div className={`mt-1 font-semibold tracking-tight text-primary ${valueSize ?? "text-2xl"}`}>{value}</div>
          <div className="mt-1 text-sm text-muted-foreground">{subtitle}</div>
        </div>
      </div>
      <div className="mt-auto pt-4 border-t border-border/40 mt-4">
        <div className="text-xs font-semibold text-muted-foreground tracking-wider uppercase">Evidence</div>
        <div className="mt-2 flex flex-wrap gap-1.5">
          {signals.map((s) => <SignalBadge key={s} label={s} />)}
        </div>
      </div>
    </div>
  );
}

type DecisionTone = "increase" | "maintain" | "decrease";
function DecisionBadge({ label, tone }: { label: string; tone: DecisionTone }) {
  const cls =
    tone === "increase"
      ? "border-transparent bg-[color:var(--signal-green-bg)] text-[color:var(--signal-green)]"
      : tone === "maintain"
      ? "border-transparent bg-[color:var(--signal-blue-bg)] text-[color:var(--signal-blue)]"
      : "border-transparent bg-[color:var(--signal-rose-bg)] text-[color:var(--signal-rose)]";
  return <span className={`inline-flex whitespace-nowrap rounded-md border px-2.5 py-1 text-xs font-semibold uppercase tracking-wider ${cls}`}>{label}</span>;
}

type ConfTone = "high" | "medium" | "low";
function ConfidenceDot({ label, tone }: { label: string; tone: ConfTone }) {
  const dot =
    tone === "high"
      ? "bg-[color:var(--signal-green)]"
      : tone === "medium"
      ? "bg-[color:var(--signal-amber)]"
      : "bg-[color:var(--signal-rose)]";
  return (
    <span className="inline-flex items-center gap-2 whitespace-nowrap text-sm font-medium text-foreground">
      {label}
      <span className={`h-2 w-2 rounded-full ${dot}`} />
    </span>
  );
}

const priorityRing = [
  "bg-[color:var(--signal-rose-bg)] text-[color:var(--signal-rose)]",
  "bg-[color:var(--signal-amber-bg)] text-[color:var(--signal-amber)]",
  "bg-secondary text-foreground",
  "bg-secondary text-muted-foreground",
  "bg-secondary text-muted-foreground",
];

type Row = {
  priority: number;
  slug: string;
  decision: string;
  decisionTone: DecisionTone;
  cluster: string;
  change: string;
  reason: string;
  evidence: string[];
  confidence: string;
  confTone: ConfTone;
  upside: string;
  nextStep: string;
};

const rows: Row[] = [
  { priority: 1, slug: "ribbed-tanks", decision: "Increase", decisionTone: "increase", cluster: "Ribbed Tanks", change: "+1,400 units", reason: "Faster sell-through than PLC; early stockout risk.", evidence: ["Similar SS24 items", "Search uplift", "Stockout risk"], confidence: "High", confTone: "high", upside: "€580K – €640K", nextStep: "Review 3 styles" },
  { priority: 2, slug: "linen-shirts", decision: "Increase", decisionTone: "increase", cluster: "Linen Shirts", change: "+1,800 units", reason: "Early/fast sell-through with search growth.", evidence: ["Early sell-through", "Search uplift"], confidence: "High", confTone: "high", upside: "€310K – €390K", nextStep: "Review 2 styles" },
  { priority: 3, slug: "lightweight-dresses", decision: "Increase", decisionTone: "increase", cluster: "Lightweight Dresses", change: "+900 units", reason: "Weather-driven uplift in warm regions.", evidence: ["Weather-sensitive", "Regional concentration"], confidence: "Medium", confTone: "medium", upside: "€240K – €310K", nextStep: "Review 2 styles" },
  { priority: 4, slug: "crochet-tops", decision: "Increase", decisionTone: "increase", cluster: "Crochet Tops", change: "+500 units", reason: "Early trend signal; positive PLC.", evidence: ["Trend signal", "PLC growth"], confidence: "Medium", confTone: "medium", upside: "€150K – €210K", nextStep: "Review 1 style" },
  { priority: 5, slug: "wide-leg-pants", decision: "Increase", decisionTone: "increase", cluster: "Wide Leg Pants", change: "+400 units", reason: "Strong sell-through; concentrated region.", evidence: ["Sell-through", "Regional concentration"], confidence: "Medium", confTone: "medium", upside: "€110K – €150K", nextStep: "Review 1 style" },
];

function HowCalculatedModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  if (!open) return null;
  return (
    <>
      <div className="fixed inset-0 z-40 bg-black/40" onClick={onClose} />
      <div className="fixed left-1/2 top-1/2 z-50 w-[480px] -translate-x-1/2 -translate-y-1/2 rounded-xl border border-border bg-card p-6 shadow-2xl">
        <div className="flex items-start justify-between">
          <h3 className="text-lg font-semibold">How recommendations are generated</h3>
          <button onClick={onClose} className="rounded-md p-1 hover:bg-secondary"><X className="h-4 w-4" /></button>
        </div>
        <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
          Recommendations combine uploaded baseline buy plans, similar SS24 item performance profiles,
          product lifecycle (PLC) velocity coefficients, search trends, local weather anomalies, and store-level runway metrics.
        </p>
        <div className="mt-5 flex justify-end">
          <button onClick={onClose} className="rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90">Got it</button>
        </div>
      </div>
    </>
  );
}

function parseBaseVsRec(str: string) {
  const parts = str.split("->");
  if (parts.length < 2) return { base: "N/A", rec: "N/A", diff: "", pct: "" };
  const base = parts[0].trim();
  const rest = parts[1].trim(); 
  const rec = rest.split("(")[0].trim();
  
  let diff = "";
  let pct = "";
  const match = rest.match(/\(\+([\d,]+)\s*units\s*\(([\d.’%]+)\)\)/);
  if (match) {
    diff = "+" + match[1];
    pct = match[2];
  } else {
    const simpleMatch = rest.match(/\(([^)]+)\)/);
    if (simpleMatch) {
      const inside = simpleMatch[1]; 
      const subParts = inside.split("(");
      diff = subParts[0].replace("units", "").trim();
      pct = subParts[1] ? subParts[1].replace(")", "").trim() : "";
    }
  }
  return { base, rec, diff, pct };
}

function Index() {
  const navigate = useNavigate();
  const setup = useSetupState();
  useEffect(() => {
    if (!setup.complete) navigate({ to: "/data-setup" });
  }, [setup.complete, navigate]);

  const [modalOpen, setModalOpen] = useState(false);
  const [activeClusterSlug, setActiveClusterSlug] = useState<string | null>(null);
  const [drawerTab, setDrawerTab] = useState<"overview" | "plc" | "similar" | "weather" | "regions" | "inventory">("overview");
  const [hoveredWeekIdx, setHoveredWeekIdx] = useState<number | null>(null);

  const plcStats = [
    { week: "W1", actual: "42%", ly: "44%", target: "43%", range: "38% – 48%" },
    { week: "W2", actual: "48%", ly: "47%", target: "47%", range: "42% – 52%" },
    { week: "W3", actual: "68%", ly: "65%", target: "62%", range: "55% – 69%" },
    { week: "W4", actual: "85%", ly: "78%", target: "75%", range: "68% – 82%" },
    { week: "W5", actual: "98%", ly: "82%", target: "80%", range: "72% – 88%" },
    { week: "W6", actual: "—", ly: "85%", target: "81%", range: "75% – 87%" },
    { week: "W7", actual: "—", ly: "78%", target: "72%", range: "65% – 79%" },
    { week: "W8", actual: "—", ly: "65%", target: "58%", range: "50% – 66%" },
    { week: "W9", actual: "—", ly: "50%", target: "42%", range: "35% – 49%" },
    { week: "W10", actual: "—", ly: "35%", target: "28%", range: "20% – 36%" },
    { week: "W11", actual: "—", ly: "22%", target: "18%", range: "12% – 24%" },
    { week: "W12", actual: "—", ly: "12%", target: "10%", range: "5% – 15%" },
  ];

  const clusterDetails = activeClusterSlug ? drawerDetailsData[activeClusterSlug] : null;
  const matchedRow = rows.find((r) => r.slug === activeClusterSlug);
  const { base: drawerBase, rec: drawerRec, diff: drawerDiff, pct: drawerPct } = clusterDetails 
    ? parseBaseVsRec(clusterDetails.baseVsRecommended) 
    : { base: "N/A", rec: "N/A", diff: "", pct: "" };

  const handleAcceptRecommendation = (title: string) => {
    toast.success(`AI Recommendation for ${title} accepted and integrated into Scenario Plan!`);
    setActiveClusterSlug(null);
  };

  const handleReviewLater = (title: string) => {
    toast.info(`Marked ${title} for follow-up review.`);
    setActiveClusterSlug(null);
  };

  const handleExcludeRecommendation = (title: string) => {
    toast.warning(`Recommendation for ${title} has been excluded from this scenario.`);
    setActiveClusterSlug(null);
  };

  return (
    <AppShell>
      <GlobalFilters />

      {/* Title */}
      <div className="mb-5">
        <h1 className="text-2xl font-semibold tracking-tight text-primary">Scenario Planning Adjustments</h1>
      </div>

      {/* Top decision message */}
      <div className="mb-5 flex items-start gap-3 rounded-xl border border-border bg-[color:var(--signal-blue-bg)]/40 px-5 py-4">
        <Info className="mt-0.5 h-5 w-5 shrink-0 text-accent" />
        <div className="text-sm leading-relaxed">
          <div className="text-foreground">
            <span className="font-semibold">RECOMMENDATION:</span> Adjust plans for 4 clusters; selectively review 2 more to optimize inventory levels and reduce stockout risk.
          </div>
          <div className="mt-1 text-muted-foreground">
            Led by Ribbed Tanks, Linen Shirts, and Lightweight Dresses to capture weather-triggered demand surges.
          </div>
        </div>
      </div>

      {/* Decision cards */}
      <div className="grid grid-cols-1 gap-4 md:grid-cols-4">
        <DecisionCard
          icon={<Target className="h-6 w-6 text-[color:var(--signal-purple)]" />}
          iconBg="bg-[color:var(--signal-purple-bg)]"
          title="Selected Clusters"
          value="5 of 8"
          subtitle="priority groups adjusted"
          signals={["Ribbed Tanks", "Linen Shirts", "Lightweight Dresses"]}
        />
        <DecisionCard
          icon={<TrendingUp className="h-6 w-6 text-[color:var(--signal-green)]" />}
          iconBg="bg-[color:var(--signal-green-bg)]"
          title="Net Action Volume"
          value="+5,000 units"
          subtitle="variation vs. baseline plan"
          signals={["Weather uplift", "Stockout prevention", "Fast PLC"]}
        />
        <DecisionCard
          icon={<Award className="h-6 w-6 text-emerald-600" />}
          iconBg="bg-emerald-50"
          title="Revenue Risk Mitigated"
          value="€1.39M – €1.70M"
          subtitle="potential stockout loss avoided"
          signals={["Stockout warnings", "W8 inventory floor", "Runway risk"]}
        />
        <DecisionCard
          icon={<ShieldCheck className="h-6 w-6 text-[color:var(--signal-blue)]" />}
          iconBg="bg-[color:var(--signal-blue-bg)]"
          title="Recommendation Confidence"
          value="High Confidence"
          subtitle="92% similarity correlation"
          signals={["SS24 performance", "Real-time trends", "Weather model"]}
        />
      </div>

      {/* Table */}
      <section className="mt-6 rounded-xl border border-border bg-card shadow-[var(--shadow-card)]">
        <div className="flex items-start justify-between border-b border-border px-6 py-5">
          <div>
            <h2 className="text-base font-semibold">AI Recommended Planning Decisions</h2>
            <p className="mt-1 text-sm text-muted-foreground">Select a row to open interactive planning cabinet drawer.</p>
          </div>
          <button
            onClick={() => setModalOpen(true)}
            className="flex items-center gap-1.5 text-sm font-medium text-accent hover:underline"
          >
            <Info className="h-4 w-4" />
            How recommendations are generated
          </button>
        </div>

        <div className="overflow-x-auto font-sans">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border text-center text-xs font-semibold uppercase tracking-wider text-muted-foreground bg-secondary/20">
                <th className="px-6 py-4 text-center">Priority</th>
                <th className="px-3 py-4 text-center">Decision</th>
                <th className="px-3 py-4 text-center text-left">Product Cluster</th>
                <th className="px-3 py-4 text-center">Change</th>
                <th className="px-3 py-4 text-left">Main Reason</th>
                <th className="px-3 py-4 text-center">Confidence</th>
                <th className="px-3 py-4 text-center">Risk Mitigated <span className="font-normal text-muted-foreground/75">(EUR)</span></th>
                <th className="px-6 py-4 text-center">Actions</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr 
                  key={row.slug} 
                  onClick={() => {
                    setActiveClusterSlug(row.slug);
                    setDrawerTab("overview");
                  }}
                  className="group h-[88px] border-b border-border/60 last:border-0 hover:bg-secondary/40 cursor-pointer transition-colors"
                >
                  <td className="px-6 py-4 align-middle text-center">
                    <div className={`flex h-7 w-7 items-center justify-center rounded-full text-xs font-semibold ${priorityRing[row.priority - 1]}`}>{row.priority}</div>
                  </td>
                  <td className="px-3 py-4 align-middle text-center">
                    <DecisionBadge label={row.decision} tone={row.decisionTone} />
                  </td>
                  <td className="px-3 py-4 align-middle text-left font-bold text-accent group-hover:underline">
                    {row.cluster}
                  </td>
                  <td className="px-3 py-4 align-middle text-center font-semibold text-foreground whitespace-nowrap">{row.change}</td>
                  <td className="px-3 py-4 align-middle text-left">
                    <div className="max-w-[280px] truncate text-sm text-foreground mb-1" title={row.reason}>{row.reason}</div>
                    <div className="flex flex-wrap gap-1">
                      {row.evidence.map((d) => <SignalBadge key={d} label={d} />)}
                    </div>
                  </td>
                  <td className="px-3 py-4 align-middle text-center">
                    <ConfidenceDot label={row.confidence} tone={row.confTone} />
                  </td>
                  <td className="px-3 py-4 align-middle text-center font-semibold text-primary/95 whitespace-nowrap">{row.upside}</td>
                  <td className="px-6 py-4 align-middle text-center">
                    <div className="flex items-center justify-center gap-2" onClick={(e) => e.stopPropagation()}>
                      <button
                        onClick={() => {
                          navigate({ to: `/demand-opportunity/${row.slug}` });
                        }}
                        className="inline-flex items-center gap-1 whitespace-nowrap rounded-lg bg-indigo-600 text-white font-extrabold hover:bg-indigo-750 px-3 py-2 text-xs transition-all shadow-sm cursor-pointer"
                      >
                        Review styles
                        <ChevronRight className="h-3 w-3" />
                      </button>
                      <button
                        onClick={() => {
                          setActiveClusterSlug(row.slug);
                          setDrawerTab("overview");
                        }}
                        className="inline-flex items-center gap-1 whitespace-nowrap rounded-lg border border-border bg-card px-2.5 py-2 text-xs font-semibold text-slate-700 hover:bg-secondary transition-all cursor-pointer"
                      >
                        Why this recommendation?
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* Interactive Planning Cabinet Drawer (CEO-styled) */}
      {activeClusterSlug && clusterDetails && (
        <>
          <div 
            className="fixed inset-0 z-40 bg-black/40 animate-in fade-in cursor-pointer" 
            onClick={() => setActiveClusterSlug(null)} 
          />
          <aside className="fixed right-0 top-0 z-50 flex h-full w-[820px] max-w-[95vw] flex-col border-l border-border bg-card shadow-2xl animate-in slide-in-from-right font-sans">
            
            {/* Drawer Header Block */}
            <div className="bg-secondary/20 border-b border-border p-6">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] uppercase font-extrabold tracking-widest bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded text-indigo-700">
                      Recommendation Evidence
                    </span>
                    <span className="flex items-center gap-1.5 text-xs font-medium text-emerald-600">
                      <Clock className="w-3.5 h-3.5" />
                      Live Data updated
                    </span>
                  </div>
                  <div className="mt-2 text-xs font-extrabold text-slate-400 uppercase tracking-wider">
                    Why this recommendation?
                  </div>
                  <h2 className="text-2xl font-extrabold tracking-tight text-slate-900 mt-1">{clusterDetails.title}</h2>
                </div>
                <button 
                  onClick={() => setActiveClusterSlug(null)} 
                  className="rounded-md p-1.5 text-muted-foreground hover:bg-secondary hover:text-foreground transition-all"
                >
                  <X className="h-5.5 w-5.5" />
                </button>
              </div>

              {/* Primary KPIs Block from Mockup */}
              <div className="mt-5 grid grid-cols-1 md:grid-cols-3 gap-4 bg-card rounded-xl border border-border/80 p-4.5 shadow-sm">
                
                {/* Base vs Recommended (Designed exactly like the attached image!) */}
                <div className="rounded-2xl bg-slate-50/50 border border-slate-100 p-5 flex flex-col justify-between">
                  <div>
                    <span className="text-[10px] uppercase font-bold tracking-widest text-[#5c6883] block">
                      Base vs Recommended
                    </span>
                    <div className="flex items-center gap-4 mt-2.5">
                      {/* Base plan units (e.g. 12,000) crossed out */}
                      <span className="font-sans text-2xl font-semibold text-slate-400/80 line-through tracking-tight">
                        {drawerBase}
                      </span>
                      {/* Rec plan units (e.g. 13,800) in big bold */}
                      <span className="font-sans text-3.5xl font-extrabold text-[#111928] tracking-tight">
                        {drawerRec}
                      </span>
                    </div>
                  </div>
                  <div className="mt-2.5">
                    {/* Live difference tag: +1,800 units (15.0%) */}
                    <span className="text-sm font-extrabold text-[#2e7d32] font-sans block">
                      {drawerDiff} units ({drawerPct})
                    </span>
                  </div>
                </div>

                {/* Confidence Card (1 column - Aligned with high/medium/low across system) */}
                <div className="rounded-2xl bg-neutral-50/50 border border-border/60 p-5 h-full flex flex-col justify-center">
                  <span className="text-[9px] text-muted-foreground font-bold uppercase tracking-widest block">Confidence Level</span>
                  <span className="font-sans text-sm font-extrabold mt-1.5 flex items-center gap-1.5">
                    <span className={`h-2.5 w-2.5 rounded-full ${
                      matchedRow?.confTone === "high" 
                        ? "bg-[color:var(--signal-green)] animate-pulse" 
                        : matchedRow?.confTone === "medium"
                        ? "bg-[color:var(--signal-amber)]"
                        : "bg-[color:var(--signal-rose)]"
                    }`} />
                    <span className={
                      matchedRow?.confTone === "high" 
                        ? "text-[color:var(--signal-green)]" 
                        : matchedRow?.confTone === "medium"
                        ? "text-[color:var(--signal-amber)]"
                        : "text-[color:var(--signal-rose)]"
                    }>
                      {matchedRow ? `${matchedRow.confidence} Confidence` : "High Confidence"}
                    </span>
                  </span>
                </div>

                {/* Strategic Purpose Card (1 column) */}
                <div className="rounded-2xl bg-neutral-50/50 border border-border/60 p-5 h-full flex flex-col justify-center">
                  <span className="text-[9px] text-muted-foreground font-bold uppercase tracking-widest block">Strategic Objective</span>
                  <span className="text-xs font-bold text-slate-800 mt-1.5 block leading-tight">{clusterDetails.decisionType}</span>
                </div>

              </div>
            </div>

            {/* Cabinet Navigation Tabs */}
            <div className="border-b border-border px-6 bg-card sticky top-0 z-10">
              <nav className="flex gap-6 overflow-x-auto scrollbar-none">
                {[
                  { id: "overview", label: "Summary" },
                  { id: "plc", label: "Sales Signal" },
                  { id: "similar", label: "Similar Items" },
                  { id: "weather", label: "External Demand" },
                  { id: "regions", label: "Regional Focus" },
                  { id: "inventory", label: "Stock Risk" },
                ].map((t) => {
                  const isActive = drawerTab === t.id;
                  return (
                    <button
                      key={t.id}
                      onClick={() => setDrawerTab(t.id as any)}
                      className={`border-b-2 py-3.5 text-sm font-semibold whitespace-nowrap transition-all uppercase tracking-wide cursor-pointer ${
                        isActive 
                          ? "border-accent text-accent font-extrabold" 
                          : "border-transparent text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      {t.label}
                    </button>
                  );
                })}
              </nav>
            </div>

            {/* Cabinet Content Body */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6">

              {/* TAB 1: OVERVIEW */}
              {drawerTab === "overview" && (
                <div className="space-y-6 animate-fade-in">
                  
                  {/* Final AI Recommendation Block */}
                  <div className="rounded-xl border border-border bg-card p-6 shadow-sm">
                    <h3 className="text-sm font-extrabold uppercase tracking-wide text-foreground pb-2 border-b border-border flex items-center gap-1.5">
                      <Award className="w-4.5 h-4.5 text-accent" />
                      Final AI Recommendation
                    </h3>
                    <p className="mt-4 text-sm leading-relaxed text-slate-800">
                      {clusterDetails.overview.text}
                    </p>
                    <ul className="mt-4 space-y-3">
                      {clusterDetails.overview.bullets.map((b, i) => (
                        <li key={i} className="flex items-start gap-2.5 text-xs text-slate-600 leading-relaxed">
                          <span className="h-1.5 w-1.5 rounded-full bg-accent mt-1.5 shrink-0" />
                          <span>{b}</span>
                        </li>
                      ))}
                    </ul>

                    {/* DECISION IMPACT ESTIMATE BANNER */}
                    <div className="mt-6 rounded-lg bg-indigo-50/60 border border-indigo-100 p-4 shrink-0">
                      <span className="text-[10px] text-indigo-800 font-bold uppercase tracking-widest block">
                        Estimated Decision Impact
                      </span>
                      <div className="text-[14px] font-mono font-extrabold text-indigo-950 mt-1 flex items-center gap-2">
                        <span>{clusterDetails.overview.benefit}</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: PLC & SALES (Bell Curves representing weekly sales velocity over time) */}
              {drawerTab === "plc" && (
                <div className="space-y-6 animate-fade-in">
                  <div className="bg-card rounded-xl border border-border p-6 shadow-sm">
                    <div className="flex justify-between items-start pb-4 border-b border-border">
                      <div>
                        <h3 className="text-sm font-extrabold uppercase tracking-wide text-foreground">
                          Product Life Cycle & Weekly Sales Profile (Bell Curve)
                        </h3>
                        <p className="text-xs text-muted-foreground mt-0.5">Rolling 12-week lifecycle index profile bounds</p>
                      </div>
                      <span className="bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-bold rounded-full px-2.5 py-0.5 flex items-center gap-1.5 uppercase">
                        <Activity className="h-3 w-3" />
                        Proper PLC Bell Curve
                      </span>
                    </div>
 
                    {/* Vector SVG Bell Curve PLC Line Graph */}
                    <div className="h-56 w-full relative pt-4" id="plc-line-graph-svg">
                      <svg className="h-full w-full" viewBox="0 0 600 180" fill="none">
                        
                        {/* Horizontal dash rules (0%, 25%, 50%, 75%, 100%) */}
                        <line x1="40" y1="20" x2="560" y2="20" stroke="hsl(var(--border))" strokeOpacity="0.4" strokeDasharray="3 3" />
                        <line x1="40" y1="55" x2="560" y2="55" stroke="hsl(var(--border))" strokeOpacity="0.4" strokeDasharray="3 3" />
                        <line x1="40" y1="90" x2="560" y2="90" stroke="hsl(var(--border))" strokeOpacity="0.4" strokeDasharray="3 3" />
                        <line x1="40" y1="125" x2="560" y2="125" stroke="hsl(var(--border))" strokeOpacity="0.4" strokeDasharray="3 3" />
                        <line x1="40" y1="160" x2="560" y2="160" stroke="hsl(var(--border))" strokeOpacity="0.8" />
 
                        {/* Y-Axis Labeling */}
                        <text x="5" y="24" fill="#94a3b8" className="text-[10px] font-sans font-semibold">100%</text>
                        <text x="5" y="59" fill="#94a3b8" className="text-[10px] font-sans font-semibold">75%</text>
                        <text x="5" y="94" fill="#94a3b8" className="text-[10px] font-sans font-semibold">50%</text>
                        <text x="5" y="129" fill="#94a3b8" className="text-[10px] font-sans font-semibold">25%</text>
                        <text x="5" y="164" fill="#94a3b8" className="text-[10px] font-sans font-semibold">0%</text>
 
                        {/* MAX bound line (Dashed Slate - Bell curve weekly profile) */}
                        <path 
                          d="M 40 142 C 160 110, 200 20, 280 20 C 360 20, 420 110, 560 142" 
                          stroke="#94a3b8" 
                          strokeWidth="1.5" 
                          strokeDasharray="4 4" 
                        />
                        <text x="490" y="122" fill="#94a3b8" className="text-[9px] font-sans">Max bound</text>
 
                        {/* MIN bound line (Dashed Slate - Bell curve weekly profile) */}
                        <path 
                          d="M 40 152 C 160 135, 200 75, 280 75 C 360 75, 420 135, 560 152" 
                          stroke="#cbd5e1" 
                          strokeWidth="1.5" 
                          strokeDasharray="4 4" 
                        />
                        <text x="490" y="148" fill="#cbd5e1" className="text-[9px] font-sans">Min bound</text>
 
                        {/* MIDDLE target curve (Dashed Amber/Slate - Bell curve weekly profile) */}
                        <path 
                          d="M 40 147 C 160 120, 200 45, 280 45 C 360 45, 420 120, 560 147" 
                          stroke="#94a3b8" 
                          strokeWidth="1.5" 
                          strokeDasharray="4 4" 
                        />
                        <text x="490" y="135" fill="#94a3b8" className="text-[9px] font-sans">Mid target</text>
 
                        {/* LAST YEAR sales track (Solid Blue curve - Bell curve weekly profile) */}
                        <path 
                          d="M 40 149 C 150 128, 195 50, 275 50 C 355 50, 415 128, 560 149" 
                          stroke="#2563eb" 
                          strokeWidth="2.5" 
                        />
 
                        {/* CURRENT sales track actuals (Solid Black curve - W1 to W5 rising rapidly) */}
                        <path 
                          d="M 40 146 C 90 135, 140 92, 230 55" 
                          stroke="#000000" 
                          strokeWidth="4" 
                          strokeLinecap="round"
                        />
 
                        {/* vertical red dashed line (Week 5: warm shift begins) */}
                        <line x1="230" y1="20" x2="230" y2="160" stroke="#ef4444" strokeWidth="1.5" strokeDasharray="3 3" />
                        <text x="235" y="32" fill="#ef4444" className="text-[10px] font-bold font-sans">W5: Warm shift begins</text>
 
                        {/* vertical orange dashed line (Week 8: Risk window) */}
                        <line x1="380" y1="20" x2="380" y2="160" stroke="#f97316" strokeWidth="1.5" strokeDasharray="3 3" />
                        <text x="385" y="45" fill="#f97316" className="text-[10px] font-bold font-sans">W8: Risk window</text>
 
                        {/* X-Axis labels */}
                        {["W1", "W2", "W3", "W4", "W5", "W6", "W7", "W8", "W9", "W10", "W11", "W12"].map((w, idx) => (
                          <text 
                            key={w} 
                            x={40 + idx * 47.2} 
                            y="176" 
                            fill="#94a3b8" 
                            className="text-[9px] font-bold text-center font-sans"
                          >
                            {w}
                          </text>
                        ))}

                        {/* Interactive Invisible Hover Pillars for Tooltip Trigger */}
                        {["W1", "W2", "W3", "W4", "W5", "W6", "W7", "W8", "W9", "W10", "W11", "W12"].map((w, idx) => {
                          const cx = 40 + idx * 47.2;
                          return (
                            <g key={`interactive-${idx}`}>
                              {hoveredWeekIdx === idx && (
                                <>
                                  <line 
                                    x1={cx} 
                                    y1={20} 
                                    x2={cx} 
                                    y2={160} 
                                    stroke="rgba(99, 102, 241, 0.7)" 
                                    strokeWidth="1.5" 
                                    strokeDasharray="2 2" 
                                  />
                                  <circle cx={cx} cy={160} r="3.5" fill="#4f46e5" />
                                </>
                              )}
                              <rect
                                x={cx - 23}
                                y={10}
                                width={46}
                                height={150}
                                fill="transparent"
                                className="cursor-pointer select-none"
                                onMouseEnter={() => setHoveredWeekIdx(idx)}
                                onMouseLeave={() => setHoveredWeekIdx(null)}
                              />
                            </g>
                          );
                        })}
                      </svg>

                      {/* Tooltip Floating Absolute Overlay */}
                      {hoveredWeekIdx !== null && (
                        <div 
                          className="absolute top-4 bg-slate-900/95 backdrop-blur-sm text-white rounded-lg p-3 shadow-xl border border-slate-700 text-xs w-[170px] pointer-events-none transition-all duration-75 z-40"
                          style={{
                            left: hoveredWeekIdx > 6 ? `${40 + hoveredWeekIdx * 47.2 - 185}px` : `${40 + hoveredWeekIdx * 47.2 + 15}px`
                          }}
                        >
                          <div className="font-extrabold pb-1 border-b border-slate-800 text-indigo-400 flex justify-between">
                            <span>Week {hoveredWeekIdx + 1}</span>
                            <span className="text-[10px] text-slate-400 uppercase font-sans">index %</span>
                          </div>
                          <div className="space-y-1.5 mt-2 font-sans text-[11px]">
                            <div className="flex justify-between items-center">
                              <span className="text-slate-400">Current actual:</span>
                              <span className="font-bold text-white">{plcStats[hoveredWeekIdx].actual}</span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-slate-400">Last Year:</span>
                              <span className="font-bold text-blue-300">{plcStats[hoveredWeekIdx].ly}</span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-slate-400">Mid Target:</span>
                              <span className="font-bold text-slate-300">{plcStats[hoveredWeekIdx].target}</span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-slate-400">Target corridor:</span>
                              <span className="font-bold text-slate-300">{plcStats[hoveredWeekIdx].range}</span>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>

                    {/* Legend keys */}
                    <div className="mt-4 pt-4 border-t border-border flex items-center justify-between text-[11px] text-muted-foreground">
                      <div className="flex flex-wrap gap-4">
                        <span className="flex items-center gap-1.5 font-semibold text-slate-900">
                          <span className="inline-block h-2 w-3.5 bg-black rounded-sm" />
                          Current actual (W1–W5)
                        </span>
                        <span className="flex items-center gap-1.5 font-semibold text-blue-600">
                          <span className="inline-block h-2 w-3.5 bg-blue-600 rounded-sm" />
                          Last Year Actual
                        </span>
                        <span className="flex items-center gap-1.5 font-semibold">
                          <span className="inline-block h-2 w-3.5 border border-dashed border-slate-400 bg-secondary rounded-sm" />
                          Max/Min target corridor
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Advice note block */}
                  <div className="rounded-xl border border-amber-200 bg-amber-50/50 p-5 flex items-start gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
                    <p className="text-sm font-medium text-amber-800 leading-relaxed">
                      {clusterDetails.plc.advice}
                    </p>
                  </div>
                </div>
              )}

              {/* TAB 3: SIMILAR ITEMS */}
              {drawerTab === "similar" && (
                <div className="space-y-6 animate-fade-in">
                  
                  {/* Scores Block */}
                  <div>
                    <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground block mb-3">
                      Similarity attribute weights
                    </span>
                    <div className="flex flex-wrap gap-3">
                      {clusterDetails.similarItems.scores.map((s) => (
                        <div key={s.label} className="rounded-lg border border-border bg-card px-4 py-2.5 text-center flex-1 min-w-[120px]">
                          <span className="text-[10px] text-muted-foreground font-semibold block">{s.label}</span>
                          <span className="font-sans text-base font-bold text-primary mt-1 block">{s.value}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Historical match outcomes table */}
                  <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden">
                    <div className="border-b border-border px-5 py-4 bg-secondary/20">
                      <h4 className="text-sm font-extrabold uppercase tracking-wide">Historical match outcomes</h4>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm text-left">
                        <thead>
                          <tr className="border-b border-border bg-secondary/10 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                            <th className="px-4 py-3">Year</th>
                            <th className="px-4 py-3">Similar product</th>
                            <th className="px-4 py-3">Scores</th>
                            <th className="px-4 py-3">Outcome</th>
                            <th className="px-4 py-3">Note</th>
                          </tr>
                        </thead>
                        <tbody>
                          {clusterDetails.similarItems.table.map((row, i) => (
                            <tr key={i} className="border-b border-border/65 last:border-0 hover:bg-secondary/20">
                              <td className="px-4 py-3.5 font-sans text-xs">{row.year}</td>
                              <td className="px-4 py-3.5 font-bold text-foreground whitespace-nowrap truncate">{row.name}</td>
                              <td className="px-4 py-3.5 whitespace-nowrap"><span className="text-[11px] font-semibold bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded uppercase">{row.scores}</span></td>
                              <td className="px-4 py-3.5 whitespace-nowrap"><span className="text-xs font-bold font-sans text-rose-600">{row.outcome}</span></td>
                              <td className="px-4 py-3.5 text-xs text-muted-foreground">{row.note}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>

                    {/* Table-specific Scores Legend placed directly underneath the table! */}
                    <div className="bg-slate-50 border-t border-border/60 px-5 py-3 text-[11px] text-slate-600 overflow-x-auto scrollbar-none">
                      <div className="flex items-center gap-x-5 whitespace-nowrap min-w-max">
                        <div className="font-extrabold text-slate-850 flex items-center gap-1.5 shrink-0">
                          <Info className="h-4 w-4 text-blue-600" />
                          Scores Legend:
                        </div>
                        <div className="flex items-center gap-1.5 shrink-0">
                          <span className="inline-flex h-4.5 w-4.5 items-center justify-center rounded bg-slate-900 font-extrabold font-mono text-white text-[9.5px]">V</span>
                          <span><strong>Visual Style</strong> similarity match</span>
                        </div>
                        <div className="flex items-center gap-1.5 shrink-0">
                          <span className="inline-flex h-4.5 w-4.5 items-center justify-center rounded bg-slate-900 font-extrabold font-mono text-white text-[9.5px]">M</span>
                          <span><strong>Material & Fiber</strong> attributes match</span>
                        </div>
                        <div className="flex items-center gap-1.5 shrink-0">
                          <span className="inline-flex h-4.5 w-4.5 items-center justify-center rounded bg-slate-900 font-extrabold font-mono text-white text-[9.5px]">P</span>
                          <span><strong>Price Band</strong> matching index</span>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 4: WEATHER */}
              {drawerTab === "weather" && (
                <div className="space-y-6 animate-fade-in">
                  
                  {/* Weather description bullete cards */}
                  <div className="bg-card rounded-xl border border-border p-5 shadow-sm space-y-3">
                    <h4 className="text-sm font-extrabold uppercase tracking-wide text-foreground pb-2 border-b border-border flex items-center gap-2">
                      <CloudSun className="w-4.5 h-4.5 text-indigo-600" />
                      Weather-Adjusted Demand Analysis
                    </h4>
                    <ul className="space-y-3 pt-2">
                      {clusterDetails.weather.bullets.map((b, i) => {
                        const isUp = b.type === "up";
                        return (
                          <li key={i} className="flex items-start gap-2 text-xs leading-relaxed text-slate-700">
                            {isUp ? (
                              <TrendingUp className="w-4.5 h-4.5 text-emerald-600 shrink-0 mt-0.5" />
                            ) : (
                              <TrendingDown className="w-4.5 h-4.5 text-rose-500 shrink-0 mt-0.5" />
                            )}
                            <span>{b.label}</span>
                          </li>
                        );
                      })}
                    </ul>
                  </div>

                  {/* Region table forecast */}
                  <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden">
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm text-left font-sans">
                        <thead>
                          <tr className="border-b border-border bg-secondary/35 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                            <th className="px-4 py-4">Region</th>
                            <th className="px-4 py-4">Forecast</th>
                            <th className="px-4 py-4 text-center">Demand impact</th>
                            <th className="px-4 py-4">Recommendation</th>
                          </tr>
                        </thead>
                        <tbody>
                          {clusterDetails.weather.table.map((row, i) => {
                            const isGreen = row.demandImpact.startsWith("+");
                            const isRed = row.demandImpact.startsWith("-");
                            return (
                              <tr key={i} className="border-b border-border/65 last:border-0 hover:bg-secondary/20">
                                <td className="px-4 py-3.5 font-bold text-foreground">{row.region}</td>
                                <td className="px-4 py-3.5 text-xs font-medium text-slate-700">{row.forecast}</td>
                                <td className={`px-4 py-3.5 font-sans font-bold text-center text-xs ${isGreen ? "text-emerald-600 bg-emerald-50/20" : isRed ? "text-rose-600 bg-rose-50/20" : "text-slate-500"}`}>
                                  {row.demandImpact}
                                </td>
                                <td className="px-4 py-3.5 text-xs">
                                  <span className={`inline-block font-bold rounded-md px-2 py-0.5 ${
                                    row.tone === "green" 
                                      ? "bg-emerald-50 text-emerald-800 border border-emerald-200" 
                                      : row.tone === "red" 
                                      ? "bg-rose-50 text-rose-800 border border-rose-200" 
                                      : "bg-secondary text-slate-600 border border-border"
                                  }`}>
                                    {row.recommendedAction}
                                  </span>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 5: REGIONS */}
              {drawerTab === "regions" && (
                <div className="space-y-6 animate-fade-in">
                  <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden">
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm text-left">
                        <thead>
                          <tr className="border-b border-border bg-secondary/35 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                            <th className="px-4 py-4">Region</th>
                            <th className="px-4 py-4 text-center">Base Alloc.</th>
                            <th className="px-4 py-4 text-center">Rec. Alloc.</th>
                            <th className="px-4 py-4 text-center">Change</th>
                            <th className="px-4 py-4">Reason</th>
                            <th className="px-4 py-4">Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          {clusterDetails.regions.table.map((row, i) => {
                            const isGreen = row.change.startsWith("+");
                            const isRed = row.change.startsWith("-");
                            return (
                              <tr key={i} className="border-b border-border/65 last:border-0 hover:bg-secondary/20">
                                <td className="px-4 py-3.5 font-bold">{row.region}</td>
                                <td className="px-4 py-3.5 text-center font-sans font-bold text-xs">{row.baseAlloc}</td>
                                <td className="px-4 py-3.5 text-center font-sans font-bold text-xs">{row.recAlloc}</td>
                                <td className={`px-4 py-3.5 text-center font-sans font-extrabold text-xs ${isGreen ? "text-emerald-600 bg-emerald-50/15" : isRed ? "text-rose-600 bg-rose-50/15" : "text-slate-500"}`}>
                                  {row.change}
                                </td>
                                <td className="px-4 py-3.5 text-xs text-slate-700 font-semibold whitespace-normal leading-relaxed">
                                  {row.reason}
                                </td>
                                <td className="px-4 py-3.5 text-xs font-semibold whitespace-nowrap">
                                  <span className={`inline-block rounded-md px-2 py-0.5 font-semibold ${
                                    row.tone === "green" 
                                      ? "bg-emerald-50 text-emerald-800 border border-emerald-100" 
                                      : row.tone === "red" 
                                      ? "bg-rose-50 text-rose-800 border border-rose-100" 
                                      : "bg-slate-100 text-slate-800"
                                  }`}>
                                    {row.action}
                                  </span>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 6: INVENTORY */}
              {drawerTab === "inventory" && (
                <div className="space-y-6 animate-fade-in">
                  <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden">
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm text-left">
                        <thead>
                          <tr className="border-b border-border bg-secondary/35 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                            <th className="px-4 py-4">Region</th>
                            <th className="px-4 py-4 text-center">Current Stock</th>
                            <th className="px-4 py-4 text-center">Wkly Velocity</th>
                            <th className="px-4 py-4 text-center">Weeks Cover</th>
                            <th className="px-4 py-4">Risk Level</th>
                            <th className="px-4 py-4">Dynamic Recommendation</th>
                          </tr>
                        </thead>
                        <tbody>
                          {clusterDetails.inventory.table.map((row, i) => (
                            <tr key={i} className="border-b border-border/65 last:border-0 hover:bg-secondary/20">
                              <td className="px-4 py-3.5 font-bold">{row.region}</td>
                              <td className="px-4 py-3.5 text-center font-sans font-bold text-xs">{row.currentStock}</td>
                              <td className="px-4 py-3.5 text-center font-sans font-bold text-xs">{row.weeklyVelocity}</td>
                              <td className="px-4 py-3.5 text-center font-sans font-bold text-xs">{row.weeksCover}</td>
                              <td className="px-4 py-3.5">
                                <span className={`inline-flex whitespace-nowrap rounded-md px-2.5 py-0.5 text-[10px] font-extrabold uppercase ${
                                  row.tone === "red" 
                                    ? "bg-rose-50 text-rose-700 border border-rose-200" 
                                    : row.tone === "orange" 
                                    ? "bg-amber-50 text-amber-700 border border-amber-200 animate-pulse" 
                                    : "bg-emerald-50 text-emerald-700 border border-emerald-200"
                                }`}>
                                  {row.risk}
                                </span>
                              </td>
                              <td className="px-4 py-3.5 text-xs text-slate-800 font-semibold">{row.recommendation}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

            </div>

            {/* Persistent Drawer Action Footer (Optional Explainability Evidence role) */}
            <div className="border-t border-border bg-slate-50 px-6 py-4 flex items-center justify-between shrink-0">
              <button 
                onClick={() => handleExcludeRecommendation(clusterDetails.title)}
                className="px-3.5 py-2 text-xs font-bold uppercase tracking-wider rounded-lg border border-rose-200 text-rose-600 bg-rose-50/40 hover:bg-rose-50 hover:text-rose-700 transition-all cursor-pointer"
              >
                Dismiss Recommendation
              </button>
              <div className="flex items-center gap-2">
                <button 
                  onClick={() => setActiveClusterSlug(null)}
                  className="px-4 py-2 text-xs font-bold uppercase tracking-wider rounded-lg border border-border bg-white text-slate-700 hover:bg-slate-50 transition-all cursor-pointer font-semibold"
                >
                  Close
                </button>
                <button 
                  onClick={() => {
                    navigate({ to: `/demand-opportunity/${clusterDetails.slug}` });
                    setActiveClusterSlug(null);
                  }}
                  className="px-5 py-2 text-xs font-bold uppercase tracking-wider rounded-lg bg-indigo-600 text-white hover:bg-indigo-700 shadow-sm flex items-center gap-1.5 transition-all cursor-pointer font-extrabold"
                >
                  Review styles
                  <ArrowUpRight className="w-4 h-4" />
                </button>
              </div>
            </div>

          </aside>
        </>
      )}

      <HowCalculatedModal open={modalOpen} onClose={() => setModalOpen(false)} />
    </AppShell>
  );
}

export default Index;
