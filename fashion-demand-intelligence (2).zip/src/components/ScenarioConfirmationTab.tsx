import { useState } from "react";
import { createFileRoute, useNavigate } from "@/lib/router-mock";
import { AppShell } from "@/components/AppShell";
import {
  Calendar,
  Download,
  Info,
  ShoppingBag,
  Tag,
  TrendingUp,
  Euro,
  Shield,
  Check,
  X,
  ChevronRight,
  Sparkles,
  Search,
  AlertTriangle,
  MapPin,
} from "lucide-react";
import { GlobalFilters } from "@/components/GlobalFilters";
import {
  adjustedUnits,
  adjustedEuroK,
  includedStylesDelta,
  useScenarioState,
} from "@/lib/scenario-store";
import { plansStore, usePlansState } from "@/lib/plans-store";
import { SaveDialog } from "@/components/SaveDialog";
import { toast } from "sonner";

export const Route = createFileRoute("/scenario-plan")({ component: Page });

const TRACKED_SKUS = ["RT-001-WHT"];
const RT_DEFAULT_INCLUDED = 12;

function fmtK(n: number) {
  return `${(n / 1000).toFixed(1)}K`;
}
function fmtEuroK(n: number) {
  if (n >= 1000) return `€${(n / 1000).toFixed(2)}M`;
  return `€${n}K`;
}

type Row = {
  cluster: string;
  styles: string;
  selMin: number; selMax: number;
  upMinK: number; upMaxK: number;
  reason: string;
  risk: string;
  dot: string;
};

function Page() {
  useScenarioState();
  const plans = usePlansState();
  const navigate = useNavigate();
  const [saveOpen, setSaveOpen] = useState(false);
  const [detailCluster, setDetailCluster] = useState<Row | null>(null);

  const rtDelta = adjustedUnits(600, 900, TRACKED_SKUS);
  const rtOpp = adjustedEuroK(150, 210, TRACKED_SKUS);
  const rtStylesDelta = includedStylesDelta(TRACKED_SKUS);

  const totalDelta = adjustedUnits(3800, 4600, TRACKED_SKUS);
  const totalOpp = adjustedEuroK(1390, 1700, TRACKED_SKUS);
  const includedStyles = 57 + rtStylesDelta;

  const fmtDelta = (min: number, max: number) =>
    min === 0 && max === 0
      ? "No change"
      : `${min >= 0 ? "+" : ""}${fmtK(min)} – ${max >= 0 ? "+" : ""}${fmtK(max)} units`;

  const cards = [
    { icon: ShoppingBag, tone: "text-accent", bg: "bg-[color:var(--signal-blue-bg)]", label: "Included clusters", value: "4 of 8", sub: "priority clusters included", valueClass: "text-foreground" },
    { icon: Tag, tone: "text-accent", bg: "bg-[color:var(--signal-blue-bg)]", label: "Included styles", value: `${includedStyles} of 72`, sub: "selected for scenario", valueClass: "text-foreground" },
    { icon: TrendingUp, tone: "text-[color:var(--signal-green)]", bg: "bg-[color:var(--signal-green-bg)]", label: "Recommended buy increase", value: `${fmtDelta(totalDelta.min, totalDelta.max)}`, sub: "vs. uploaded baseline plan", valueClass: "text-accent" },
    { icon: Euro, tone: "text-[color:var(--signal-purple)]", bg: "bg-[color:var(--signal-purple-bg)]", label: "Expected upside", value: `${fmtEuroK(totalOpp.min)} – ${fmtEuroK(totalOpp.max)}`, sub: "additional sales opportunity", valueClass: "text-[color:var(--signal-purple)]" },
  ];

  const fmtUnitsK = (min: number, max: number) =>
    min === 0 && max === 0
      ? "No change"
      : `${min >= 0 ? "+" : ""}${fmtK(min)} – ${max >= 0 ? "+" : ""}${fmtK(max)} units`;

  const rows: Row[] = [
    {
      cluster: "Ribbed Tanks",
      styles: `${RT_DEFAULT_INCLUDED + rtStylesDelta} of 15`,
      selMin: rtDelta.min, selMax: rtDelta.max,
      upMinK: rtOpp.min, upMaxK: rtOpp.max,
      reason: "Similar SS24 item performance + stockout risk",
      risk: "Early stockout",
      dot: "bg-accent",
    },
    { cluster: "Linen Shirts", styles: "14 of 18", selMin: 800, selMax: 1000, upMinK: 310, upMaxK: 390, reason: "Early sell-through + search uplift", risk: "Low cover", dot: "bg-[color:var(--signal-blue)]" },
    { cluster: "Lightweight Dresses", styles: "16 of 20", selMin: 600, selMax: 800, upMinK: 240, upMaxK: 310, reason: "Weather-sensitive demand", risk: "Weather-driven missed demand", dot: "bg-[color:var(--signal-amber)]" },
    { cluster: "Crochet Tops", styles: "15 of 19", selMin: 500, selMax: 700, upMinK: 150, upMaxK: 210, reason: "Early velocity", risk: "Slow reaction risk", dot: "bg-[color:var(--signal-purple)]" },
    { cluster: "Wide Leg Pants", styles: "10 of 14", selMin: 300, selMax: 500, upMinK: 110, upMaxK: 150, reason: "Regional concentration", risk: "Missed regional demand", dot: "bg-accent" },
  ];

  return (
    <AppShell>
      <GlobalFilters />

      <div className="mt-6 flex items-start justify-between gap-6">
        <h1 className="text-2xl font-semibold tracking-tight text-primary">Scenario Confirmation</h1>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setSaveOpen(true)}
            className="inline-flex items-center gap-2 rounded-md bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground shadow-sm hover:opacity-90"
          >
            {plans.scenarioSaved ? <Check className="h-4 w-4" /> : <Calendar className="h-4 w-4" />}
            {plans.scenarioSaved ? "Scenario Saved" : "Save Scenario"}
          </button>
          <button
            onClick={() => toast("Scenario export ready")}
            className="inline-flex items-center gap-2 rounded-md border border-border bg-card px-5 py-2.5 text-sm font-medium hover:bg-secondary"
          >
            <Download className="h-4 w-4" />
            Export Scenario
          </button>
        </div>
      </div>

      <div className="mt-4 rounded-lg border border-border bg-[color:var(--signal-blue-bg)]/40 px-4 py-3">
        <div className="flex gap-3">
          <Info className="mt-0.5 h-4 w-4 shrink-0 text-accent" />
          <div className="text-sm text-foreground">
            This scenario increases the uploaded <span className="font-semibold">SS25 Spain</span> baseline plan by{" "}
            <span className="font-semibold">
              {fmtDelta(totalDelta.min, totalDelta.max).replace(" units", "")} units
            </span>
            , with expected additional sales opportunity of{" "}
            <span className="font-semibold">
              {fmtEuroK(totalOpp.min)}–{fmtEuroK(totalOpp.max)}
            </span>
            .
            <div className="mt-1 flex items-center gap-1.5 text-xs text-muted-foreground">
              <Shield className="h-3.5 w-3.5" />
              Main risk reduced: early stockout in Seville and Valencia for priority Ribbed Tanks styles.
            </div>
          </div>
        </div>
      </div>

      <div className="mt-5 grid grid-cols-4 gap-4">
        {cards.map((c) => {
          const Icon = c.icon;
          return (
            <div key={c.label} className="rounded-xl border border-border bg-card p-4">
              <div className="flex items-start gap-3">
                <span className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-full ${c.bg}`}>
                  <Icon className={`h-5 w-5 ${c.tone}`} />
                </span>
                <div className="min-w-0">
                  <div className="text-xs text-muted-foreground">{c.label}</div>
                  <div className={`mt-1 text-lg font-semibold leading-tight ${c.valueClass}`}>{c.value}</div>
                  <div className="mt-1 text-[11px] text-muted-foreground">{c.sub}</div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div className="mt-6">
        <div className="mb-1 text-sm font-semibold text-foreground">Scenario Impact Summary</div>
        <div className="mb-3 text-xs text-muted-foreground">
          Review the selected clusters, included styles, buy increase, and expected upside before confirmation.
        </div>
        <div className="overflow-hidden rounded-xl border border-border bg-card">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border bg-secondary/40 text-left text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
                <th className="px-4 py-2.5">Product Cluster</th>
                <th className="px-4 py-2.5">Included Styles</th>
                <th className="px-4 py-2.5">Change vs. Baseline</th>
                <th className="px-4 py-2.5">Expected Upside</th>
                <th className="px-4 py-2.5">Main Reason</th>
                <th className="px-4 py-2.5">Main Risk Reduced</th>
                <th className="px-4 py-2.5 w-8" />
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr
                  key={r.cluster}
                  onClick={() => setDetailCluster(r)}
                  className="group cursor-pointer border-b border-border/60 last:border-0 hover:bg-secondary/40"
                >
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2.5">
                      <span className={`h-2.5 w-2.5 rounded-full ${r.dot}`} />
                      <span className="font-medium text-accent">{r.cluster}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3">{r.styles}</td>
                  <td className="px-4 py-3 text-[color:var(--signal-green)]">{fmtUnitsK(r.selMin, r.selMax)}</td>
                  <td className="px-4 py-3">{`${fmtEuroK(r.upMinK)} – ${fmtEuroK(r.upMaxK)}`}</td>
                  <td className="px-4 py-3 text-foreground">{r.reason}</td>
                  <td className="px-4 py-3 text-foreground">
                    <div className="flex items-center gap-2 text-muted-foreground">
                      <Shield className="h-3.5 w-3.5 text-[color:var(--signal-green)]" />
                      <span className="text-foreground">{r.risk}</span>
                    </div>
                  </td>
                  <td className="px-4 py-3 text-muted-foreground">
                    <ChevronRight className="h-4 w-4 opacity-60 group-hover:opacity-100" />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
      <SaveDialog
        open={saveOpen}
        title="Save scenario"
        fieldLabel="Scenario name"
        helper="Name this scenario so you can reopen or export it later."
        defaultValue={plans.scenarioName}
        saveLabel="Save Scenario"
        onCancel={() => setSaveOpen(false)}
        onSave={(name) => {
          plansStore.saveScenario(name);
          setSaveOpen(false);
          toast("Scenario saved");
        }}
      />

      {detailCluster && (
        <ClusterImpactDrawer
          row={detailCluster}
          onClose={() => setDetailCluster(null)}
          onEditStyles={() => {
            setDetailCluster(null);
            navigate({ to: "/demand-opportunity" });
          }}
        />
      )}
    </AppShell>
  );
}

function ClusterImpactDrawer({
  row,
  onClose,
  onEditStyles,
}: {
  row: Row;
  onClose: () => void;
  onEditStyles: () => void;
}) {
  const keyStyles =
    row.cluster === "Ribbed Tanks"
      ? [
          { sku: "RT-001-WHT", name: "Rib Tank Top", change: "+260 – +390 units" },
          { sku: "RT-002-BEI", name: "Square Neck Rib", change: "+80 – +130 units" },
          { sku: "RT-003-BLK", name: "Rib Racer Tank", change: "+80 – +120 units" },
        ]
      : [
          { sku: "—", name: "Top contributing styles", change: "—" },
        ];

  const evidence =
    row.cluster === "Ribbed Tanks"
      ? [
          { icon: <Sparkles className="h-4 w-4 text-[color:var(--signal-blue)]" />, tone: "bg-[color:var(--signal-blue-bg)]", title: "Similar SS24 item performance", body: "Similar rib styles sold faster than PLC" },
          { icon: <Search className="h-4 w-4 text-[color:var(--signal-green)]" />, tone: "bg-[color:var(--signal-green-bg)]", title: "Search uplift", body: "Demand signal increased in priority regions" },
          { icon: <AlertTriangle className="h-4 w-4 text-[color:var(--signal-rose)]" />, tone: "bg-[color:var(--signal-rose-bg)]", title: "Stockout risk", body: "Low cover risk in Seville and Valencia" },
        ]
      : [
          { icon: <Sparkles className="h-4 w-4 text-[color:var(--signal-blue)]" />, tone: "bg-[color:var(--signal-blue-bg)]", title: row.reason, body: "Primary signal driving inclusion" },
        ];

  return (
    <>
      <div className="fixed inset-0 z-40 bg-black/30 animate-in fade-in" onClick={onClose} />
      <aside className="fixed right-0 top-0 z-50 flex h-full w-[640px] max-w-[95vw] flex-col border-l border-border bg-card shadow-2xl animate-in slide-in-from-right">
        <div className="flex items-start justify-between border-b border-border px-6 py-4">
          <div>
            <h2 className="text-xl font-semibold tracking-tight text-primary">Cluster Impact Detail</h2>
            <div className="mt-1 text-sm font-medium text-accent">{row.cluster}</div>
          </div>
          <button onClick={onClose} className="rounded-md p-1.5 text-muted-foreground hover:bg-secondary">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-6 py-5">
          <div className="grid grid-cols-2 gap-4">
            <Metric label="Included styles" value={row.styles} />
            <Metric label="Change vs. Baseline" value={`${row.selMin > 0 ? "+" : ""}${(row.selMin / 1000).toFixed(1)}K – ${row.selMax > 0 ? "+" : ""}${(row.selMax / 1000).toFixed(1)}K units`} tone="text-[color:var(--signal-green)]" />
            <Metric label="Expected upside" value={`€${row.upMinK}K – €${row.upMaxK}K`} tone="text-[color:var(--signal-purple)]" />
            <Metric label="Main risk reduced" value={row.risk} />
          </div>

          <div className="mt-6">
            <div className="mb-2 text-sm font-semibold">Included key styles</div>
            <div className="overflow-hidden rounded-lg border border-border">
              <table className="w-full text-sm">
                <tbody>
                  {keyStyles.map((s) => (
                    <tr key={s.sku} className="border-b border-border/60 last:border-0">
                      <td className="px-3 py-2 font-medium">{s.sku}</td>
                      <td className="px-3 py-2 text-muted-foreground">{s.name}</td>
                      <td className="px-3 py-2 text-right text-[color:var(--signal-green)]">{s.change}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="mt-6">
            <div className="mb-2 text-sm font-semibold">Why this cluster is included</div>
            <div className="grid grid-cols-1 gap-2 md:grid-cols-3">
              {evidence.map((e) => (
                <div key={e.title} className="rounded-lg border border-border px-3 py-2">
                  <div className="flex items-center gap-2">
                    <span className={`flex h-6 w-6 items-center justify-center rounded-md ${e.tone}`}>{e.icon}</span>
                    <span className="text-xs font-semibold">{e.title}</span>
                  </div>
                  <div className="mt-1 text-xs text-muted-foreground">{e.body}</div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-6">
            <div className="mb-2 text-sm font-semibold">Regional focus</div>
            <div className="flex flex-wrap gap-2">
              {["Seville", "Valencia", "Barcelona"].map((r) => (
                <span key={r} className="inline-flex items-center gap-1.5 rounded-md border border-border bg-secondary/40 px-2.5 py-1 text-xs font-medium">
                  <MapPin className="h-3 w-3 text-muted-foreground" />
                  {r}
                </span>
              ))}
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between gap-3 border-t border-border bg-card px-6 py-3">
          <button onClick={onClose} className="rounded-md border border-border bg-card px-5 py-2 text-sm font-medium hover:bg-secondary">
            Close
          </button>
          <button onClick={onEditStyles} className="inline-flex items-center gap-2 rounded-md bg-primary px-5 py-2 text-sm font-medium text-primary-foreground hover:opacity-90">
            Edit styles
            <ChevronRight className="h-4 w-4" />
          </button>
        </div>
      </aside>
    </>
  );
}

function Metric({ label, value, tone }: { label: string; value: string; tone?: string }) {
  return (
    <div className="rounded-lg border border-border bg-secondary/30 px-3 py-2">
      <div className="text-[11px] uppercase tracking-wide text-muted-foreground">{label}</div>
      <div className={`mt-1 text-sm font-semibold ${tone ?? "text-foreground"}`}>{value}</div>
    </div>
  );
}

export default Page;
