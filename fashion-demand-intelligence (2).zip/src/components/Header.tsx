import React, { useState, useEffect } from 'react';
import { 
  auth, 
  googleProvider, 
  isMockConfig, 
  seedFirestoreDatabase 
} from '../firebase';
import { 
  signInWithPopup, 
  signOut, 
  onAuthStateChanged, 
  User 
} from 'firebase/auth';
import { Database, ShieldCheck, ShieldAlert, LogIn, LogOut, User as UserIcon, RefreshCw, Layers } from 'lucide-react';

export default function Header() {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const [isSeeding, setIsSeeding] = useState(false);
  const [seedSuccess, setSeedSuccess] = useState(false);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setLoading(false);
      
      // Auto-seed if user logs in on real project
      if (currentUser && !isMockConfig) {
        seedFirestoreDatabase();
      }
    });
    return () => unsubscribe();
  }, []);

  const handleSignIn = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
    } catch (e) {
      console.warn('Authentication Popup blocked or canceled. This is expected if inside parent iframe. Custom fallback authentication enabled.');
    }
  };

  const handleSignOut = async () => {
    await signOut(auth);
  };

  const handleManualSeed = async () => {
    setIsSeeding(true);
    await seedFirestoreDatabase();
    setIsSeeding(false);
    setSeedSuccess(true);
    setTimeout(() => setSeedSuccess(false), 3000);
  };

  return (
    <header className="bg-white border-b border-slate-200 text-slate-900 shadow-sm" id="app-header-container">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          {/* Title Branding */}
          <div className="flex items-center space-x-3">
            <div className="bg-indigo-600 p-2 rounded-lg flex items-center justify-center text-white shadow-sm" id="header-logo-badge">
              <Layers className="h-5.5 w-5.5" />
            </div>
            <div>
              <h1 className="text-lg font-extrabold font-sans tracking-tight text-slate-900 flex items-center gap-2">
                Fashion Demand Intelligence
                <span className="text-[10px] font-bold px-1.5 py-0.5 bg-slate-100 text-slate-500 rounded uppercase font-mono tracking-wider border border-slate-200/60">
                  Enterprise SaaS
                </span>
              </h1>
              <p className="text-[11px] text-slate-500 font-sans">Apparel planning, buying allocation, and adaptive in-season simulation</p>
            </div>
          </div>

          {/* Core Controls */}
          <div className="flex flex-wrap items-center gap-2.5">
            {/* Database Status Pill */}
            {isMockConfig ? (
              <div 
                className="flex items-center space-x-1.5 bg-amber-50 border border-amber-200/80 text-amber-850 px-3 py-1.5 rounded-full text-[11px] font-sans font-medium hover:shadow-sm"
                id="db-sandbox-status"
                title="SaaS runs on local memory sandbox before user completes Firebase cloud database provisioning."
              >
                <div className="w-2 h-2 rounded-full bg-amber-500 animate-pulse"></div>
                <span>Simulated Sandbox DB</span>
              </div>
            ) : (
              <div 
                className="flex items-center space-x-1.5 bg-green-50 border border-green-200 text-green-750 px-3 py-1.5 rounded-full text-[11px] font-sans font-medium"
                id="db-live-status"
              >
                <div className="w-2 h-2 rounded-full bg-green-500"></div>
                <span>Cloud Firestore Live</span>
              </div>
            )}

            {/* Manual Seed Action */}
            {!isMockConfig && user && (
              <button
                onClick={handleManualSeed}
                disabled={isSeeding}
                className="flex items-center space-x-1.5 bg-white hover:bg-slate-50 border border-slate-200 text-slate-700 px-3 py-1.5 rounded-lg text-xs font-semibold hover:text-slate-950 transition-all disabled:opacity-50 shadow-sm"
                id="seed-database-button"
              >
                <RefreshCw className={`h-3 w-3 text-slate-550 ${isSeeding ? 'animate-spin' : ''}`} />
                <span>{seedSuccess ? 'Synced!' : 'Sync Demo Data'}</span>
              </button>
            )}

            {/* Auth section */}
            <div className="flex items-center bg-slate-50 border border-slate-200 rounded-xl px-2 py-1" id="auth-actions-interface">
              {loading ? (
                <div className="h-6 w-16 bg-slate-200 animate-pulse rounded"></div>
              ) : user ? (
                <div className="flex items-center space-x-2.5">
                  <div className="flex items-center space-x-2">
                    {user.photoURL ? (
                      <img 
                      src={user.photoURL} 
                        alt="Avatar" 
                        referrerPolicy="no-referrer"
                        className="h-7 w-7 rounded-full border border-slate-300" 
                      />
                    ) : (
                      <div className="h-7 w-7 rounded-full bg-slate-200 flex items-center justify-center text-slate-600 font-bold text-xs">
                        {user.displayName ? user.displayName.split(' ').map(n => n[0]).join('') : 'U'}
                      </div>
                    )}
                    <div className="hidden sm:block text-left">
                      <p className="text-xs font-bold text-slate-800 line-clamp-1 max-w-[120px] leading-tight">{user.displayName || 'Alex Chen'}</p>
                      <p className="text-[10px] text-slate-400 line-clamp-1 max-w-[120px] font-mono leading-none mt-0.5">{user.email}</p>
                    </div>
                  </div>
                  <button
                    onClick={handleSignOut}
                    className="p-1 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-md transition-all"
                    title="Sign Out"
                    id="sign-out-button"
                  >
                    <LogOut className="h-3.5 w-3.5" />
                  </button>
                </div>
              ) : (
                <button
                  onClick={handleSignIn}
                  className="flex items-center space-x-1 px-3 py-1 text-xs font-bold text-indigo-600 hover:text-indigo-700 transition-all font-sans"
                  id="sign-in-button"
                >
                  <LogIn className="h-3.5 w-3.5" />
                  <span>Planner Login</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
