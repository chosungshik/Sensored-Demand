import * as React from "react";
import { useState } from "react";
import { ClipboardList, ChevronDown, Info, TrendingUp, Star, RefreshCw, Download, ChevronLeft, ChevronRight, X, Search, AlertTriangle, MapPin, Save, Users, Check, ArrowUpRight, Award, Activity, CloudSun, TrendingDown, Clock } from "lucide-react";
import { GlobalFilters, ClusterContextChip } from "@/components/GlobalFilters";
import { ribbedTanksStyles, type StyleRow, type ClusterRow } from "@/lib/cockpit-data";
import { drawerDetailsData } from "@/data/drawer-details";
import ribTankWhite from "@/assets/rib-tank-white.jpg";
import { Switch } from "@/components/ui/switch";
import {
  STYLE_REGION_BUY,
  adjustedUnits,
  defaultAdjustment,
  scenarioStore,
  styleContribution,
  fmtChangeRange,
  fmtBuyRange,
  fmtUpsideEuroK,
  useScenarioState,
} from "@/lib/scenario-store";

function DecisionCard({
  icon, iconBg, title, children, subtitle, thumb,
}: { icon: React.ReactNode; iconBg: string; title: string; children: React.ReactNode; subtitle: string; thumb?: React.ReactNode; }) {
  return (
    <div className="flex h-full items-start gap-4 rounded-xl border border-border bg-card p-5 shadow-[var(--shadow-card)]">
      <div className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-full ${iconBg}`}>{icon}</div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
          {title}
          <Info className="h-3.5 w-3.5" />
        </div>
        <div className="mt-1.5 text-xl font-semibold tracking-tight text-primary">{children}</div>
        <div className="mt-1 text-xs text-muted-foreground">{subtitle}</div>
      </div>
      {thumb}
    </div>
  );
}

type DecisionType = "Included in scenario" | "Not included in scenario";
function DecisionPill({ decision }: { decision: DecisionType }) {
  const cls =
    decision === "Included in scenario"
      ? "bg-[color:var(--signal-green-bg)] text-[color:var(--signal-green)]"
      : "bg-secondary text-muted-foreground";
  return <span className={`inline-flex whitespace-nowrap rounded-md px-2.5 py-1 text-xs font-medium ${cls}`}>{decision}</span>;
}

type ConfidenceLevel = "High" | "Medium" | "Low";
function ConfidencePill({ level }: { level: ConfidenceLevel }) {
  const cls =
    level === "High"
      ? "bg-[color:var(--signal-green-bg)] text-[color:var(--signal-green)]"
      : level === "Medium"
      ? "bg-[color:var(--signal-amber-bg)] text-[color:var(--signal-amber)]"
      : "bg-[color:var(--signal-rose-bg)] text-[color:var(--signal-rose)]";
  return <span className={`inline-flex rounded-md px-2.5 py-1 text-xs font-medium ${cls}`}>{level}</span>;
}

function ProductThumb({ color, swatch }: { color: string; swatch: string }) {
  const isStripe = color === "Stripe";
  return (
    <div className="flex h-12 w-12 items-center justify-center rounded-md border border-border bg-secondary/40">
      <svg viewBox="0 0 32 36" className="h-9 w-9" aria-hidden>
        <defs>
          {isStripe && (
            <pattern id="stripe" patternUnits="userSpaceOnUse" width="4" height="4">
              <rect width="4" height="4" fill="#f0ebe0" />
              <rect width="4" height="2" fill="#8a7f6a" />
            </pattern>
          )}
        </defs>
        <path
          d="M8 4 L4 10 L8 12 L8 32 Q8 34 10 34 L22 34 Q24 34 24 32 L24 12 L28 10 L24 4 L20 4 Q20 8 16 8 Q12 8 12 4 Z"
          fill={isStripe ? "url(#stripe)" : swatch}
          stroke="#0a0a0a"
          strokeOpacity="0.15"
          strokeWidth="0.5"
        />
      </svg>
    </div>
  );
}

function StyleThumb({ row }: { row: StyleRow }) {
  if (row.sku === "RT-001-WHT") {
    return (
      <div className="flex h-12 w-12 items-center justify-center overflow-hidden rounded-md border border-border bg-secondary/40">
        <img src={ribTankWhite} alt="Rib Tank Top White" className="h-full w-full object-cover" />
      </div>
    );
  }
  return <ProductThumb color={row.color} swatch={row.swatch} />;
}

function LargeProductThumb({ color, swatch, sku }: { color: string; swatch: string; sku: string }) {
  if (sku === "RT-001-WHT") {
    return (
      <div className="flex h-[120px] w-[100px] shrink-0 items-center justify-center overflow-hidden rounded-md border border-border bg-secondary/40 select-none">
        <img src={ribTankWhite} alt="Rib Tank Top White" className="h-full w-full object-cover" />
      </div>
    );
  }
  const isStripe = color === "Stripe";
  return (
    <div className="flex h-[120px] w-[100px] shrink-0 items-center justify-center overflow-hidden rounded-md border border-border bg-secondary/40 select-none">
      <svg viewBox="0 0 32 36" className="h-20 w-16 animate-pulse-subtle" aria-hidden>
        <defs>
          {isStripe && (
            <pattern id="stripe-lg" patternUnits="userSpaceOnUse" width="6" height="6">
              <rect width="6" height="6" fill="#f0ebe0" />
              <rect width="6" height="3" fill="#8a7f6a" />
            </pattern>
          )}
        </defs>
        <path
          d="M8 4 L4 10 L8 12 L8 32 Q8 34 10 34 L22 34 Q24 34 24 32 L24 12 L28 10 L24 4 L20 4 Q20 8 16 8 Q12 8 12 4 Z"
          fill={isStripe ? "url(#stripe-lg)" : swatch}
          stroke="#000000"
          strokeOpacity="0.2"
          strokeWidth="0.75"
        />
      </svg>
    </div>
  );
}

function ColorChip({ color, swatch }: { color: string; swatch: string }) {
  return (
    <div className="flex items-center gap-2">
      <span className="h-5 w-5 rounded border border-border" style={{ background: swatch }} />
      <span className="text-sm">{color}</span>
    </div>
  );
}

function StyleReviewDrawer({ row, onClose }: { row: StyleRow | null; onClose: () => void }) {
  if (!row) return null;
  return <StyleReviewDrawerContent row={row} onClose={onClose} />;
}

function DemandPill({ level }: { level: "High" | "Medium" | "Low" }) {
  const cls =
    level === "High"
      ? "bg-[color:var(--signal-green-bg)] text-[color:var(--signal-green)]"
      : level === "Medium"
      ? "bg-[color:var(--signal-amber-bg)] text-[color:var(--signal-amber)]"
      : "bg-[color:var(--signal-rose-bg)] text-[color:var(--signal-rose)]";
  return <span className={`inline-flex rounded-md px-2 py-0.5 text-xs font-medium ${cls}`}>{level}</span>;
}

type Region = { name: string; signal: "High" | "Medium" | "Low"; min: number; max: number; reason: string; defaultInclude: boolean };

function StyleReviewDrawerContent({ row, onClose }: { row: StyleRow; onClose: () => void }) {
  const sku = row.sku;
  const scenario = useScenarioState();
  const adj = scenario.adjustments[sku] ?? defaultAdjustment(sku);
  const keepInScenario = adj.keepInScenario;
  const regionInclude = adj.regionInclude;

  const setKeepInScenario = (v: boolean) =>
    scenarioStore.setAdjustment(sku, { ...adj, keepInScenario: v });
  const setRegionInclude = (name: string, v: boolean) =>
    scenarioStore.setAdjustment(sku, {
      ...adj,
      regionInclude: { ...adj.regionInclude, [name]: v },
    });

  const signalByRegion: Record<string, "High" | "Medium" | "Low"> = {
    Seville: "High", Valencia: "High", Barcelona: "Medium", Madrid: "Low", Bilbao: "Low",
  };
  const reasonByRegion: Record<string, string> = {
    Seville: "Strong demand and stockout risk",
    Valencia: "Strong demand and stockout risk",
    Barcelona: "Solid demand potential",
    Madrid: "Lower demand signal",
    Bilbao: "Lower demand signal",
  };
  const regions: Region[] = (STYLE_REGION_BUY[sku] ?? []).map((r) => ({
    name: r.name,
    min: r.min,
    max: r.max,
    defaultInclude: r.defaultInclude,
    signal: signalByRegion[r.name] ?? "Low",
    reason: reasonByRegion[r.name] ?? "",
  }));

  const contrib = styleContribution(sku, adj);
  const currentPlan = 220;

  const evidence = [
    { icon: <Users className="h-4 w-4 text-[color:var(--signal-blue)]" />, tone: "bg-[color:var(--signal-blue-bg)]", title: "Similar item evidence", body: "4 similar SS24 items sold faster than PLC" },
    { icon: <TrendingUp className="h-4 w-4 text-[color:var(--signal-green)]" />, tone: "bg-[color:var(--signal-green-bg)]", title: "Early velocity", body: "Similar items sold 74% of season volume by Week 4" },
    { icon: <Search className="h-4 w-4 text-[color:var(--signal-blue)]" />, tone: "bg-[color:var(--signal-blue-bg)]", title: "Demand signal", body: "Search trend +26% over last 4 weeks" },
    { icon: <AlertTriangle className="h-4 w-4 text-[color:var(--signal-rose)]" />, tone: "bg-[color:var(--signal-rose-bg)]", title: "Inventory risk", body: "Stockout risk concentrated in Seville and Valencia" },
    { icon: <MapPin className="h-4 w-4 text-[color:var(--signal-purple)]" />, tone: "bg-[color:var(--signal-purple-bg)]", title: "Regional concentration", body: "Strongest demand signal in Seville and Valencia" },
  ];

  return (
    <>
      <div className="fixed inset-0 z-40 bg-black/30 animate-in fade-in" onClick={onClose} />
      <aside className="fixed right-0 top-0 z-50 flex h-full w-[640px] max-w-[95vw] flex-col border-l border-border bg-card shadow-2xl animate-in slide-in-from-right text-left">
        <div className="flex items-start justify-between px-6 py-3 border-b border-border text-left">
          <h2 className="text-xl font-semibold tracking-tight text-primary text-left font-sans">Style Review</h2>
          <button onClick={onClose} className="rounded-md p-1.5 text-muted-foreground hover:bg-secondary transition-all">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-6 py-4 text-left">
          {/* Recommendation + decision */}
          <div className="rounded-lg border border-border p-4 text-left">
            <div className="flex items-center gap-1.5 text-sm font-semibold text-left">
              Recommendation <Info className="h-3.5 w-3.5 text-muted-foreground" />
            </div>
            <p className="mt-2 text-sm text-foreground text-left">
              {keepInScenario && (contrib.min > 0 || contrib.max > 0) ? (
                <>
                  Include this style in selected regions and increase buy by{" "}
                  <span className="font-semibold text-[color:var(--signal-green)]">
                    {fmtChangeRange(contrib)}
                  </span>
                </>
              ) : !keepInScenario ? (
                <>Excluded from scenario — no buy change applied.</>
              ) : (
                <>Include this style with no regional buy increase.</>
              )}
            </p>
            <div className="mt-3 flex items-center justify-between rounded-md border border-border bg-secondary/30 px-3 py-2 text-left">
              <div className="flex items-center gap-3 text-left">
                <Switch checked={keepInScenario} onCheckedChange={setKeepInScenario} />
                <span className="text-sm font-medium">Keep style in scenario</span>
              </div>
              <span
                className={`inline-flex rounded-md px-2 py-0.5 text-xs font-medium ${
                  keepInScenario
                    ? "bg-[color:var(--signal-green-bg)] text-[color:var(--signal-green)]"
                    : "bg-[color:var(--signal-rose-bg)] text-[color:var(--signal-rose)]"
                }`}
              >
                {keepInScenario ? "Included" : "Excluded"}
              </span>
            </div>
          </div>

          {/* Product summary */}
          <div className="mt-4 flex gap-4 text-left">
            <LargeProductThumb color={row.color} swatch={row.swatch} sku={row.sku} />
            <dl className="grid flex-1 grid-cols-[140px,1fr] gap-x-5 gap-y-1.5 text-sm self-center text-left">
              <dt className="text-muted-foreground text-left font-medium">SKU / Product Code</dt>
              <dd className="font-semibold text-foreground text-left font-mono">{row.sku}</dd>
              
              <dt className="text-muted-foreground text-left font-medium">Style</dt>
              <dd className="font-semibold text-foreground text-left">{row.style}</dd>
              
              <dt className="text-muted-foreground text-left font-medium">Color</dt>
              <dd className="text-left flex items-center justify-start"><ColorChip color={row.color} swatch={row.swatch} /></dd>
              
              <dt className="text-muted-foreground text-left font-medium">Product Cluster</dt>
              <dd className="font-semibold text-foreground text-left">Ribbed Tanks</dd>
              
              <dt className="text-muted-foreground text-left font-medium">Category</dt>
              <dd className="font-semibold text-foreground text-left">Tops</dd>
            </dl>
          </div>

          {/* Compact change metrics */}
          <div className="mt-4 grid grid-cols-4 gap-2 rounded-lg border border-border px-4 py-3">
            {[
              { k: "Current plan", v: `${currentPlan}`, u: "units" },
              { k: "Recommended buy", v: fmtBuyRange(currentPlan, contrib), u: "units" },
              {
                k: "Change",
                v: contrib.min === 0 && contrib.max === 0
                  ? "0"
                  : `+${contrib.min} – +${contrib.max}`,
                u: "units",
                tone:
                  contrib.min === 0 && contrib.max === 0
                    ? "text-muted-foreground"
                    : "text-[color:var(--signal-green)]",
              },
              { k: "Expected upside", v: fmtUpsideEuroK(contrib), u: "EUR" },
            ].map((m) => (
              <div key={m.k}>
                <div className="text-xs text-muted-foreground">{m.k}</div>
                <div className={`mt-0.5 text-sm font-semibold ${m.tone ?? ""}`}>{m.v}</div>
                <div className="text-xs text-muted-foreground">{m.u}</div>
              </div>
            ))}
          </div>

          {/* Why this style is recommended */}
          <div className="mt-4">
            <div className="mb-2 flex items-center gap-1.5 text-sm font-semibold">
              Why this style is recommended <Info className="h-3.5 w-3.5 text-muted-foreground" />
            </div>
            <div className="grid grid-cols-2 gap-2">
              {evidence.map((e) => (
                <div key={e.title} className="rounded-lg border border-border px-3 py-2">
                  <div className="flex items-center gap-2">
                    <span className={`flex h-6 w-6 items-center justify-center rounded-md ${e.tone}`}>{e.icon}</span>
                    <span className="text-xs font-semibold text-foreground">{e.title}</span>
                  </div>
                  <div className="mt-1 text-xs text-muted-foreground">{e.body}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Where to include */}
          <div className="mt-4">
            <div className="flex items-center gap-1.5 text-sm font-semibold">
              Where to include <Info className="h-3.5 w-3.5 text-muted-foreground" />
            </div>
            <div className="mt-2 overflow-hidden rounded-lg border border-border">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border bg-secondary/30 text-center text-xs font-medium text-muted-foreground">
                    <th className="px-3 py-1.5 text-center">Region</th>
                    <th className="px-3 py-1.5 text-center">Demand signal</th>
                    <th className="px-3 py-1.5 text-center">Recommended Change</th>
                    <th className="px-3 py-1.5 text-center">Why it matters</th>
                    <th className="px-3 py-1.5 text-center">Include</th>
                  </tr>
                </thead>
                <tbody>
                  {regions.map((r) => (
                    <tr key={r.name} className="border-b border-border/60 last:border-0">
                      <td className="px-3 py-2 font-medium">{r.name}</td>
                      <td className="px-3 py-2"><DemandPill level={r.signal} /></td>
                      <td className="px-3 py-2 whitespace-nowrap">
                        {r.min === 0 && r.max === 0 ? `0 – ${r.max} units` : `+${r.min} – +${r.max} units`}
                      </td>
                      <td className="px-3 py-2 text-muted-foreground">{r.reason}</td>
                      <td className="px-3 py-2">
                        <div className="flex justify-center">
                          <Switch
                            checked={keepInScenario && regionInclude[r.name]}
                            onCheckedChange={(v) => setRegionInclude(r.name, v)}
                            disabled={!keepInScenario}
                          />
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between gap-3 border-t border-border px-6 py-3 bg-card">
          <button onClick={onClose} className="rounded-md border border-border bg-card px-5 py-2 text-sm font-medium hover:bg-secondary">
            Cancel
          </button>
          <button onClick={onClose} className="inline-flex items-center gap-2 rounded-md bg-primary px-5 py-2 text-sm font-medium text-primary-foreground hover:opacity-90">
            <Save className="h-4 w-4" />
            Save style decision
          </button>
        </div>
      </aside>
    </>
  );
}

function parseBaseVsRec(str: string) {
  const parts = str.split("->");
  if (parts.length < 2) return { base: "N/A", rec: "N/A", diff: "", pct: "" };
  const base = parts[0].trim();
  const rest = parts[1].trim(); 
  const rec = rest.split("(")[0].trim();
  
  let diff = "";
  let pct = "";
  const match = rest.match(/\(\+([\d,]+)\s*units\s*\(([\d.’%]+)\)\)/);
  if (match) {
    diff = "+" + match[1];
    pct = match[2];
  } else {
    const simpleMatch = rest.match(/\(([^)]+)\)/);
    if (simpleMatch) {
      const inside = simpleMatch[1]; 
      const subParts = inside.split("(");
      diff = subParts[0].replace("units", "").trim();
      pct = subParts[1] ? subParts[1].replace(")", "").trim() : "";
    }
  }
  return { base, rec, diff, pct };
}

export function DemandOpportunityPage({ cluster }: { cluster: ClusterRow }) {
  const [reviewRow, setReviewRow] = useState<StyleRow | null>(null);
  const [showClusterDetails, setShowClusterDetails] = useState(false);
  const [clusterDrawerTab, setClusterDrawerTab] = useState<"overview" | "plc" | "similar" | "weather" | "regions" | "inventory">("overview");
  const [hoveredWeekIdxOnCluster, setHoveredWeekIdxOnCluster] = useState<number | null>(null);

  const scenario = useScenarioState();

  const clusterDetails = drawerDetailsData[cluster.slug || "ribbed-tanks"];
  const { base: drawerBase, rec: drawerRec, diff: drawerDiff, pct: drawerPct } = clusterDetails 
    ? parseBaseVsRec(clusterDetails.baseVsRecommended) 
    : { base: "N/A", rec: "N/A", diff: "", pct: "" };

  // Buy increase KPI reflects scenario adjustments for Ribbed Tanks (the
  // cluster with per-style toggles wired). Other clusters stay static.
  const isRibbedTanks = cluster.cluster === "Ribbed Tanks";
  const baseMin = isRibbedTanks ? 1200 : 0;
  const baseMax = isRibbedTanks ? 1600 : 0;
  const buy = isRibbedTanks
    ? adjustedUnits(baseMin, baseMax, ["RT-001-WHT"])
    : { min: baseMin, max: baseMax };
  const fmtK = (n: number) => `${(n / 1000).toFixed(1)}K`;
  const buyIncreaseLabel = isRibbedTanks
    ? `+${fmtK(buy.min)} – +${fmtK(buy.max)} units`
    : "+1.2K – +1.6K units";

  type DisplayRow = {
    base: StyleRow;
    change: string;
    evidence: string;
    where: string;
    confidence: ConfidenceLevel;
  };

  const rows: DisplayRow[] = [
    { base: ribbedTanksStyles[0], change: "+260 – +390 units", evidence: "4 similar SS24 styles sold faster than PLC", where: "Seville, Valencia, Barcelona", confidence: "High" },
    { base: ribbedTanksStyles[1], change: "+80 – +130 units", evidence: "Fast early sell-through in SS24", where: "Seville", confidence: "High" },
    { base: ribbedTanksStyles[2], change: "+80 – +120 units", evidence: "Positive PLC signal, weaker regional signal", where: "Valencia-led", confidence: "Medium" },
    { base: ribbedTanksStyles[3], change: "+60 – +100 units", evidence: "Moderate similarity evidence", where: "Spain selected regions", confidence: "Medium" },
    { base: ribbedTanksStyles[5], change: "No increase", evidence: "Weak similarity and demand signal", where: "Limited focus", confidence: "Low" },
  ];

  const decisionFor = (sku: string): DecisionType => {
    const adj = scenario.adjustments[sku];
    if (adj && !adj.keepInScenario) return "Not included in scenario";
    return "Included in scenario";
  };

  return (
    <>
      <GlobalFilters />

      <div className="mb-5 flex items-start justify-between">
        <div>
          <ClusterContextChip cluster={cluster.cluster} />
          <h1 className="text-2xl font-semibold tracking-tight text-primary">Style Selection</h1>
        </div>
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <span>Last updated: May 20, 2025 09:30 AM</span>
          <RefreshCw className="h-3.5 w-3.5" />
        </div>
      </div>

      {/* Product Cluster Context Summary & Optional Drawer Access */}
      <div className="mb-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 rounded-xl border border-indigo-150 bg-indigo-50/20 px-5 py-4">
        <div className="flex items-start gap-3">
          <Info className="mt-0.5 h-5 w-5 shrink-0 text-indigo-600" />
          <div>
            <div className="text-sm font-semibold text-indigo-950">
              Why is {cluster.cluster} recommended?
            </div>
            <p className="mt-1 text-xs text-indigo-805 leading-relaxed max-w-2xl">
              {cluster.cluster === "Ribbed Tanks"
                ? "Ribbed Tanks recommended buy increase of +1.2K – +1.6K units is backed by similar SS24 overperformance, rapid early-season sell-through, and regional stockout risks in Andalusian stores."
                : `${cluster.cluster} is recommended for a buy increase driven by rolling PLC sales profiles, regional demand signals, and external demand surges.`}
            </p>
          </div>
        </div>
        <button
          onClick={() => {
            setShowClusterDetails(true);
            setClusterDrawerTab("overview");
          }}
          className="inline-flex items-center gap-1.5 whitespace-nowrap rounded-lg border border-indigo-200 bg-white px-3.5 py-2 text-xs font-bold text-indigo-700 shadow-sm hover:bg-indigo-50/80 transition-all cursor-pointer"
        >
          Why this recommendation? (View Evidence)
          <ArrowUpRight className="h-3.5 w-3.5" />
        </button>
      </div>

      <div className="grid grid-cols-1 gap-5 md:grid-cols-3">
        <DecisionCard
          icon={<ClipboardList className="h-6 w-6 text-accent" />}
          iconBg="bg-[color:var(--signal-blue-bg)]"
          title="Recommended style decisions"
          subtitle="Included / not included in scenario"
        >
          <span>18 style decisions</span>
        </DecisionCard>
        <DecisionCard
          icon={<TrendingUp className="h-6 w-6 text-[color:var(--signal-green)]" />}
          iconBg="bg-[color:var(--signal-green-bg)]"
          title="Recommended buy increase"
          subtitle="vs. current plan"
        >
          <span className="text-[color:var(--signal-green)]">{buyIncreaseLabel}</span>
        </DecisionCard>
        <DecisionCard
          icon={<Star className="h-6 w-6 text-[color:var(--signal-purple)]" />}
          iconBg="bg-[color:var(--signal-purple-bg)]"
          title="Highest priority style"
          subtitle={""}
          thumb={
            <div className="ml-2 hidden h-16 w-14 shrink-0 overflow-hidden rounded-md border border-border bg-secondary/40 lg:block">
              <img src={ribTankWhite} alt="Rib Tank Top White" className="h-full w-full object-cover" />
            </div>
          }
        >
          <div className="leading-snug">Rib Tank Top <span className="text-muted-foreground">White</span></div>
          <div className="mt-1 text-xs font-medium text-[color:var(--signal-green)]">+260 – +390 units recommended</div>
        </DecisionCard>
      </div>

      <section className="mt-6 rounded-xl border border-border bg-card shadow-[var(--shadow-card)]">
        <div className="flex items-start justify-between border-b border-border px-6 py-5">
          <div className="flex items-center gap-3">
            <h2 className="text-base font-semibold">Style Decision List</h2>
            <span className="rounded-md bg-secondary px-2 py-0.5 text-xs font-medium text-muted-foreground">18 styles</span>
          </div>
          <div className="flex items-center gap-2">
            <button className="flex items-center gap-2 rounded-md border border-border bg-card px-3 py-1.5 text-sm font-medium hover:bg-secondary">
              Columns
              <ChevronDown className="h-4 w-4 text-muted-foreground" />
            </button>
            <button className="flex items-center gap-2 rounded-md border border-border bg-card px-3 py-1.5 text-sm font-medium hover:bg-secondary">
              <Download className="h-4 w-4" />
              Export
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border text-center text-xs font-medium text-muted-foreground">
                <th className="px-6 py-3 text-center">Decision</th>
                <th className="px-3 py-3 text-center">Product</th>
                <th className="px-3 py-3 text-center">SKU / Product Code</th>
                <th className="px-3 py-3 text-center">Style</th>
                <th className="px-3 py-3 text-center">Recommended Change<div className="text-[10px] font-normal text-muted-foreground/70">vs. current plan</div></th>
                <th className="px-3 py-3 text-center">Similar SS24 Evidence</th>
                <th className="px-3 py-3 text-center">Where to include</th>
                <th className="px-3 py-3 text-center">Confidence</th>
                <th className="px-3 py-3 text-center">Action</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => {
                const row = r.base;
                const isNoChange = r.change === "No increase";
                return (
                  <tr
                    key={row.sku}
                    onClick={() => setReviewRow(row)}
                    className="group h-[80px] cursor-pointer border-b border-border/60 last:border-0 hover:bg-secondary/40"
                  >
                    <td className="px-6 py-4 align-middle text-center"><DecisionPill decision={decisionFor(row.sku)} /></td>
                    <td className="px-3 py-4 align-middle text-center"><StyleThumb row={row} /></td>
                    <td className="px-3 py-4 align-middle text-center font-medium whitespace-nowrap">{row.sku}</td>
                    <td className="px-3 py-4 align-middle text-center whitespace-nowrap">{row.style}</td>
                    <td className={`px-3 py-4 align-middle text-center font-medium whitespace-nowrap ${isNoChange ? "text-muted-foreground" : "text-[color:var(--signal-green)]"}`}>{r.change}</td>
                    <td className="px-3 py-4 align-middle text-sm text-foreground">{r.evidence}</td>
                    <td className="px-3 py-4 align-middle text-center text-sm">{r.where}</td>
                    <td className="px-3 py-4 align-middle"><ConfidencePill level={r.confidence} /></td>
                    <td className="px-3 py-4 align-middle text-center">
                      <button
                        onClick={(e) => { e.stopPropagation(); setReviewRow(row); }}
                        className="inline-flex items-center gap-1 whitespace-nowrap rounded-md border border-accent/40 bg-card px-3 py-1.5 text-xs font-medium text-accent hover:bg-[color:var(--signal-blue-bg)]"
                      >
                        Review
                        <ChevronRight className="h-3.5 w-3.5" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <div className="flex items-center justify-between border-t border-border px-6 py-3 text-xs text-muted-foreground">
          <span>Showing 1 to {rows.length} of 18 styles</span>
          <div className="flex items-center gap-2">
            <button className="flex items-center gap-1 rounded-md border border-border bg-card px-2 py-1 hover:bg-secondary">
              25 per page <ChevronDown className="h-3 w-3" />
            </button>
            <button className="rounded-md border border-border p-1 hover:bg-secondary"><ChevronLeft className="h-3.5 w-3.5" /></button>
            <span className="rounded-md border border-accent/40 bg-card px-2 py-0.5 text-accent">1</span>
            <button className="rounded-md border border-border p-1 hover:bg-secondary"><ChevronRight className="h-3.5 w-3.5" /></button>
          </div>
        </div>
      </section>

      <StyleReviewDrawer row={reviewRow} onClose={() => setReviewRow(null)} />

      {/* Cluster Evidence Drawer */}
      {showClusterDetails && clusterDetails && (
        <>
          <div 
            className="fixed inset-0 z-40 bg-black/40 animate-in fade-in cursor-pointer" 
            onClick={() => setShowClusterDetails(false)} 
          />
          <aside className="fixed right-0 top-0 z-50 flex h-full w-[820px] max-w-[95vw] flex-col border-l border-border bg-card shadow-2xl animate-in slide-in-from-right font-sans text-left text-slate-900">
            
            {/* Drawer Header Block */}
            <div className="bg-secondary/20 border-b border-border p-6 text-left">
              <div className="flex items-start justify-between">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="text-[10px] uppercase font-extrabold tracking-widest bg-indigo-50 border border-indigo-200 px-2 py-0.5 rounded text-indigo-700">
                      Recommendation Evidence
                    </span>
                    <span className="flex items-center gap-1.5 text-xs font-medium text-emerald-600">
                      <Clock className="w-3.5 h-3.5" />
                      Live Data updated
                    </span>
                  </div>
                  <div className="mt-2 text-xs font-extrabold text-slate-400 uppercase tracking-wider">
                    Why is this cluster recommended?
                  </div>
                  <h2 className="text-2xl font-extrabold tracking-tight text-slate-900 mt-1">{clusterDetails.title}</h2>
                </div>
                <button 
                  onClick={() => setShowClusterDetails(false)} 
                  className="rounded-md p-1.5 text-muted-foreground hover:bg-secondary hover:text-foreground transition-all"
                >
                  <X className="h-5.5 w-5.5" />
                </button>
              </div>

              {/* Primary KPIs Block */}
              <div className="mt-5 grid grid-cols-1 md:grid-cols-3 gap-4 bg-card rounded-xl border border-border/80 p-4.5 shadow-sm text-left">
                
                {/* Base vs Recommended */}
                <div className="rounded-2xl bg-slate-50/50 border border-slate-100 p-5 flex flex-col justify-between text-left">
                  <div>
                    <span className="text-[10px] uppercase font-bold tracking-widest text-[#5c6883] block">
                      Base vs Recommended
                    </span>
                    <div className="flex items-center gap-4 mt-2.5">
                      <span className="font-sans text-2xl font-semibold text-slate-400/80 line-through tracking-tight">
                        {drawerBase}
                      </span>
                      <span className="font-sans text-3.5xl font-extrabold text-[#111928] tracking-tight">
                        {drawerRec}
                      </span>
                    </div>
                  </div>
                  <div className="mt-2.5">
                    <span className="text-sm font-extrabold text-[#2e7d32] font-sans block">
                      {drawerDiff} units ({drawerPct})
                    </span>
                  </div>
                </div>

                {/* Confidence Card */}
                <div className="rounded-2xl bg-neutral-50/50 border border-border/60 p-5 h-full flex flex-col justify-center text-left">
                  <span className="text-[9px] text-muted-foreground font-bold uppercase tracking-widest block">Confidence Level</span>
                  <span className="font-sans text-sm font-extrabold mt-1.5 flex items-center gap-1.5">
                    <span className="h-2.5 w-2.5 rounded-full bg-[color:var(--signal-green)] animate-pulse" />
                    <span className="text-[color:var(--signal-green)]">
                      {clusterDetails.confidence}
                    </span>
                  </span>
                </div>

                {/* Strategic Purpose Card */}
                <div className="rounded-2xl bg-neutral-50/50 border border-border/60 p-5 h-full flex flex-col justify-center text-left">
                  <span className="text-[9px] text-muted-foreground font-bold uppercase tracking-widest block">Strategic Objective</span>
                  <span className="text-xs font-bold text-slate-800 mt-1.5 block leading-tight">{clusterDetails.decisionType}</span>
                </div>

              </div>
            </div>

            {/* Cabinet Navigation Tabs */}
            <div className="border-b border-border px-6 bg-card sticky top-0 z-10 text-left">
              <nav className="flex gap-6 overflow-x-auto scrollbar-none">
                {[
                  { id: "overview", label: "Summary" },
                  { id: "plc", label: "Sales Signal" },
                  { id: "similar", label: "Similar Items" },
                  { id: "weather", label: "External Demand" },
                  { id: "regions", label: "Regional Focus" },
                  { id: "inventory", label: "Stock Risk" },
                ].map((t) => {
                  const isActive = clusterDrawerTab === t.id;
                  return (
                    <button
                      key={t.id}
                      onClick={() => setClusterDrawerTab(t.id as any)}
                      className={`border-b-2 py-3.5 text-sm font-semibold whitespace-nowrap transition-all uppercase tracking-wide cursor-pointer ${
                        isActive 
                          ? "border-accent text-accent font-extrabold" 
                          : "border-transparent text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      {t.label}
                    </button>
                  );
                })}
              </nav>
            </div>

            {/* Cabinet Content Body */}
            <div className="flex-1 overflow-y-auto p-6 space-y-6 text-left">

              {/* TAB 1: OVERVIEW */}
              {clusterDrawerTab === "overview" && (
                <div className="space-y-6 animate-fade-in text-left">
                  <div className="rounded-xl border border-border bg-card p-6 shadow-sm text-left">
                    <h3 className="text-sm font-extrabold uppercase tracking-wide text-foreground pb-2 border-b border-border flex items-center gap-1.5">
                      <Award className="w-4.5 h-4.5 text-accent" />
                      Final AI Recommendation
                    </h3>
                    <p className="mt-4 text-sm leading-relaxed text-slate-800">
                      {clusterDetails.overview.text}
                    </p>
                    <ul className="mt-4 space-y-3">
                      {clusterDetails.overview.bullets.map((b, i) => (
                        <li key={i} className="flex items-start gap-2.5 text-xs text-slate-600 leading-relaxed">
                          <span className="h-1.5 w-1.5 rounded-full bg-accent mt-1.5 shrink-0" />
                          <span>{b}</span>
                        </li>
                      ))}
                    </ul>

                    {/* DECISION IMPACT ESTIMATE BANNER */}
                    <div className="mt-6 rounded-lg bg-indigo-50/60 border border-indigo-100 p-4 shrink-0">
                      <span className="text-[10px] text-indigo-800 font-bold uppercase tracking-widest block">
                        Estimated Decision Impact
                      </span>
                      <div className="text-[14px] font-mono font-extrabold text-indigo-950 mt-1 flex items-center gap-2">
                        <span>{clusterDetails.overview.benefit}</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 2: PLC */}
              {clusterDrawerTab === "plc" && (
                <div className="space-y-6 animate-fade-in text-left">
                  <div className="bg-card rounded-xl border border-border p-6 shadow-sm">
                    <div className="flex justify-between items-start pb-4 border-b border-border">
                      <div>
                        <h3 className="text-sm font-extrabold uppercase tracking-wide text-foreground">
                          Product Life Cycle & Weekly Sales Profile (Bell Curve)
                        </h3>
                        <p className="text-xs text-muted-foreground mt-0.5">Rolling 12-week lifecycle index profile bounds</p>
                      </div>
                      <span className="bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-bold rounded-full px-2.5 py-0.5 flex items-center gap-1.5 uppercase">
                        <Activity className="h-3 w-3" />
                        Proper PLC Bell Curve
                      </span>
                    </div>

                    {/* PLC Line Graph SVG */}
                    <div className="h-56 w-full relative pt-4">
                      <svg className="h-full w-full" viewBox="0 0 600 180" fill="none">
                        
                        <line x1="40" y1="20" x2="560" y2="20" stroke="hsl(var(--border))" strokeOpacity="0.4" strokeDasharray="3 3" />
                        <line x1="40" y1="55" x2="560" y2="55" stroke="hsl(var(--border))" strokeOpacity="0.4" strokeDasharray="3 3" />
                        <line x1="40" y1="90" x2="560" y2="90" stroke="hsl(var(--border))" strokeOpacity="0.4" strokeDasharray="3 3" />
                        <line x1="40" y1="125" x2="560" y2="125" stroke="hsl(var(--border))" strokeOpacity="0.4" strokeDasharray="3 3" />
                        <line x1="40" y1="160" x2="560" y2="160" stroke="hsl(var(--border))" strokeOpacity="0.8" />

                        <text x="5" y="24" fill="#94a3b8" className="text-[10px] font-sans font-semibold">100%</text>
                        <text x="5" y="59" fill="#94a3b8" className="text-[10px] font-sans font-semibold">75%</text>
                        <text x="5" y="94" fill="#94a3b8" className="text-[10px] font-sans font-semibold">50%</text>
                        <text x="5" y="129" fill="#94a3b8" className="text-[10px] font-sans font-semibold">25%</text>
                        <text x="5" y="164" fill="#94a3b8" className="text-[10px] font-sans font-semibold">0%</text>

                        <path d="M 40 142 C 160 110, 200 20, 280 20 C 360 20, 420 110, 560 142" stroke="#94a3b8" strokeWidth="1.5" strokeDasharray="4 4" />
                        <text x="490" y="122" fill="#94a3b8" className="text-[9px] font-sans">Max bound</text>

                        <path d="M 40 152 C 160 135, 200 75, 280 75 C 360 75, 420 135, 560 152" stroke="#cbd5e1" strokeWidth="1.5" strokeDasharray="4 4" />
                        <text x="490" y="148" fill="#cbd5e1" className="text-[9px] font-sans">Min bound</text>

                        <path d="M 40 147 C 160 120, 200 45, 280 45 C 360 45, 420 120, 560 147" stroke="#94a3b8" strokeWidth="1.5" strokeDasharray="4 4" />
                        <text x="490" y="135" fill="#94a3b8" className="text-[9px] font-sans">Mid target</text>

                        <path d="M 40 149 C 150 128, 195 50, 275 50 C 355 50, 415 128, 560 149" stroke="#2563eb" strokeWidth="2.5" />
                        <path d="M 40 146 C 90 135, 140 92, 230 55" stroke="#000000" strokeWidth="4" strokeLinecap="round" />

                        <line x1="230" y1="20" x2="230" y2="160" stroke="#ef4444" strokeWidth="1.5" strokeDasharray="3 3" />
                        <text x="235" y="32" fill="#ef4444" className="text-[10px] font-bold font-sans">W5: Warm shift begins</text>

                        <line x1="380" y1="20" x2="380" y2="160" stroke="#f97316" strokeWidth="1.5" strokeDasharray="3 3" />
                        <text x="385" y="45" fill="#f97316" className="text-[10px] font-bold font-sans">W8: Risk window</text>

                        {["W1", "W2", "W3", "W4", "W5", "W6", "W7", "W8", "W9", "W10", "W11", "W12"].map((w, idx) => (
                          <text key={w} x={40 + idx * 47.2} y="176" fill="#94a3b8" className="text-[9px] font-bold text-center font-sans">{w}</text>
                        ))}
                      </svg>
                    </div>
                  </div>

                  <div className="rounded-xl border border-amber-200 bg-amber-50/50 p-5 flex items-start gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-600 shrink-0 mt-0.5" />
                    <p className="text-sm font-medium text-amber-800 leading-relaxed text-left">
                      {clusterDetails.plc.advice}
                    </p>
                  </div>
                </div>
              )}

              {/* TAB 3: SIMILAR ITEMS */}
              {clusterDrawerTab === "similar" && (
                <div className="space-y-6 animate-fade-in text-left">
                  <div>
                    <span className="text-xs font-bold uppercase tracking-wider text-muted-foreground block mb-3">
                      Similarity attribute weights
                    </span>
                    <div className="flex flex-wrap gap-3">
                      {clusterDetails.similarItems.scores.map((s) => (
                        <div key={s.label} className="rounded-lg border border-border bg-card px-4 py-2.5 text-center flex-1 min-w-[120px]">
                          <span className="text-[10px] text-muted-foreground font-semibold block">{s.label}</span>
                          <span className="font-sans text-base font-bold text-primary mt-1 block">{s.value}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden text-left">
                    <div className="border-b border-border px-5 py-4 bg-secondary/20">
                      <h4 className="text-sm font-extrabold uppercase tracking-wide">Historical match outcomes</h4>
                    </div>
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm text-left">
                        <thead>
                          <tr className="border-b border-border bg-secondary/10 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                            <th className="px-4 py-3">Year</th>
                            <th className="px-4 py-3">Similar product</th>
                            <th className="px-4 py-3">Scores</th>
                            <th className="px-4 py-3">Outcome</th>
                            <th className="px-4 py-3">Note</th>
                          </tr>
                        </thead>
                        <tbody>
                          {clusterDetails.similarItems.table.map((row, i) => (
                            <tr key={i} className="border-b border-border/65 last:border-0 hover:bg-secondary/20">
                              <td className="px-4 py-3.5 font-sans text-xs">{row.year}</td>
                              <td className="px-4 py-3.5 font-bold text-foreground whitespace-nowrap truncate">{row.name}</td>
                              <td className="px-4 py-3.5 whitespace-nowrap"><span className="text-[11px] font-semibold bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded uppercase">{row.scores}</span></td>
                              <td className="px-4 py-3.5 whitespace-nowrap"><span className="text-xs font-bold font-sans text-rose-600">{row.outcome}</span></td>
                              <td className="px-4 py-3.5 text-xs text-muted-foreground">{row.note}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 4: WEATHER */}
              {clusterDrawerTab === "weather" && (
                <div className="space-y-6 animate-fade-in text-left">
                  <div className="bg-card rounded-xl border border-border p-5 shadow-sm space-y-3">
                    <h4 className="text-sm font-extrabold uppercase tracking-wide text-foreground pb-2 border-b border-border flex items-center gap-2">
                      <CloudSun className="w-4.5 h-4.5 text-indigo-600" />
                      Weather-Adjusted Demand Analysis
                    </h4>
                    <ul className="space-y-3 pt-2">
                      {clusterDetails.weather.bullets.map((b, i) => {
                        const isUp = b.type === "up";
                        return (
                          <li key={i} className="flex items-start gap-2 text-xs leading-relaxed text-slate-700 text-left">
                            {isUp ? (
                              <TrendingUp className="w-4.5 h-4.5 text-emerald-600 shrink-0 mt-0.5" />
                            ) : (
                              <TrendingDown className="w-4.5 h-4.5 text-rose-500 shrink-0 mt-0.5" />
                            )}
                            <span>{b.label}</span>
                          </li>
                        );
                      })}
                    </ul>
                  </div>

                  <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden text-left">
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm text-left">
                        <thead>
                          <tr className="border-b border-border bg-secondary/35 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                            <th className="px-4 py-4">Region</th>
                            <th className="px-4 py-4">Forecast</th>
                            <th className="px-4 py-4 text-center">Demand impact</th>
                            <th className="px-4 py-4">Recommendation</th>
                          </tr>
                        </thead>
                        <tbody>
                          {clusterDetails.weather.table.map((row, i) => {
                            const isGreen = row.demandImpact.startsWith("+");
                            const isRed = row.demandImpact.startsWith("-");
                            return (
                              <tr key={i} className="border-b border-border/65 last:border-0 hover:bg-secondary/20">
                                <td className="px-4 py-3.5 font-bold text-foreground">{row.region}</td>
                                <td className="px-4 py-3.5 text-xs font-medium text-slate-700">{row.forecast}</td>
                                <td className={`px-4 py-3.5 font-sans font-bold text-center text-xs ${isGreen ? "text-emerald-600 bg-emerald-50/20" : isRed ? "text-rose-600 bg-rose-50/20" : "text-slate-500"}`}>
                                  {row.demandImpact}
                                </td>
                                <td className="px-4 py-3.5 text-xs">
                                  <span className={`inline-block font-bold rounded-md px-2 py-0.5 ${
                                    row.tone === "green" 
                                      ? "bg-emerald-50 text-emerald-800 border border-emerald-200" 
                                      : row.tone === "red" 
                                      ? "bg-rose-50 text-rose-800 border border-rose-200" 
                                      : "bg-secondary text-slate-600 border border-border"
                                  }`}>
                                    {row.recommendedAction}
                                  </span>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 5: REGIONS */}
              {clusterDrawerTab === "regions" && (
                <div className="space-y-6 animate-fade-in text-left">
                  <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden text-left">
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm text-left">
                        <thead>
                          <tr className="border-b border-border bg-secondary/35 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                            <th className="px-4 py-4">Region</th>
                            <th className="px-4 py-4 text-center">Base Alloc.</th>
                            <th className="px-4 py-4 text-center">Rec. Alloc.</th>
                            <th className="px-4 py-4 text-center">Change</th>
                            <th className="px-4 py-4">Reason</th>
                            <th className="px-4 py-4">Action</th>
                          </tr>
                        </thead>
                        <tbody>
                          {clusterDetails.regions.table.map((row, i) => {
                            const isGreen = row.change.startsWith("+");
                            const isRed = row.change.startsWith("-");
                            return (
                              <tr key={i} className="border-b border-border/65 last:border-0 hover:bg-secondary/20">
                                <td className="px-4 py-3.5 font-bold">{row.region}</td>
                                <td className="px-4 py-3.5 text-center font-sans font-bold text-xs">{row.baseAlloc}</td>
                                <td className="px-4 py-3.5 text-center font-sans font-bold text-xs">{row.recAlloc}</td>
                                <td className={`px-4 py-3.5 text-center font-sans font-extrabold text-xs ${isGreen ? "text-emerald-600 bg-emerald-50/15" : isRed ? "text-rose-600 bg-rose-50/15" : "text-slate-500"}`}>
                                  {row.change}
                                </td>
                                <td className="px-4 py-3.5 text-xs text-slate-700 font-semibold whitespace-normal leading-relaxed text-left">
                                  {row.reason}
                                </td>
                                <td className="px-4 py-3.5 text-xs font-semibold whitespace-nowrap">
                                  <span className={`inline-block rounded-md px-2 py-0.5 font-semibold ${
                                    row.tone === "green" 
                                      ? "bg-emerald-50 text-emerald-800 border border-emerald-100" 
                                      : row.tone === "red" 
                                      ? "bg-rose-50 text-rose-800 border border-rose-100" 
                                      : "bg-slate-100 text-slate-800"
                                  }`}>
                                    {row.action}
                                  </span>
                                </td>
                              </tr>
                            );
                          })}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

              {/* TAB 6: INVENTORY */}
              {clusterDrawerTab === "inventory" && (
                <div className="space-y-6 animate-fade-in text-left">
                  <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden text-left">
                    <div className="overflow-x-auto">
                      <table className="w-full text-sm text-left">
                        <thead>
                          <tr className="border-b border-border bg-secondary/35 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground">
                            <th className="px-4 py-4">Region</th>
                            <th className="px-4 py-4 text-center">Current Stock</th>
                            <th className="px-4 py-4 text-center">Wkly Velocity</th>
                            <th className="px-4 py-4 text-center">Weeks Cover</th>
                            <th className="px-4 py-4">Risk Level</th>
                            <th className="px-4 py-4">Dynamic Recommendation</th>
                          </tr>
                        </thead>
                        <tbody>
                          {clusterDetails.inventory.table.map((row, i) => (
                            <tr key={i} className="border-b border-border/65 last:border-0 hover:bg-secondary/20">
                              <td className="px-4 py-3.5 font-bold">{row.region}</td>
                              <td className="px-4 py-3.5 text-center font-sans font-bold text-xs">{row.currentStock}</td>
                              <td className="px-4 py-3.5 text-center font-sans font-bold text-xs">{row.weeklyVelocity}</td>
                              <td className="px-4 py-3.5 text-center font-sans font-bold text-xs">{row.weeksCover}</td>
                              <td className="px-4 py-3.5">
                                <span className={`inline-flex whitespace-nowrap rounded-md px-2.5 py-0.5 text-[10px] font-extrabold uppercase ${
                                  row.tone === "red" 
                                    ? "bg-rose-50 text-rose-700 border border-rose-200" 
                                    : row.tone === "orange" 
                                    ? "bg-amber-50 text-amber-700 border border-amber-200 animate-pulse" 
                                    : "bg-emerald-50 text-emerald-700 border border-emerald-200"
                                }`}>
                                  {row.risk}
                                </span>
                              </td>
                              <td className="px-4 py-3.5 text-xs text-slate-800 font-semibold text-left">{row.recommendation}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                </div>
              )}

            </div>

            {/* Persistent Drawer Action Footer */}
            <div className="border-t border-border bg-slate-50 px-6 py-4 flex items-center justify-end shrink-0">
              <button 
                onClick={() => setShowClusterDetails(false)}
                className="px-5 py-2 text-xs font-bold uppercase tracking-wider rounded-lg bg-indigo-600 text-white hover:bg-indigo-700 shadow-sm transition-all cursor-pointer font-extrabold"
              >
                Close Evidence
              </button>
            </div>

          </aside>
        </>
      )}
    </>
  );
}