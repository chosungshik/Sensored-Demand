import React, { useState, useEffect } from 'react';
import { clientDB } from '../firebase';
import { Action, ActionPlan } from '../types';
import { 
  Activity, 
  TrendingUp, 
  Send, 
  Trash2, 
  AlertCircle, 
  CheckCircle, 
  ArrowRight, 
  MapPin, 
  Truck,
  DollarSign, 
  Percent, 
  Grid,
  RefreshCw,
  Clock,
  CheckCircle2
} from 'lucide-react';

export default function InSeasonOperationsTab() {
  const [activeSubTab, setActiveSubTab] = useState<'cockpit' | 'actions'>('cockpit');
  const [actions, setActions] = useState<Action[]>([]);
  const [plans, setPlans] = useState<ActionPlan[]>([]);
  const [loading, setLoading] = useState(true);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const loadData = async () => {
    try {
      const dbActions = await clientDB.getActions();
      const dbPlans = await clientDB.getActionPlans();
      if (dbActions) setActions(dbActions);
      if (dbPlans) setPlans(dbPlans);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Action: Send Action Request (Pending -> Sent)
  const handleSendRequest = async (action: Action) => {
    const updatedAction: Action = {
      ...action,
      status: 'Sent'
    };

    // Optimistic UI update
    setActions(actions.map(a => a.id === action.id ? updatedAction : a));

    try {
      await clientDB.updateAction(updatedAction);
      setToastMessage(`Action Request "${action.title}" successfully dispatched to store operators!`);
      setTimeout(() => setToastMessage(null), 3500);
    } catch (e) {
      console.error(e);
      setActions(actions); // revert
      setToastMessage('Failed to update action. Check Firestore permissions.');
      setTimeout(() => setToastMessage(null), 3000);
    }
  };

  // Action: Dismiss Action (Pending / Sent -> Dismissed)
  const handleDismissAction = async (action: Action) => {
    const updatedAction: Action = {
      ...action,
      status: 'Dismissed'
    };

    // Optimistic UI update
    setActions(actions.map(a => a.id === action.id ? updatedAction : a));

    try {
      await clientDB.updateAction(updatedAction);
      setToastMessage(`Action recommendation "${action.title}" has been dismissed.`);
      setTimeout(() => setToastMessage(null), 3500);
    } catch (e) {
      console.error(e);
      setActions(actions); // revert
      setToastMessage('Error updating action on backend.');
      setTimeout(() => setToastMessage(null), 3000);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 bg-slate-50/50 rounded-2xl border border-slate-200" id="in-season-loading">
        <RefreshCw className="h-8 w-8 text-indigo-600 animate-spin mb-3" />
        <p className="text-sm text-slate-500 font-sans">Connecting to retail operations cockpit...</p>
      </div>
    );
  }

  // Segment action counts
  const pendingActions = actions.filter(a => a.status === 'Pending');
  const sentActions = actions.filter(a => a.status === 'Sent');
  const dismissedActions = actions.filter(a => a.status === 'Dismissed');

  return (
    <div className="space-y-6" id="inseason-operations-workspace">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 border border-slate-800 text-white px-4 py-3 rounded-xl shadow-xl flex items-center space-x-2 text-xs font-sans animate-fade-in animate-bounce">
          <CheckCircle2 className="h-4 w-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Sub Navigation Bar - Sleek Interface Style */}
      <div className="h-12 flex items-center px-4 gap-6 bg-white border border-slate-200/95 rounded-xl shadow-sm mb-6 shrink-0" id="inseason-subtab-bar">
        <button
          onClick={() => setActiveSubTab('cockpit')}
          className={`text-xs sm:text-sm h-full flex items-center transition-all duration-200 cursor-pointer ${
            activeSubTab === 'cockpit' 
              ? 'font-bold text-slate-950 border-b-2 border-slate-950' 
              : 'font-semibold text-slate-550 hover:text-slate-855'
          }`}
          id="tab-cockpit"
        >
          Operations Cockpit
        </button>
        <button
          onClick={() => setActiveSubTab('actions')}
          className={`text-xs sm:text-sm h-full flex items-center gap-1.5 transition-all duration-200 cursor-pointer ${
            activeSubTab === 'actions' 
              ? 'font-bold text-slate-950 border-b-2 border-slate-950' 
              : 'font-semibold text-slate-550 hover:text-slate-855'
          }`}
          id="tab-actions"
        >
          <span>Recommended Actions</span>
          {pendingActions.length > 0 && (
            <span className="bg-rose-500 text-white text-[9px] font-black h-4 px-1.5 rounded-full flex items-center justify-center">
              {pendingActions.length}
            </span>
          )}
        </button>
      </div>

      {activeSubTab === 'cockpit' && (
        <div className="space-y-6 animate-fade-in" id="cockpit-subtab-view">
          {/* Main indicators and custom telemetry line chart */}
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            
            {/* Sales Velocity custom vector Chart */}
            <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200/90 shadow-sm p-6 flex flex-col justify-between">
              <div>
                <div className="flex justify-between items-start pb-4 border-b border-slate-100 mb-4">
                  <div>
                    <h3 className="text-sm font-bold text-slate-850 uppercase font-sans">Apparel Sales Velocity Index</h3>
                    <p className="text-[11px] text-slate-500 mt-0.5">Rolling 8-week real-time store throughput vs. seasonal demand target baseline</p>
                  </div>
                  <span className="bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-mono font-medium rounded-full px-2.5 py-0.5 flex items-center gap-1">
                    <TrendingUp className="h-3 w-3" />
                    +14.2% demand pace
                  </span>
                </div>

                {/* Vector SVG line graph */}
                <div className="h-44 w-full relative pt-2" id="velocity-line-graph-svg">
                  {/* High contrast chart grid background */}
                  <svg className="h-full w-full" viewBox="0 0 500 150" fill="none">
                    {/* Horizontal dash rules */}
                    <line x1="0" y1="30" x2="500" y2="30" stroke="#f1f5f9" strokeDasharray="4 4" />
                    <line x1="0" y1="75" x2="500" y2="75" stroke="#f1f5f9" strokeDasharray="4 4" />
                    <line x1="0" y1="120" x2="500" y2="120" stroke="#f1f5f9" strokeDasharray="4 4" />
                    
                    {/* Baseline target path (Dashed Purple) */}
                    <path d="M 0 100 Q 125 90, 250 85 T 500 70" stroke="#cbd5e1" strokeWidth="1.5" strokeDasharray="5 5" />
                    
                    {/* In-season actual path (Indigo Solid with Gradient below) */}
                    <path 
                      d="M 0 120 L 70 105 L 140 115 L 210 80 L 280 65 L 350 72 L 420 40 L 500 35" 
                      stroke="#4f46e5" 
                      strokeWidth="3.5" 
                      strokeLinecap="round" 
                      strokeLinejoin="round" 
                    />
                    
                    {/* Highlight data points */}
                    <circle cx="210" cy="80" r="4.5" fill="#4f46e5" stroke="#ffffff" strokeWidth="2" />
                    <circle cx="420" cy="40" r="4.5" fill="#4f46e5" stroke="#ffffff" strokeWidth="2" />
                    <circle cx="500" cy="35" r="4.5" fill="#10b981" stroke="#ffffff" strokeWidth="2" />

                    {/* text markers */}
                    <text x="5" y="140" fill="#94a3b8" className="text-[9px] font-mono">Week 18</text>
                    <text x="200" y="70" fill="#4f46e5" className="text-[9px] font-mono font-bold">Ginza Launch</text>
                    <text x="400" y="30" fill="#10b981" className="text-[9px] font-mono font-bold">Current W25</text>
                  </svg>
                </div>
              </div>

              <div className="border-t border-slate-100 pt-3 mt-4 flex items-center justify-between text-[11px] text-slate-500 font-sans">
                <span className="flex items-center gap-1">
                  <span className="inline-block h-2.5 w-2.5 bg-indigo-600 rounded-full"></span>
                  Actual sales pace
                </span>
                <span className="flex items-center gap-1">
                  <span className="inline-block h-2.5 w-2.5 border border-dashed border-slate-400 rounded-sm"></span>
                  Baseline target forecast
                </span>
              </div>
            </div>

            {/* Quick alert list panel */}
            <div className="bg-white rounded-xl border border-slate-200/90 p-6 flex flex-col justify-between shadow-sm">
              <div>
                <h3 className="text-sm font-bold text-slate-850 uppercase font-sans">In-Season Alarms</h3>
                <p className="text-[11px] text-slate-500 mt-0.5">Disruptions needing markdown or store-transfer reallocations</p>
                
                <div className="mt-4 space-y-3.5" id="mini-alerts-stack">
                  <div className="flex items-start gap-2.5 p-2.5 rounded-lg bg-rose-50 border border-rose-100 text-[11px] text-rose-800">
                    <AlertCircle className="h-4.5 w-4.5 text-rose-600 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-bold font-sans">Ginza Understock Code LBB-202</p>
                      <p className="text-rose-700/80 mt-0.5">Ginza is outperforming buy plan; inventory runway estimated &lt; 5 days.</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-2.5 p-2.5 rounded-lg bg-amber-50 border border-amber-100 text-[11px] text-amber-800">
                    <AlertCircle className="h-4.5 w-4.5 text-amber-600 shrink-0 mt-0.5" />
                    <div>
                      <p className="font-bold font-sans">Shibuya Overstock Code RKD-405</p>
                      <p className="text-amber-700/80 mt-0.5">Local rainy week depressed in-store midi dress sells. 21% excess SKU build.</p>
                    </div>
                  </div>
                </div>
              </div>

              <button 
                onClick={() => setActiveSubTab('actions')}
                className="w-full text-center bg-slate-900 text-white font-sans text-xs font-semibold py-2.5 rounded-lg hover:bg-slate-800 transition-colors mt-4 flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <span>Trigger In-store Transfers</span>
                <ArrowRight className="h-4 w-4" />
              </button>
            </div>
          </div>

          {/* Active Optimization Scenarios list (Reads activePlans collection) */}
          <div className="bg-white rounded-xl border border-slate-200/90 shadow-sm p-6">
            <h3 className="text-sm font-bold text-slate-850 uppercase font-sans pb-4 border-b border-slate-100 mb-5">Open System Reallocation Proposals</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6" id="proposals-matrix">
              {plans.map((plan) => (
                <div key={plan.id} className="border border-slate-200/85 hover:border-indigo-300 rounded-xl p-5 hover:bg-slate-50/40 hover:shadow-sm transition-all flex flex-col justify-between">
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="text-[10px] font-mono bg-indigo-50 text-indigo-700 font-bold px-2 py-0.5 rounded uppercase">
                        {plan.category}
                      </span>
                      <h4 className="text-sm font-bold text-slate-850 font-sans mt-2">{plan.title}</h4>
                    </div>
                    <div className="text-right">
                      <p className="text-xs text-slate-400 font-mono">Estimated Benefit</p>
                      <p className="text-sm font-extrabold text-emerald-600 font-mono">+${plan.potentialBenefit.toLocaleString()}</p>
                    </div>
                  </div>

                  <div className="mt-5 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                    <span className="font-mono text-[11px]">Aggregated SKUs monitored: {plan.skuCount}</span>
                    <button 
                      onClick={() => setActiveSubTab('actions')}
                      className="text-indigo-600 font-semibold hover:text-indigo-805 transition-colors text-[11px] flex items-center gap-1"
                    >
                      <span>Review Details</span>
                      <ArrowRight className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {activeSubTab === 'actions' && (
        <div className="bg-white rounded-xl border border-slate-200/90 shadow-sm p-6 animate-fade-in" id="recommended-actions-subview">
          <div className="pb-5 mb-6 border-b border-slate-100">
            <h3 className="text-base font-bold text-slate-900 font-sans tracking-tight">Enterprise Reallocation Cockpit</h3>
            <p className="text-xs text-slate-500 mt-1">Review, authorize, or dismiss granular SKU movements across your retail store network based on real-time sales anomalies.</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6" id="split-by-status-dashboard">
            {/* Status counts pills */}
            <div className="lg:col-span-2 space-y-4" id="individual-actions-card-list">
              {actions.length === 0 ? (
                <div className="text-center py-10 text-slate-400 text-xs">No active action alerts found in database.</div>
              ) : (
                actions.map((act) => (
                  <div 
                    key={act.id} 
                    className={`border rounded-xl p-5 hover:shadow-sm transition-all ${
                      act.status === 'Sent' ? 'border-emerald-200 bg-emerald-50/20' :
                      act.status === 'Dismissed' ? 'border-slate-100 bg-slate-50/20 opacity-50' :
                      'border-slate-200/90 bg-white'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 pb-3 mb-3 border-b border-slate-100">
                      <div>
                        <span className={`text-[9px] font-mono font-black uppercase text-white px-2 py-0.5 rounded ${
                          act.category === 'Reallocation' ? 'bg-indigo-600' :
                          act.category === 'Pricing' ? 'bg-pink-600' :
                          'bg-amber-600'
                        }`}>
                          {act.category}
                        </span>
                        <h4 className="text-slate-850 font-bold font-sans text-sm mt-1">{act.title}</h4>
                      </div>
                      <span className={`inline-flex items-center px-2 py-0.5 rounded text-[10px] font-mono font-semibold uppercase ${
                        act.status === 'Sent' ? 'bg-emerald-100 text-emerald-800' :
                        act.status === 'Dismissed' ? 'bg-slate-100 text-slate-400' :
                        'bg-amber-100 text-amber-800'
                      }`}>
                        {act.status}
                      </span>
                    </div>

                    <p className="text-xs text-slate-600 font-sans leading-relaxed">{act.description}</p>

                    {/* Store from / store to details */}
                    <div className="bg-slate-50 border border-slate-100 rounded-xl p-3 grid grid-cols-1 sm:grid-cols-3 gap-3 my-4 text-xs">
                      <div>
                        <p className="text-[10px] font-mono text-slate-400 uppercase tracking-wide">Target SKU Code</p>
                        <p className="font-mono font-bold text-slate-800 mt-0.5">{act.sku}</p>
                      </div>

                      <div className="sm:border-l sm:border-slate-200 sm:pl-3">
                        <p className="text-[10px] font-mono text-slate-400 uppercase tracking-wide">Source Facility</p>
                        <p className="font-sans font-semibold text-slate-800 mt-0.5 flex items-center gap-1">
                          <MapPin className="h-3 w-3 text-rose-500" />
                          {act.storeFrom}
                        </p>
                      </div>

                      <div className="sm:border-l sm:border-slate-200 sm:pl-3">
                        <p className="text-[10px] font-mono text-slate-400 uppercase tracking-wide">Destination Facility</p>
                        <p className="font-sans font-semibold text-slate-800 mt-0.5 flex items-center gap-1">
                          <Truck className="h-3 w-3 text-indigo-500" />
                          {act.storeTo}
                        </p>
                      </div>
                    </div>

                    {/* Interactive state updates */}
                    {act.status === 'Pending' && (
                      <div className="flex gap-2 justify-end mt-4 pt-3 border-t border-slate-100">
                        <button
                          onClick={() => handleDismissAction(act)}
                          className="flex items-center space-x-1.5 hover:bg-rose-50 text-rose-600 hover:text-rose-700 px-3 py-2 rounded-lg text-xs font-semibold border border-rose-200/50 transition-all cursor-pointer"
                          id={`dismiss-action-btn-${act.id}`}
                        >
                          <Trash2 className="h-4 w-4" />
                          <span>Dismiss Alert</span>
                        </button>
                        
                        <button
                          onClick={() => handleSendRequest(act)}
                          className="flex items-center space-x-1.5 bg-indigo-600 hover:bg-indigo-705 text-white px-4 py-2 rounded-lg text-xs font-semibold shadow-sm transition-all cursor-pointer"
                          id={`send-action-btn-${act.id}`}
                        >
                          <Send className="h-3.5 w-3.5" />
                          <span>Approve & Dispatch</span>
                        </button>
                      </div>
                    )}

                    {act.status === 'Sent' && (
                      <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-emerald-600 font-mono">
                        <span className="flex items-center gap-1 font-sans">
                          <CheckCircle className="h-3.5 w-3.5" />
                          Approval transmitted. Logistics courier dispatched.
                        </span>
                        <button 
                          onClick={() => handleDismissAction(act)}
                          className="text-slate-400 hover:text-slate-600 transition-colors"
                          id={`dismiss-sent-btn-${act.id}`}
                        >
                          Archive Action
                        </button>
                      </div>
                    )}

                    {act.status === 'Dismissed' && (
                      <div className="mt-3 pt-2 text-[11px] text-slate-400 font-sans italic flex items-center gap-1 font-mono">
                        <Clock className="h-3.5 w-3.5" />
                        Action dismissed. No stock modifications committed.
                      </div>
                    )}
                  </div>
                ))
              )}
            </div>

            {/* Side summary details card */}
            <div className="space-y-6">
              <div className="bg-slate-50 rounded-xl p-5 border border-slate-200">
                <h4 className="text-xs font-mono font-bold text-slate-400 uppercase tracking-widest pb-2 border-b border-slate-200">Cockpit Dispatch Summary</h4>
                
                <div className="mt-4 space-y-4 text-xs font-sans">
                  <div className="flex justify-between border-b border-slate-200/40 pb-2">
                    <span className="text-slate-500">Pending Authorization:</span>
                    <span className="font-mono font-semibold text-amber-600">{pendingActions.length} recommendations</span>
                  </div>

                  <div className="flex justify-between border-b border-slate-200/40 pb-2">
                    <span className="text-slate-500">Transmitted & Dispatched:</span>
                    <span className="font-mono font-semibold text-emerald-600">{sentActions.length} approved</span>
                  </div>

                  <div className="flex justify-between pb-2">
                    <span className="text-slate-500">Dismissed Alerts:</span>
                    <span className="font-mono font-semibold text-slate-500">{dismissedActions.length} archived</span>
                  </div>
                </div>

                <div className="bg-white/80 border border-slate-200 rounded-lg p-3 text-[11px] text-slate-500 mt-4 leading-relaxed font-sans">
                  Authorization automatically updates the specific action status document in the Firestore database. Transmitted items trigger fulfillment procedures.
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
