import React, { useState, useEffect } from 'react';
import { clientDB } from '../firebase';
import { Scenario, ScenarioItem } from '../types';
import { 
  DollarSign, 
  Percent, 
  TrendingUp, 
  Layers, 
  Check, 
  Edit3, 
  Info, 
  Save, 
  ToggleLeft, 
  ToggleRight, 
  FolderOpen, 
  Grid, 
  Filter,
  CheckCircle2,
  RefreshCw,
  Image as ImageIcon
} from 'lucide-react';

export default function SeasonPlanningTab() {
  const [activeSubTab, setActiveSubTab] = useState<'buy' | 'style' | 'confirm'>('buy');
  const [scenario, setScenario] = useState<Scenario | null>(null);
  const [scenarioItems, setScenarioItems] = useState<ScenarioItem[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Fields for scenario editor
  const [editName, setEditName] = useState('');
  const [editBudget, setEditBudget] = useState(0);
  const [editMargin, setEditMargin] = useState(0);
  const [editSellThrough, setEditSellThrough] = useState(0);
  const [editDesc, setEditDesc] = useState('');

  const [isSaving, setIsSaving] = useState(false);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const loadData = async () => {
    try {
      const dbScenarios = await clientDB.getScenarios();
      const dbItems = await clientDB.getScenarioItems();
      
      if (dbScenarios && dbScenarios.length > 0) {
        const activeScen = dbScenarios[0];
        setScenario(activeScen);
        
        // Populate editor fields
        setEditName(activeScen.name);
        setEditBudget(activeScen.budgetAllocated);
        setEditMargin(activeScen.targetMargin);
        setEditSellThrough(activeScen.projectedSellThrough);
        setEditDesc(activeScen.description);
      }
      
      if (dbItems) {
        setScenarioItems(dbItems);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  // Update Style Status Toggle
  const handleStyleToggle = async (item: ScenarioItem) => {
    const newStatus = item.status === 'Included' ? 'Excluded' : 'Included';
    const updatedItem: ScenarioItem = {
      ...item,
      status: newStatus
    };

    // Optimistically update UI local states
    const nextItems = scenarioItems.map(x => x.id === item.id ? updatedItem : x);
    setScenarioItems(nextItems);

    try {
      await clientDB.updateScenarioItem(updatedItem);
      
      // Re-calculate the scenario aggregates based on items included
      if (scenario) {
        const totalQty = nextItems
          .filter(i => i.status === 'Included')
          .reduce((sum, curr) => sum + curr.recommendedQty, 0);
          
        const updatedScen: Scenario = {
          ...scenario,
          buyQuantityTotal: totalQty,
          updatedAt: new Date().toISOString()
        };
        
        await clientDB.updateScenario(updatedScen);
        setScenario(updatedScen);
      }
      
      setToastMessage(`Style ${item.styleCode} ${newStatus === 'Included' ? 'added to' : 'removed from'} active buying scenario.`);
      setTimeout(() => setToastMessage(null), 3500);
    } catch (e) {
      console.error(e);
      // Revert upon Failure
      setScenarioItems(scenarioItems);
      setToastMessage(`Failed to update style status on Firestore.`);
      setTimeout(() => setToastMessage(null), 3000);
    }
  };

  // Save Scenario Confirmation Form
  const handleSaveScenario = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!scenario) return;

    setIsSaving(true);
    
    // Automatically recalculate Qty total from style list
    const totalQty = scenarioItems
      .filter(i => i.status === 'Included')
      .reduce((sum, curr) => sum + curr.recommendedQty, 0);

    const updatedScen: Scenario = {
      ...scenario,
      name: editName,
      budgetAllocated: editBudget,
      targetMargin: editMargin,
      projectedSellThrough: editSellThrough,
      description: editDesc,
      buyQuantityTotal: totalQty,
      updatedAt: new Date().toISOString()
    };

    try {
      await clientDB.updateScenario(updatedScen);
      setScenario(updatedScen);
      setToastMessage('Seasonal Planning Scenario successfully committed to Firestore!');
      setTimeout(() => setToastMessage(null), 3505);
    } catch (err) {
      console.error(err);
      setToastMessage('Error updating planning scenario. Check Firestore rules.');
      setTimeout(() => setToastMessage(null), 3000);
    } finally {
      setIsSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 bg-slate-50/50 rounded-2xl border border-slate-201" id="planning-loading">
        <LoadingSpinner />
      </div>
    );
  }

  const activeScen = scenario || {
    id: 'active-scenario',
    name: 'Standard SKU Scenario Plan',
    status: 'Draft',
    budgetAllocated: 600000,
    targetMargin: 55,
    projectedSellThrough: 80,
    buyQuantityTotal: 2500,
    description: 'N/A',
    updatedAt: new Date().toISOString()
  };

  // Calculations for React UI
  const includedStyles = scenarioItems.filter(i => i.status === 'Included');
  const totalRecommendedQty = includedStyles.reduce((sum, x) => sum + x.recommendedQty, 0);
  const totalInvoicedBudget = includedStyles.reduce((sum, x) => sum + (x.price * x.recommendedQty), 0);
  const stylesCount = scenarioItems.length;
  const includedCount = includedStyles.length;

  return (
    <div className="space-y-6" id="seasonal-planning-workspace">
      {/* Toast Banner */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 border border-slate-800 text-white px-4 py-3 rounded-xl shadow-xl flex items-center space-x-2 text-xs font-sans animate-fade-in animate-bounce">
          <CheckCircle2 className="h-4 w-4 text-emerald-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Sub-Navigation Tabs - Sleek Interface Style */}
      <div className="h-12 flex items-center px-4 gap-6 bg-white border border-slate-200/95 rounded-xl shadow-sm mb-6 shrink-0" id="subtab-navigator">
        <button
          onClick={() => setActiveSubTab('buy')}
          className={`text-xs sm:text-sm h-full flex items-center transition-all duration-200 cursor-pointer ${
            activeSubTab === 'buy' 
              ? 'font-bold text-slate-950 border-b-2 border-slate-950' 
              : 'font-semibold text-slate-500 hover:text-slate-800'
          }`}
          id="tab-buy-recs"
        >
          Buy Recommendations
        </button>
        <button
          onClick={() => setActiveSubTab('style')}
          className={`text-xs sm:text-sm h-full flex items-center transition-all duration-200 cursor-pointer ${
            activeSubTab === 'style' 
              ? 'font-bold text-slate-950 border-b-2 border-slate-950' 
              : 'font-semibold text-slate-550 hover:text-slate-850'
          }`}
          id="tab-style-select"
        >
          Style Selection ({includedCount}/{stylesCount})
        </button>
        <button
          onClick={() => setActiveSubTab('confirm')}
          className={`text-xs sm:text-sm h-full flex items-center transition-all duration-200 cursor-pointer ${
            activeSubTab === 'confirm' 
              ? 'font-bold text-slate-950 border-b-2 border-slate-950' 
              : 'font-semibold text-slate-550 hover:text-slate-850'
          }`}
          id="tab-scenario-confirm"
        >
          Scenario Confirmation
        </button>
      </div>

      {/* RENDER ACTIVE SUBTAB CONTENT */}
      {activeSubTab === 'buy' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fade-in" id="buy-recommendations-subview">
          {/* Summary Panel */}
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-white rounded-xl border border-slate-200/90 shadow-sm p-6">
              <h3 className="text-base font-bold text-slate-900 font-sans tracking-tight">Enterprise Purchase Guide</h3>
              <p className="text-xs text-slate-500 mt-1">Recommended pre-season buy allocations derived from predictive customer search, historic sell-through, and inventory runway.</p>
              
              {/* Summary Lists of Styles */}
              <div className="mt-6 flow-root">
                <div className="-mx-4 -my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                  <div className="inline-block min-w-full py-2 align-middle sm:px-6 lg:px-8">
                    <table className="min-w-full divide-y divide-slate-100">
                      <thead>
                        <tr className="text-slate-400 font-mono text-[10px] tracking-wider uppercase text-left">
                          <th scope="col" className="py-3 px-3">Style Key</th>
                          <th scope="col" className="py-3 px-3">Forecast</th>
                          <th scope="col" className="py-3 px-3">Unit Price</th>
                          <th scope="col" className="py-3 px-3">Target Volume</th>
                          <th scope="col" className="py-3 px-3">Total Cost</th>
                          <th scope="col" className="py-3 px-3 text-right">Selection</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-100 text-xs">
                        {scenarioItems.map((style) => (
                          <tr key={style.id} className={`hover:bg-slate-50/50 transition-colors ${style.status === 'Excluded' ? 'opacity-50 line-through' : ''}`}>
                            <td className="py-3.5 px-3">
                              <div className="flex items-center gap-2">
                                <img src={style.image} alt={style.name} className="h-6 w-6 rounded object-cover shadow-sm bg-slate-100 shrink-0" />
                                <div>
                                  <p className="font-semibold text-slate-800">{style.name}</p>
                                  <p className="text-[10px] text-slate-400 font-mono">{style.styleCode}</p>
                                </div>
                              </div>
                            </td>
                            <td className="py-3.5 px-3">
                              <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-[10px] font-medium font-mono border ${
                                style.demandForecast === 'High' ? 'bg-emerald-50 text-emerald-700 border-emerald-100' :
                                style.demandForecast === 'Medium' ? 'bg-indigo-50 text-indigo-700 border-indigo-100' :
                                'bg-slate-55 text-slate-600 border-slate-100'
                              }`}>
                                {style.demandForecast} Demand
                              </span>
                            </td>
                            <td className="py-3.5 px-3 font-mono text-slate-600">${style.price}</td>
                            <td className="py-3.5 px-3 font-mono font-medium text-slate-800">{style.recommendedQty.toLocaleString()} units</td>
                            <td className="py-3.5 px-3 font-mono text-slate-700">${(style.price * style.recommendedQty).toLocaleString()}</td>
                            <td className="py-3.5 px-3 text-right">
                              <span className={`inline-flex px-2 py-0.5 rounded text-[10px] font-semibold tracking-wide uppercase ${
                                style.status === 'Included' ? 'bg-emerald-100 text-emerald-800' : 'bg-slate-100 text-slate-400'
                              }`}>
                                {style.status === 'Included' ? 'Included' : 'Excluded'}
                              </span>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Scenario KPI Card (Reads from and Summarizes Firestore Scenario State) */}
          <div className="space-y-6" id="compiled-scenario-summary-panel">
            <div className="bg-slate-900 text-white rounded-xl border border-slate-800 p-6 flex flex-col justify-between shadow-lg">
              <div>
                <div className="flex justify-between items-start pb-4 border-b border-slate-800 mb-5">
                  <div>
                    <span className="text-[10px] font-mono font-black text-indigo-400 uppercase tracking-widest">Active Plan Summary</span>
                    <h4 className="text-md font-bold text-slate-100 mt-1 font-sans tracking-tight">{activeScen.name}</h4>
                  </div>
                  <span className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded text-[10px] font-mono font-semibold uppercase">
                    {activeScen.status}
                  </span>
                </div>

                <div className="space-y-4">
                  <div className="flex justify-between items-center py-1.5 border-b border-slate-850">
                    <p className="text-xs text-slate-400 font-sans">Budget Cap Limit:</p>
                    <p className="text-sm font-bold font-mono text-slate-100">${activeScen.budgetAllocated.toLocaleString()}</p>
                  </div>
                  
                  <div className="flex justify-between items-center py-1.5 border-b border-slate-850">
                    <p className="text-xs text-slate-400 font-sans">Projected Invoiced Allocations:</p>
                    <p className="text-sm font-bold font-mono text-emerald-400">${totalInvoicedBudget.toLocaleString()}</p>
                  </div>

                  <div className="flex justify-between items-center py-1.5 border-b border-slate-850">
                    <p className="text-xs text-slate-400 font-sans">Rec. Buy Quantity:</p>
                    <p className="text-sm font-bold font-mono text-slate-100">{totalRecommendedQty.toLocaleString()} units</p>
                  </div>

                  <div className="flex justify-between items-center py-1.5 border-b border-slate-850">
                    <p className="text-xs text-slate-400 font-sans">Target Margin Goal %:</p>
                    <p className="text-sm font-bold font-mono text-slate-100">{activeScen.targetMargin}%</p>
                  </div>

                  <div className="flex justify-between items-center pb-2">
                    <p className="text-xs text-slate-400 font-sans">Expected Sell-Through:</p>
                    <p className="text-sm font-bold font-mono text-slate-100">{activeScen.projectedSellThrough}%</p>
                  </div>
                </div>

                <p className="text-xs text-slate-400 italic bg-slate-950/40 border border-slate-850 p-3 rounded-lg mt-5 font-sans leading-relaxed">
                  &ldquo;{activeScen.description}&rdquo;
                </p>
              </div>

              <div className="border-t border-slate-800 pt-4 mt-6 flex justify-between items-center text-[11px] text-slate-500 font-mono">
                <span>Linked Firestore: active-scenario</span>
                <span>Saved: {new Date(activeScen.updatedAt).toLocaleTimeString()}</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeSubTab === 'style' && (
        <div className="bg-white rounded-xl border border-slate-200/90 shadow-sm p-6 animate-fade-in" id="style-selection-subview">
          <div className="pb-5 mb-5 border-b border-slate-100">
            <h3 className="text-base font-bold text-slate-900 font-sans tracking-tight">Style Availability Selection</h3>
            <p className="text-xs text-slate-500 mt-1">Include or exclude specific SKU style codes within the active seasonal buying forecast scenario.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6" id="style-items-interactive-list">
            {scenarioItems.map((style) => (
              <div 
                key={style.id} 
                className={`bg-slate-50 border rounded-xl overflow-hidden transition-all duration-300 flex flex-col justify-between ${
                  style.status === 'Included' ? 'border-indigo-200 shadow-md shadow-indigo-100/30' : 'border-slate-200 opacity-70'
                }`}
              >
                <div>
                  <div className="h-44 w-full relative overflow-hidden bg-slate-100">
                    <img src={style.image} alt={style.name} className="h-full w-full object-cover transition-transform duration-500 hover:scale-105" />
                    <span className="absolute top-3 left-3 bg-slate-900/80 text-white font-mono px-2 py-1 rounded text-[10px]">
                      {style.styleCode}
                    </span>
                    <span className={`absolute top-3 right-3 font-mono px-2 py-0.5 rounded text-[10px] font-bold ${
                      style.status === 'Included' ? 'bg-emerald-500 text-white' : 'bg-slate-500 text-white'
                    }`}>
                      {style.status === 'Included' ? 'Active In Selection' : 'Inactive'}
                    </span>
                  </div>

                  <div className="p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <p className="text-xs font-mono font-bold text-indigo-600 uppercase tracking-wide">{style.category}</p>
                        <h4 className="text-sm font-bold text-slate-850 mt-1 font-sans">{style.name}</h4>
                      </div>
                      <p className="text-sm font-extrabold text-slate-800 font-mono">${style.price}</p>
                    </div>

                    <div className="mt-4 pt-3 border-t border-slate-200/50 flex justify-between text-xs text-slate-500 font-sans">
                      <span>Rec. Quantity:</span>
                      <strong className="text-slate-700 font-mono">{style.recommendedQty.toLocaleString()} units</strong>
                    </div>
                  </div>
                </div>

                <div className="p-4 pt-0 border-t border-slate-100/50 bg-slate-50/50 flex justify-between items-center mt-2">
                  <span className="text-xs text-slate-600 font-medium font-sans">Include Style in Scenario?</span>
                  <button
                    onClick={() => handleStyleToggle(style)}
                    className="focus:outline-none transition-all"
                    id={`toggle-style-${style.id}`}
                  >
                    {style.status === 'Included' ? (
                      <ToggleRight className="h-9 w-9 text-indigo-600 cursor-pointer" />
                    ) : (
                      <ToggleLeft className="h-9 w-9 text-slate-400 cursor-pointer" />
                    )}
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {activeSubTab === 'confirm' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fade-in" id="scenario-configuration-form-view">
          {/* Editor Form */}
          <div className="lg:col-span-2 bg-white rounded-xl border border-slate-200/90 shadow-sm p-6">
            <h3 className="text-base font-bold text-slate-900 font-sans tracking-tight">Edit active-scenario parameters</h3>
            <p className="text-xs text-slate-500 mt-1">Overwrite target financial parameters which drive the buy calculator output.</p>
            
            <form onSubmit={handleSaveScenario} className="space-y-4 mt-6">
              <div>
                <label className="block text-xs font-mono font-bold text-slate-400 uppercase tracking-widest mb-1.5">Scenario Title Name</label>
                <input 
                  type="text"
                  required
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full text-xs font-sans border border-slate-205 rounded-xl px-4 py-2.5 bg-slate-50 hover:bg-slate-50 focus:bg-white focus:outline-indigo-500 transition-all font-semibold"
                  placeholder="e.g. Summer In-Demand Plan"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div>
                  <label className="block text-xs font-mono font-bold text-slate-400 uppercase tracking-widest mb-1.5">Allocated Budget ($)</label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400 font-mono text-xs">$</span>
                    <input 
                      type="number"
                      required
                      min={100}
                      value={editBudget}
                      onChange={(e) => setEditBudget(Number(e.target.value))}
                      className="w-full text-xs font-mono border border-slate-205 rounded-xl pl-8 pr-4 py-2.5 bg-slate-50 focus:bg-white focus:outline-indigo-500 transition-all font-semibold"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-mono font-bold text-slate-400 uppercase tracking-widest mb-1.5">Target Margin (%)</label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400 font-mono text-xs">%</span>
                    <input 
                      type="number"
                      required
                      min={0}
                      max={100}
                      value={editMargin}
                      onChange={(e) => setEditMargin(Number(e.target.value))}
                      className="w-full text-xs font-mono border border-slate-205 rounded-xl pl-8 pr-4 py-2.5 bg-slate-50 focus:bg-white focus:outline-indigo-500 transition-all font-semibold"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-mono font-bold text-slate-400 uppercase tracking-widest mb-1.5">Exp. Sell-Through (%)</label>
                  <div className="relative">
                    <span className="absolute inset-y-0 left-0 pl-3 flex items-center text-slate-400 font-mono text-xs">%</span>
                    <input 
                      type="number"
                      required
                      min={0}
                      max={100}
                      value={editSellThrough}
                      onChange={(e) => setEditSellThrough(Number(e.target.value))}
                      className="w-full text-xs font-mono border border-slate-205 rounded-xl pl-8 pr-4 py-2.5 bg-slate-50 focus:bg-white focus:outline-indigo-500 transition-all font-semibold"
                    />
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-xs font-mono font-bold text-slate-400 uppercase tracking-widest mb-1.5">Scenario Strategic Description</label>
                <textarea
                  required
                  rows={4}
                  value={editDesc}
                  onChange={(e) => setEditDesc(e.target.value)}
                  className="w-full text-xs font-sans border border-slate-205 rounded-xl px-4 py-2.5 bg-slate-50 focus:bg-white focus:outline-indigo-500 transition-all font-semibold leading-relaxed"
                  placeholder="Detail the strategy or seasonal limits..."
                ></textarea>
              </div>

              <div className="pt-3 border-t border-slate-100 flex justify-end">
                <button
                  type="submit"
                  disabled={isSaving}
                  className="bg-indigo-600 hover:bg-indigo-700 disabled:bg-indigo-400 text-white px-5 py-2.5 rounded-xl text-xs font-medium flex items-center space-x-2 transition-all cursor-pointer shadow-sm"
                  id="save-scenario-form-button"
                >
                  <Save className="h-4 w-4" />
                  <span>{isSaving ? 'Saving to Firestore...' : 'Save Scenario Parameters'}</span>
                </button>
              </div>
            </form>
          </div>

          {/* Quick Informational Panel */}
          <div className="space-y-6">
            <div className="bg-slate-50 rounded-xl p-6 border border-slate-200">
              <h4 className="text-xs font-mono font-black text-slate-400 uppercase tracking-widest">Calculated Allocation Check</h4>
              
              <div className="mt-4 space-y-4 text-xs font-sans">
                <div className="flex justify-between border-b border-slate-200/50 pb-2">
                  <span className="text-slate-500">Invoiced Budget Allocated:</span>
                  <span className="font-mono font-semibold text-slate-900">${totalInvoicedBudget.toLocaleString()}</span>
                </div>
                
                <div className="flex justify-between border-b border-slate-200/50 pb-2">
                  <span className="text-slate-500">Allowed Spending Maximum:</span>
                  <span className="font-mono font-semibold text-slate-900">${editBudget.toLocaleString()}</span>
                </div>

                <div className="flex justify-between border-b border-slate-200/50 pb-2">
                  <span className="text-slate-500">Runway Remaining:</span>
                  <span className={`font-mono font-semibold ${
                    editBudget - totalInvoicedBudget >= 0 ? 'text-emerald-600' : 'text-rose-600'
                  }`}>
                    ${(editBudget - totalInvoicedBudget).toLocaleString()}
                  </span>
                </div>

                <div className="rounded-lg p-3 bg-indigo-50 border border-indigo-100 text-slate-700/90 text-[11px] leading-relaxed mt-4">
                  <p className="font-medium text-indigo-800 flex items-center gap-1.5 mb-1">
                    <Info className="h-3.5 w-3.5" />
                    Strategic Guidance
                  </p>
                  Buying allocations automatically update total quantity totals. Ensure remaining budget runway stays positive to maintain fiscal guidelines.
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function LoadingSpinner() {
  return (
    <div className="flex flex-col items-center">
      <RefreshCw className="h-8 w-8 text-indigo-600 animate-spin mb-3" />
      <p className="text-sm text-slate-500 font-sans">Querying Scenario Data from Firestore...</p>
    </div>
  );
}
