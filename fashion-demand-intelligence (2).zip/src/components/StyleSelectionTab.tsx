import { useMemo } from "react";
import { AppShell } from "@/components/AppShell";
import { DemandOpportunityPage } from "@/components/DemandOpportunityPage";
import { clusters } from "@/lib/cockpit-data";
import { useRouterState } from "@/lib/router-mock";

export default function StyleSelectionTab() {
  const path = useRouterState({ select: (s) => s.location.pathname });
  
  // Extract cluster slug if path is /demand-opportunity/:cluster
  const slug = useMemo(() => {
    if (path.startsWith('/demand-opportunity/')) {
      return path.replace('/demand-opportunity/', '');
    }
    return "ribbed-tanks";
  }, [path]);

  const cluster = useMemo(() => {
    return clusters.find((c) => c.slug === slug) || clusters[0];
  }, [slug]);

  return (
    <AppShell>
      <DemandOpportunityPage cluster={cluster} />
    </AppShell>
  );
}