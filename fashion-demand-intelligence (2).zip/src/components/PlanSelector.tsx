import * as React from "react";
import { useEffect, useRef, useState } from "react";
import { ChevronDown, Check } from "lucide-react";
import { PlanItem, PlanStatus } from "@/lib/plans-store";

const statusTone: Record<PlanStatus, string> = {
  Saved: "bg-[color:var(--signal-green-bg)] text-[color:var(--signal-green)]",
  Draft: "bg-secondary text-muted-foreground",
  Ready: "bg-[color:var(--signal-blue-bg)] text-accent",
  Exported: "bg-[color:var(--signal-purple-bg)] text-[color:var(--signal-purple)]",
};

export function PlanSelector({
  label,
  current,
  items,
  onSelect,
  suffix,
}: {
  label: string;
  current: string;
  items: PlanItem[];
  onSelect: (name: string) => void;
  suffix?: React.ReactNode;
}) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const fn = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", fn);
    return () => document.removeEventListener("mousedown", fn);
  }, []);

  return (
    <div ref={ref} className="relative flex items-center gap-1.5">
      <span className="text-muted-foreground">{label}: </span>
      <button
        onClick={() => setOpen((o) => !o)}
        className="inline-flex items-center gap-1 rounded-md px-1.5 py-0.5 font-medium hover:bg-secondary"
      >
        {current}
        <ChevronDown className="h-3.5 w-3.5 text-muted-foreground" />
      </button>
      {suffix}
      {open && (
        <div className="absolute bottom-full left-0 z-40 mb-2 w-[320px] rounded-xl border border-border bg-card p-1.5 shadow-xl">
          {items.map((it) => {
            const active = it.name === current;
            return (
              <button
                key={it.name}
                onClick={() => { onSelect(it.name); setOpen(false); }}
                className={`flex w-full items-center justify-between gap-2 rounded-md px-2.5 py-2 text-left text-[13px] hover:bg-secondary ${
                  active ? "bg-secondary" : ""
                }`}
              >
                <span className="flex min-w-0 items-center gap-2">
                  {active ? (
                    <Check className="h-3.5 w-3.5 shrink-0 text-accent" />
                  ) : (
                    <span className="h-3.5 w-3.5 shrink-0" />
                  )}
                  <span className="truncate font-medium">{it.name}</span>
                </span>
                <span className={`shrink-0 rounded-md px-2 py-0.5 text-[10px] font-medium ${statusTone[it.status]}`}>
                  {it.status}
                </span>
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
}