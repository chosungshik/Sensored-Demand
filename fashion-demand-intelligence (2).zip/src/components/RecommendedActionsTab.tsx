import * as React from "react";
import { useMemo, useState } from "react";
import { createFileRoute } from "@/lib/router-mock";
import { AppShell } from "@/components/AppShell";
import { GlobalFilters } from "@/components/GlobalFilters";
import {
  ClipboardList,
  CheckCircle2,
  Euro,
  Truck,
  LayoutGrid,
  Palette,
  ArrowLeftRight,
  Send,
} from "lucide-react";
import { toast } from "sonner";

type Search = { location?: string; cluster?: string };

export const Route = createFileRoute("/recommended-actions")({
  component: Page,
  validateSearch: (s: Record<string, unknown>): Search => ({
    location: typeof s.location === "string" ? s.location : undefined,
    cluster: typeof s.cluster === "string" ? s.cluster : undefined,
  }),
});

type Priority = "High" | "Medium";
type Status = "Pending" | "Sent" | "In progress" | "Completed" | "Dismissed";

type Action = {
  id: string;
  priority: Priority;
  location: string;
  stores: string;
  cluster: string;
  action: string;
  actionKind: string;
  actionIcon: typeof Truck;
  reason: string;
  evidence: string[];
  risk: string;
  status: Status;
  owner: string;
  impact: string;
  impactDetail: string;
  whyThisAction: string;
  suggestedMessage: string;
  sendLabel: string;
};

const initialActions: Action[] = [
  {
    id: "a1",
    priority: "High",
    location: "Seville",
    stores: "7 stores",
    cluster: "Ribbed Tanks",
    action: "DC replenishment",
    actionKind: "SCM action",
    actionIcon: Truck,
    reason: "Heat spike + low stock",
    evidence: ["Heat spike", "Low stock"],
    risk: "7 stores may run low within 2 weeks",
    status: "Pending",
    owner: "SCM team",
    impact: "€42K protected",
    impactDetail: "At-risk stores reduced from 7 to 2.",
    whyThisAction: "7 Seville stores may run below cover within 2 weeks due to heat spike and low stock.",
    suggestedMessage:
      "Please replenish Ribbed Tanks inventory for 7 Seville stores before May 22 to reduce early stockout risk.",
    sendLabel: "Send to SCM team",
  },
  {
    id: "a2",
    priority: "High",
    location: "Seville",
    stores: "7 stores",
    cluster: "Ribbed Tanks",
    action: "Move to front display",
    actionKind: "VMD action",
    actionIcon: LayoutGrid,
    reason: "Heat spike + low visibility",
    evidence: ["Heat spike", "Low visibility"],
    risk: "Demand may not convert",
    status: "Pending",
    owner: "Store team",
    impact: "€16K uplift",
    impactDetail: "Front display lifts conversion on warm-weather demand.",
    whyThisAction: "Seville stores show low visibility on Ribbed Tanks despite heat spike demand.",
    suggestedMessage:
      "Please move Ribbed Tanks to the front display across 7 Seville stores to capture warm-weather demand.",
    sendLabel: "Send to Store team",
  },
  {
    id: "a3",
    priority: "High",
    location: "Seville",
    stores: "7 stores",
    cluster: "Ribbed Tanks",
    action: "Prioritize colorways",
    actionKind: "Store Ops",
    actionIcon: Palette,
    reason: "Heat spike + color mix",
    evidence: ["Heat spike", "Color mix"],
    risk: "Size-color imbalance risk",
    status: "Pending",
    owner: "Store Ops",
    impact: "€9K uplift",
    impactDetail: "Rebalances size-color mix in top-performing stores.",
    whyThisAction: "Color mix is shifting; stores need size-color rebalancing for Ribbed Tanks.",
    suggestedMessage:
      "Please prioritize top-performing colorways for Ribbed Tanks across 7 Seville stores.",
    sendLabel: "Send to Store Ops",
  },
  {
    id: "a4",
    priority: "Medium",
    location: "Seville",
    stores: "5 stores",
    cluster: "Linen Shirts",
    action: "DC replenishment",
    actionKind: "SCM action",
    actionIcon: Truck,
    reason: "Fast sell-through + low cover",
    evidence: ["Fast sell-through", "Low cover"],
    risk: "Missed sales risk",
    status: "Pending",
    owner: "SCM team",
    impact: "€27K protected",
    impactDetail: "Protects sell-through across 5 priority stores.",
    whyThisAction: "Fast sell-through and low cover in 5 Seville stores for Linen Shirts.",
    suggestedMessage:
      "Please replenish Linen Shirts inventory for 5 Seville stores to protect ongoing sell-through.",
    sendLabel: "Send to SCM team",
  },
  {
    id: "a5",
    priority: "Medium",
    location: "Valencia",
    stores: "5 stores",
    cluster: "Linen Shirts",
    action: "Transfer from other stores",
    actionKind: "Store transfer",
    actionIcon: ArrowLeftRight,
    reason: "Store imbalance + low cover",
    evidence: ["Store imbalance", "Low cover"],
    risk: "Stockout risk",
    status: "Pending",
    owner: "Store Ops",
    impact: "€12K uplift",
    impactDetail: "Rebalances stock from low-velocity stores.",
    whyThisAction: "Stock imbalance across Valencia stores; low cover on Linen Shirts.",
    suggestedMessage:
      "Please transfer Linen Shirts inventory from low-velocity stores to 5 Valencia stores.",
    sendLabel: "Send transfer request",
  },
];

function PriorityPill({ level }: { level: Priority }) {
  const cls =
    level === "High"
      ? "bg-[color:var(--signal-rose-bg)] text-[color:var(--signal-rose)]"
      : "bg-[color:var(--signal-amber-bg)] text-[color:var(--signal-amber)]";
  return (
    <span className={`inline-flex whitespace-nowrap rounded-md px-2.5 py-0.5 text-[11px] font-medium ${cls}`}>
      {level}
    </span>
  );
}

function EvidenceChip({ label, tone = "muted", key }: { label: string; tone?: "muted" | "blue"; key?: React.Key }) {
  const cls =
    tone === "blue"
      ? "bg-[color:var(--signal-blue-bg)] text-accent"
      : "bg-secondary text-foreground";
  return (
    <span className={`inline-flex whitespace-nowrap rounded-md px-2 py-0.5 text-[11px] font-medium ${cls}`}>
      {label}
    </span>
  );
}

function StatusPill({ status }: { status: Status }) {
  const cls =
    status === "Pending"
      ? "bg-[color:var(--signal-amber-bg)] text-[color:var(--signal-amber)]"
      : status === "Sent"
      ? "bg-[color:var(--signal-blue-bg)] text-accent"
      : status === "In progress"
      ? "bg-[color:var(--signal-purple-bg)] text-[color:var(--signal-purple)]"
      : status === "Completed"
      ? "bg-[color:var(--signal-green-bg)] text-[color:var(--signal-green)]"
      : "bg-secondary text-muted-foreground";
  return (
    <span className={`inline-flex whitespace-nowrap rounded-md px-2 py-0.5 text-[11px] font-medium ${cls}`}>
      {status}
    </span>
  );
}

function DecisionCard({
  icon, iconBg, title, value, valueTone, subtitle,
}: {
  icon: React.ReactNode;
  iconBg: string;
  title: string;
  value: React.ReactNode;
  valueTone: string;
  subtitle: string;
}) {
  return (
    <div className="rounded-xl border border-border bg-card p-5 shadow-[var(--shadow-card)]">
      <div className="flex items-start gap-4">
        <span className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-full ${iconBg}`}>
          {icon}
        </span>
        <div className="min-w-0">
          <div className="text-sm font-medium text-primary">{title}</div>
          <div className={`mt-1 text-[22px] font-semibold leading-tight ${valueTone}`}>{value}</div>
          <div className="mt-1.5 text-xs text-muted-foreground">{subtitle}</div>
        </div>
      </div>
    </div>
  );
}

function Page() {
  const [actions, setActions] = useState<Action[]>(initialActions);
  const [selectedId, setSelectedId] = useState<string>(initialActions[0].id);

  const selected = actions.find((a) => a.id === selectedId) ?? actions[0];

  const pending = actions.filter((a) => a.status === "Pending").length;
  const sent = actions.filter((a) => a.status === "Sent" || a.status === "In progress" || a.status === "Completed").length;

  const impactRange = useMemo(() => {
    return `€${96 + sent * 8}K – €${118 + sent * 10}K`;
  }, [sent]);

  const setStatus = (id: string, status: Status) =>
    setActions((prev) => prev.map((a) => (a.id === id ? { ...a, status } : a)));

  const handleSend = () => {
    setStatus(selected.id, "Sent");
    toast(`Action request sent to ${selected.owner}`);
  };
  const handleDismiss = () => {
    setStatus(selected.id, "Dismissed");
    toast("Action dismissed");
  };

  return (
    <AppShell>
      <GlobalFilters variant="ops" />

      <h1 className="text-2xl font-semibold tracking-tight text-primary">Recommended Actions</h1>
      <p className="mt-2 max-w-3xl text-sm text-muted-foreground">
        Review recommended operational actions and send them directly to the responsible team.
      </p>
      <p className="mt-1 max-w-3xl text-xs text-muted-foreground">
        Actions are prioritized by urgency, store impact, stock cover, and expected sales protection.
      </p>

      {/* Decision cards */}
      <div className="mt-5 grid grid-cols-1 gap-5 md:grid-cols-3">
        <DecisionCard
          icon={<ClipboardList className="h-6 w-6 text-[color:var(--signal-amber)]" />}
          iconBg="bg-[color:var(--signal-amber-bg)]"
          title="Pending decisions"
          value={<span>{pending} actions</span>}
          valueTone="text-[color:var(--signal-amber)]"
          subtitle="not yet sent"
        />
        <DecisionCard
          icon={<CheckCircle2 className="h-6 w-6 text-[color:var(--signal-green)]" />}
          iconBg="bg-[color:var(--signal-green-bg)]"
          title="Sent to teams"
          value={<span>{sent} actions</span>}
          valueTone="text-[color:var(--signal-green)]"
          subtitle="being executed"
        />
        <DecisionCard
          icon={<Euro className="h-6 w-6 text-[color:var(--signal-purple)]" />}
          iconBg="bg-[color:var(--signal-purple-bg)]"
          title="Potential impact"
          value={<span>{impactRange}</span>}
          valueTone="text-[color:var(--signal-purple)]"
          subtitle="if all actions are implemented"
        />
      </div>

      {/* Table + Panel grid */}
      <div className="mt-6 grid grid-cols-1 gap-5 lg:grid-cols-[minmax(0,1fr)_360px]">
        <section className="rounded-xl border border-border bg-card shadow-[var(--shadow-card)]">
          <div className="border-b border-border px-6 py-4">
            <h2 className="text-base font-semibold">Action List</h2>
            <p className="mt-1 text-xs text-muted-foreground">
              Select an action to review details and send it to the responsible team.
            </p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-border text-left text-xs font-medium text-muted-foreground">
                  <th className="px-3 py-3">Priority</th>
                  <th className="px-3 py-3">Status</th>
                  <th className="px-3 py-3">Affected Location</th>
                  <th className="px-3 py-3">Product Cluster</th>
                  <th className="px-3 py-3">Recommended Action</th>
                  <th className="px-3 py-3">Main Reason</th>
                  <th className="px-3 py-3">Risk if ignored</th>
                  <th className="px-3 py-3">Owner / Team</th>
                  <th className="px-3 py-3">Potential Impact</th>
                </tr>
              </thead>
              <tbody>
                {actions.map((r) => {
                  const ActionIcon = r.actionIcon;
                  const isSelected = r.id === selectedId;
                  return (
                    <tr
                      key={r.id}
                      onClick={() => setSelectedId(r.id)}
                      className={`group cursor-pointer border-b border-border/60 align-top last:border-0 hover:bg-secondary/40 ${
                        isSelected ? "bg-[color:var(--signal-blue-bg)]/30" : ""
                      }`}
                    >
                      <td className="px-3 py-4 align-middle"><PriorityPill level={r.priority} /></td>
                      <td className="px-3 py-4 align-middle"><StatusPill status={r.status} /></td>
                      <td className="px-3 py-4 align-middle text-sm">
                        <div className="text-foreground">
                          {r.location} · <span className="text-muted-foreground">{r.stores}</span>
                        </div>
                      </td>
                      <td className="px-3 py-4 align-middle font-medium text-accent">{r.cluster}</td>
                      <td className="px-3 py-4 align-middle">
                        <div className="flex items-start gap-2 text-sm">
                          <ActionIcon className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />
                          <div>
                            <div>{r.action}</div>
                            <div className="text-xs text-muted-foreground">{r.actionKind}</div>
                          </div>
                        </div>
                      </td>
                      <td className="px-3 py-4 align-middle">
                        <div className="flex flex-wrap gap-1.5">
                          {r.evidence.map((e, i) => (
                            <EvidenceChip key={e} label={e} tone={i === 0 ? "muted" : "blue"} />
                          ))}
                        </div>
                      </td>
                      <td className="px-3 py-4 align-middle text-sm text-muted-foreground">{r.risk}</td>
                      <td className="px-3 py-4 align-middle text-sm">{r.owner}</td>
                      <td className="px-3 py-4 align-middle text-sm font-medium">{r.impact}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div className="flex items-center justify-end gap-2 border-t border-border px-6 py-3 text-xs text-muted-foreground">
            <span>1–{actions.length} of {actions.length}</span>
            <button className="rounded-md border border-border bg-card p-1 hover:bg-secondary">‹</button>
            <button className="rounded-md border border-border bg-card p-1 hover:bg-secondary">›</button>
          </div>
        </section>

        {/* Selected Action panel */}
        <aside className="self-start rounded-xl border border-border bg-card p-5 shadow-[var(--shadow-card)]">
          <h3 className="text-base font-semibold text-primary">Selected Action</h3>
          <div className="mt-2 flex flex-wrap items-center gap-2 text-sm">
            <span className="font-medium text-foreground">{selected.location}</span>
            <span className="text-muted-foreground">·</span>
            <span className="font-medium text-foreground">{selected.cluster}</span>
            <StatusPill status={selected.status} />
          </div>

          <div className="mt-4 text-xs font-medium uppercase tracking-wide text-muted-foreground">Recommended action</div>
          <div className="mt-1.5 flex items-start gap-2">
            <selected.actionIcon className="mt-0.5 h-4 w-4 text-muted-foreground" />
            <div>
              <div className="text-sm font-medium text-foreground">{selected.action}</div>
              <div className="text-xs text-muted-foreground">{selected.actionKind}</div>
            </div>
          </div>

          <div className="mt-4">
            <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Why this action</div>
            <div className="mt-1 text-sm text-foreground">{selected.whyThisAction}</div>
          </div>

          <div className="mt-3">
            <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Risk if ignored</div>
            <div className="mt-1 text-sm text-foreground">{selected.risk}</div>
          </div>

          <div className="mt-3">
            <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Owner / Team</div>
            <div className="mt-1 text-sm font-medium text-foreground">{selected.owner}</div>
          </div>

          <div className="mt-3">
            <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Potential impact</div>
            <div className="mt-1 text-sm font-semibold text-[color:var(--signal-green)]">{selected.impact}</div>
            <div className="mt-0.5 text-xs text-muted-foreground">{selected.impactDetail}</div>
          </div>

          <div className="mt-3">
            <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Suggested message</div>
            <div className="mt-1 rounded-md border border-border bg-secondary/30 px-3 py-2 text-xs text-foreground">
              {selected.suggestedMessage}
            </div>
          </div>

          <div className="mt-5 flex flex-col gap-2">
            <button
              onClick={handleSend}
              disabled={selected.status !== "Pending"}
              className="inline-flex w-full items-center justify-center gap-2 rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90 disabled:opacity-50"
            >
              <Send className="h-4 w-4" />
              Send action request
            </button>
            <button
              onClick={handleDismiss}
              disabled={selected.status === "Dismissed"}
              className="w-full rounded-md border border-border bg-card px-4 py-2 text-sm font-medium hover:bg-secondary disabled:opacity-50"
            >
              Dismiss action
            </button>
            <button className="text-xs font-medium text-accent hover:underline">
              View execution details
            </button>
          </div>
        </aside>
      </div>
    </AppShell>
  );
}

export default Page;
