import React from 'react';
import { NavigationProvider, useRouterState } from '@/lib/router-mock';
import DataSetupTab from '@/components/DataSetupTab';
import BuyRecommendationsTab from '@/components/BuyRecommendationsTab';
import StyleSelectionTab from '@/components/StyleSelectionTab';
import ScenarioConfirmationTab from '@/components/ScenarioConfirmationTab';
import OperationsCockpitTab from '@/components/OperationsCockpitTab';
import RecommendedActionsTab from '@/components/RecommendedActionsTab';

function AppContent() {
  const path = useRouterState({ select: (s) => s.location.pathname });

  // Render correct Page component based on local state router pathname
  if (path === '/data-setup') {
    return <DataSetupTab />;
  }
  if (path === '/') {
    return <BuyRecommendationsTab />;
  }
  if (path === '/demand-opportunity' || path.startsWith('/demand-opportunity/')) {
    return <StyleSelectionTab />;
  }
  if (path === '/scenario-plan') {
    return <ScenarioConfirmationTab />;
  }
  if (path === '/operations-cockpit') {
    return <OperationsCockpitTab />;
  }
  if (path === '/recommended-actions') {
    return <RecommendedActionsTab />;
  }

  // Fallback to initial Setup workspace
  return <DataSetupTab />;
}

export default function App() {
  return (
    <NavigationProvider initialPath="/data-setup">
      <AppContent />
    </NavigationProvider>
  );
}
