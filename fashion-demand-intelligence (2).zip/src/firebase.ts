import { initializeApp, getApps, getApp } from 'firebase/app';
import { 
  getAuth, 
  signInWithPopup, 
  GoogleAuthProvider, 
  onAuthStateChanged,
  User 
} from 'firebase/auth';
import { 
  getFirestore, 
  doc, 
  collection, 
  getDoc, 
  getDocs, 
  setDoc, 
  updateDoc, 
  deleteDoc, 
  onSnapshot 
} from 'firebase/firestore';
import firebaseConfig from '../firebase-applet-config.json';
import { DataSetups, Scenario, ScenarioItem, ActionPlan, Action } from './types';

// Check if we are running in a real project environment or mock placeholder
export const isMockConfig = firebaseConfig.apiKey.includes('mock-api-key') || firebaseConfig.projectId === 'mock-project-id';

// Initialize Firebase App
const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp();

// Initialize Services
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId); /* CRITICAL: The app will break without this line */
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
    tenantId?: string | null;
    providerInfo?: {
      providerId?: string | null;
      email?: string | null;
    }[];
  };
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null): never {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid || null,
      email: auth.currentUser?.email || null,
      emailVerified: auth.currentUser?.emailVerified || null,
      isAnonymous: auth.currentUser?.isAnonymous || null,
      tenantId: auth.currentUser?.tenantId || null,
      providerInfo: auth.currentUser?.providerData?.map(provider => ({
        providerId: provider.providerId,
        email: provider.email,
      })) || []
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// Simulated/Fallback Database (When credentials aren't completed or offline)
const LOCAL_STORAGE_KEY_PREFIX = 'fashion_demand_intel_';

function getLocalData<T>(key: string, defaultValue: T): T {
  try {
    const val = localStorage.getItem(LOCAL_STORAGE_KEY_PREFIX + key);
    return val ? JSON.parse(val) : defaultValue;
  } catch (e) {
    return defaultValue;
  }
}

function setLocalData<T>(key: string, data: T): void {
  try {
    localStorage.setItem(LOCAL_STORAGE_KEY_PREFIX + key, JSON.stringify(data));
  } catch (e) {
    console.error('Local Storage Save Error:', e);
  }
}

// Initial seed values if empty or simulating
const defaultDataSetups: DataSetups[] = [
  {
    id: 'current',
    erpConnection: 'Connected',
    wmsConnection: 'Connected',
    posConnection: 'Connected',
    lastSync: '2026-05-27T07:20:00Z',
    dataHealthScore: 94,
    skusMonitored: 1450,
    missingAttributes: 12,
    outOfStockAlerts: 45,
    overstockAlerts: 28
  }
];

const defaultScenarios: Scenario[] = [
  {
    id: 'active-scenario',
    name: 'High-Velocity Summer SKU Plan',
    status: 'Draft',
    budgetAllocated: 650000,
    targetMargin: 58,
    projectedSellThrough: 82,
    buyQuantityTotal: 4820,
    description: 'Strategic inventory buy focusing on high-margin linen resort styles and ribbed dresses to offset low sell-through in standard outerwear.',
    updatedAt: '2026-05-27T07:15:00Z'
  }
];

const defaultScenarioItems: ScenarioItem[] = [
  {
    id: 'style-1',
    scenarioId: 'active-scenario',
    styleCode: 'LBB-202',
    name: 'Linen Blend Blazer',
    category: 'Outerwear',
    price: 149,
    recommendedQty: 1200,
    demandForecast: 'High',
    status: 'Included',
    image: 'https://images.unsplash.com/photo-1591047139829-d91aecb6caea?w=400&auto=format&fit=crop&q=84'
  },
  {
    id: 'style-2',
    scenarioId: 'active-scenario',
    styleCode: 'RKD-405',
    name: 'Ribbed Knit Midi Dress',
    category: 'Core Apparel',
    price: 119,
    recommendedQty: 950,
    demandForecast: 'High',
    status: 'Included',
    image: 'https://images.unsplash.com/photo-1595777457583-95e059d581b8?w=400&auto=format&fit=crop&q=84'
  },
  {
    id: 'style-3',
    scenarioId: 'active-scenario',
    styleCode: 'PBD-012',
    name: 'Poplin Button Down',
    category: 'Core Apparel',
    price: 79,
    recommendedQty: 1500,
    demandForecast: 'Medium',
    status: 'Included',
    image: 'https://images.unsplash.com/photo-1603252109303-2751441dd157?w=400&auto=format&fit=crop&q=84'
  },
  {
    id: 'style-4',
    scenarioId: 'active-scenario',
    styleCode: 'WIP-303',
    name: 'High Waist Wide Leg Pant',
    category: 'Bottoms',
    price: 98,
    recommendedQty: 800,
    demandForecast: 'Medium',
    status: 'Excluded',
    image: 'https://images.unsplash.com/photo-1594633312681-425c7b97ccd1?w=400&auto=format&fit=crop&q=84'
  },
  {
    id: 'style-5',
    scenarioId: 'active-scenario',
    styleCode: 'SSC-098',
    name: 'Silk Slip Camisole',
    category: 'Tops',
    price: 65,
    recommendedQty: 500,
    demandForecast: 'Low',
    status: 'Excluded',
    image: 'https://images.unsplash.com/photo-1548624149-f9b185967ee5?w=400&auto=format&fit=crop&q=84'
  }
];

const defaultActionPlans: ActionPlan[] = [
  {
    id: 'plan-1',
    title: 'Inter-store Transfer Plan',
    category: 'Reallocation',
    potentialBenefit: 14200,
    skuCount: 5
  },
  {
    id: 'plan-2',
    title: 'Micro-Markdown Promotion',
    category: 'Pricing Strategy',
    potentialBenefit: 8500,
    skuCount: 3
  }
];

const defaultActions: Action[] = [
  {
    id: 'act-1',
    title: 'Transfer Linen Blazers to Tokyo Ginza',
    category: 'Reallocation',
    status: 'Pending',
    sku: 'LBB-202',
    description: 'Tokyo Ginza boutique is running 45% ahead of seasonal forecasted demand. Transfer regional excess stock from Saitama Outlet.',
    storeFrom: 'Saitama Outlet (W-04)',
    storeTo: 'Tokyo Ginza (S-01)',
    quantity: 120,
    createdAt: '2026-05-27T07:15:00Z'
  },
  {
    id: 'act-2',
    title: 'Run 15% Promotion on Midi Dresses',
    category: 'Pricing',
    status: 'Pending',
    sku: 'RKD-405',
    description: 'Overstock alarm at Shibuya Flagship due to unseasonable weather sales dip. Implement 15% custom regional off-price markdown.',
    storeFrom: 'Shibuya Flagship (S-02)',
    storeTo: 'N/A (Local Markdown)',
    quantity: 400,
    createdAt: '2026-05-27T07:20:00Z'
  },
  {
    id: 'act-3',
    title: 'Replenish Poplin Shirts in Osaka',
    category: 'Replenishment',
    status: 'Pending',
    sku: 'PBD-012',
    description: 'Critical stock exhaust predicted within 4 operational days. Forward dispatch of 250 units from central distribution hub.',
    storeFrom: 'Central DC (W-01)',
    storeTo: 'Osaka Shinsaibashi (S-05)',
    quantity: 250,
    createdAt: '2026-05-27T07:25:00Z'
  }
];

// Seed Firestore DB
export async function seedFirestoreDatabase() {
  if (isMockConfig) {
    // Already loaded in memory/localStorage, skip real write
    return;
  }
  
  try {
    // Check if data is already seeded
    const path = 'dataSetups';
    const snap = await getDocs(collection(db, path)).catch(e => {
      handleFirestoreError(e, OperationType.GET, path);
    });
    
    if (snap.empty) {
      console.log('Seeding initial enterprise datasets into Firestore Database...');
      // Seed dataSetups
      for (const item of defaultDataSetups) {
        await setDoc(doc(db, 'dataSetups', item.id), item);
      }
      // Seed scenarios
      for (const item of defaultScenarios) {
        await setDoc(doc(db, 'scenarios', item.id), item);
      }
      // Seed scenarioItems
      for (const item of defaultScenarioItems) {
        await setDoc(doc(db, 'scenarioItems', item.id), item);
      }
      // Seed actionPlans
      for (const item of defaultActionPlans) {
        await setDoc(doc(db, 'actionPlans', item.id), item);
      }
      // Seed actions
      for (const item of defaultActions) {
        await setDoc(doc(db, 'actions', item.id), item);
      }
      console.log('Firestore Database successfully seeded!');
    }
  } catch (error) {
    console.warn('Seeding failed (perhaps unauthenticated or permission denied). This is expected for standard security rules before sign-in.', error);
  }
}

// Unified Database CRUD API with safe failure fallback to offline storage
export const clientDB = {
  async getDataSetups(): Promise<DataSetups[]> {
    if (isMockConfig) {
      return getLocalData<DataSetups[]>('dataSetups', defaultDataSetups);
    }
    const path = 'dataSetups';
    try {
      const snap = await getDocs(collection(db, path));
      if (snap.empty) {
        return defaultDataSetups;
      }
      return snap.docs.map(d => ({ ...d.data(), id: d.id })) as DataSetups[];
    } catch (e) {
      console.warn('Firestore failed, loading offline fallback scenario:', e);
      return getLocalData<DataSetups[]>('dataSetups', defaultDataSetups);
    }
  },

  async updateDataSetup(item: DataSetups): Promise<void> {
    const key = 'dataSetups';
    if (isMockConfig) {
      const current = getLocalData<DataSetups[]>(key, defaultDataSetups);
      const updated = current.map(x => x.id === item.id ? item : x);
      setLocalData(key, updated);
      return;
    }
    const path = `dataSetups/${item.id}`;
    try {
      await setDoc(doc(db, 'dataSetups', item.id), item);
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, path);
    }
  },

  async getScenarios(): Promise<Scenario[]> {
    if (isMockConfig) {
      return getLocalData<Scenario[]>('scenarios', defaultScenarios);
    }
    const path = 'scenarios';
    try {
      const snap = await getDocs(collection(db, path));
      if (snap.empty) {
        return defaultScenarios;
      }
      return snap.docs.map(d => ({ ...d.data(), id: d.id })) as Scenario[];
    } catch (e) {
      console.warn('Firestore failed, loading offline scenarios:', e);
      return getLocalData<Scenario[]>('scenarios', defaultScenarios);
    }
  },

  async updateScenario(item: Scenario): Promise<void> {
    const key = 'scenarios';
    if (isMockConfig) {
      const current = getLocalData<Scenario[]>(key, defaultScenarios);
      const updated = current.map(x => x.id === item.id ? item : x);
      setLocalData(key, updated);
      return;
    }
    const path = `scenarios/${item.id}`;
    try {
      await setDoc(doc(db, 'scenarios', item.id), item);
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, path);
    }
  },

  async getScenarioItems(): Promise<ScenarioItem[]> {
    if (isMockConfig) {
      return getLocalData<ScenarioItem[]>('scenarioItems', defaultScenarioItems);
    }
    const path = 'scenarioItems';
    try {
      const snap = await getDocs(collection(db, path));
      if (snap.empty) {
        return defaultScenarioItems;
      }
      return snap.docs.map(d => ({ ...d.data(), id: d.id })) as ScenarioItem[];
    } catch (e) {
      console.warn('Firestore failed, loading offline styles:', e);
      return getLocalData<ScenarioItem[]>('scenarioItems', defaultScenarioItems);
    }
  },

  async updateScenarioItem(item: ScenarioItem): Promise<void> {
    const key = 'scenarioItems';
    if (isMockConfig) {
      const current = getLocalData<ScenarioItem[]>(key, defaultScenarioItems);
      const updated = current.map(x => x.id === item.id ? item : x);
      setLocalData(key, updated);
      return;
    }
    const path = `scenarioItems/${item.id}`;
    try {
      await setDoc(doc(db, 'scenarioItems', item.id), item);
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, path);
    }
  },

  async getActionPlans(): Promise<ActionPlan[]> {
    if (isMockConfig) {
      return getLocalData<ActionPlan[]>('actionPlans', defaultActionPlans);
    }
    const path = 'actionPlans';
    try {
      const snap = await getDocs(collection(db, path));
      if (snap.empty) {
        return defaultActionPlans;
      }
      return snap.docs.map(d => ({ ...d.data(), id: d.id })) as ActionPlan[];
    } catch (e) {
      console.warn('Firestore failed, loading offline action plans:', e);
      return getLocalData<ActionPlan[]>('actionPlans', defaultActionPlans);
    }
  },

  async getActions(): Promise<Action[]> {
    if (isMockConfig) {
      return getLocalData<Action[]>('actions', defaultActions);
    }
    const path = 'actions';
    try {
      const snap = await getDocs(collection(db, path));
      if (snap.empty) {
        return defaultActions;
      }
      return snap.docs.map(d => ({ ...d.data(), id: d.id })) as Action[];
    } catch (e) {
      console.warn('Firestore failed, loading offline in-season actions:', e);
      return getLocalData<Action[]>('actions', defaultActions);
    }
  },

  async updateAction(item: Action): Promise<void> {
    const key = 'actions';
    if (isMockConfig) {
      const current = getLocalData<Action[]>(key, defaultActions);
      const updated = current.map(x => x.id === item.id ? item : x);
      setLocalData(key, updated);
      return;
    }
    const path = `actions/${item.id}`;
    try {
      await setDoc(doc(db, 'actions', item.id), item);
    } catch (e) {
      handleFirestoreError(e, OperationType.WRITE, path);
    }
  }
};
