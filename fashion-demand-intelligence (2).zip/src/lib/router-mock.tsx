import React, { createContext, useContext, useState, ReactNode } from "react";
import { clusters } from "./cockpit-data";

export type NavigationContextType = {
  pathname: string;
  navigate: (options: { to: string; search?: any }) => void;
};

export const NavigationContext = createContext<NavigationContextType | null>(null);

export function NavigationProvider({ children, initialPath = "/data-setup" }: { children: ReactNode; initialPath?: string }) {
  const [pathname, setPathname] = useState(initialPath);
  const navigate = (options: { to: string; search?: any }) => {
    setPathname(options.to);
  };
  return (
    <NavigationContext.Provider value={{ pathname, navigate }}>
      {children}
    </NavigationContext.Provider>
  );
}

export function useNavigate() {
  const ctx = useContext(NavigationContext);
  if (!ctx || !ctx.navigate) {
    // Return a safe fallback mock in case context is absent (e.g., during setup)
    return (options: any) => {
      console.log('Mock navigating to', options);
    };
  }
  return ctx.navigate;
}

export function useRouterState(options?: { select?: (s: any) => any }) {
  const ctx = useContext(NavigationContext);
  const pathname = ctx?.pathname ?? "/data-setup";
  const state = { location: { pathname } };
  return options?.select ? options.select(state) : state;
}

export function Link({ to, children, className, ...props }: any) {
  const navigate = useNavigate();
  return (
    <a
      href={to}
      onClick={(e) => {
        e.preventDefault();
        navigate({ to });
      }}
      className={className}
      {...props}
    >
      {children}
    </a>
  );
}

export function createFileRoute(path: string) {
  const routeObj = {
    path,
    useLoaderData() {
      // Mock parameter loader
      return clusters.find((c) => c.slug === "ribbed-tanks") || clusters[0];
    }
  };
  return (config: any) => {
    return routeObj;
  };
}

export function notFound() {
  return new Error("Not Found");
}
