export interface HealthScore {
  label: string;
  value: string;
}

export interface SimilarItemRow {
  year: string;
  name: string;
  scores: string;
  outcome: string;
  note: string;
}

export interface WeatherRow {
  region: string;
  forecast: string;
  demandImpact: string;
  recommendedAction: string;
  tone: "green" | "red" | "gray" | "blue";
}

export interface RegionRow {
  region: string;
  baseAlloc: string;
  recAlloc: string;
  change: string;
  reason: string;
  action: string;
  tone: "green" | "red" | "gray" | "blue";
}

export interface InventoryRow {
  region: string;
  currentStock: string;
  weeklyVelocity: string;
  weeksCover: string;
  risk: string;
  recommendation: string;
  tone: "green" | "red" | "orange";
}

export interface ClusterDrawerDetails {
  slug: string;
  title: string;
  baseVsRecommended: string;
  recommendationText: string;
  confidence: string;
  decisionType: string;
  overview: {
    text: string;
    bullets: string[];
    benefit: string;
  };
  plc: {
    advice: string;
    current: number[];
    lastYear: number[];
    max: number[];
    min: number[];
    middle: number[];
  };
  similarItems: {
    scores: HealthScore[];
    table: SimilarItemRow[];
  };
  weather: {
    bullets: { type: "up" | "down"; label: string }[];
    table: WeatherRow[];
  };
  regions: {
    table: RegionRow[];
  };
  inventory: {
    table: InventoryRow[];
  };
}

export const drawerDetailsData: Record<string, ClusterDrawerDetails> = {
  "ribbed-tanks": {
    slug: "ribbed-tanks",
    title: "Ribbed Tanks",
    baseVsRecommended: "5,800 -> 7,200 (+1,400 units (24.1%))",
    recommendationText: "STRONG INCREASE",
    confidence: "High 92%",
    decisionType: "Early Summer Stockout Avoidance",
    overview: {
      text: "Score: 90. Based on rapid early season sell-through (94%) & search trends (92%). The stock is burning through faster than the baseline PLC. Highly recommended to expedite the shipment.",
      bullets: [
        "Summer tank search terms surged +45% earlier than traditional seasonal start in Madrid-sur.",
        "SS24 sales records show that Ribbed Tanks suffer from a high stockout elasticity (W4 stockout lost €80k peak demand).",
        "Recommended regional increase is centered on Andalusian stores, which have a prolonged hot season."
      ],
      benefit: "+21.4% Sell-through | -$120k Stockout Risk"
    },
    plc: {
      advice: "Actual sales velocity is trending near the absolute Max boundary line. Without an immediate increase, stockouts will occur by Week 6 (current is Week 5). Curves are descending as part of the standard seasonal decay.",
      current: [100, 95, 87, 82, 79],
      lastYear: [98, 93, 85, 80, 75, 70, 65, 58, 50, 42, 35, 25],
      max: [100, 100, 98, 95, 92, 88, 82, 75, 65, 55, 45, 30],
      min: [90, 85, 75, 68, 60, 52, 45, 38, 30, 22, 15, 8],
      middle: [95, 90, 82, 74, 68, 61, 54, 46, 38, 28, 20, 12]
    },
    similarItems: {
      scores: [
        { label: "VISUAL", value: "94%" },
        { label: "MATERIAL", value: "89%" },
        { label: "TEXT", value: "91%" },
        { label: "PRICE-BAND", value: "98%" },
        { label: "CUSTOMER-PERC.", value: "85%" }
      ],
      table: [
        { year: "2024", name: "Premium Rib Tank", scores: "V:94% M:89% P:98%", outcome: "Stockout W4", note: "Ran out of white early; lost €140K in demand" },
        { year: "2024", name: "Crop Rib Tank", scores: "V:85% M:80% P:95%", outcome: "Sold out W10", note: "Successful clearance; clean flow" },
        { year: "2023", name: "Classic Cotton Tank", scores: "V:90% M:85% P:90%", outcome: "Clean clearance", note: "Solid baseline performance" }
      ]
    },
    weather: {
      bullets: [
        { type: "up", label: "Demand expands when temperatures surge above 25°C early in Southern Spain" },
        { type: "down", label: "Demand slightly impacted during rainy weeks, but has high carry-over" }
      ],
      table: [
        { region: "Seville", forecast: "+5.1°C hot/dry", demandImpact: "+42%", recommendedAction: "EXPEDITE ALLOCATION", tone: "green" },
        { region: "Madrid", forecast: "+3.2°C sunny", demandImpact: "+28%", recommendedAction: "INCREASE STOCK", tone: "green" },
        { region: "Valencia", forecast: "warm + dry", demandImpact: "+15%", recommendedAction: "MAINTAIN", tone: "green" },
        { region: "Barcelona", forecast: "normal", demandImpact: "+5%", recommendedAction: "MAINTAIN", tone: "gray" },
        { region: "Bilbao", forecast: "cooler rain", demandImpact: "-5%", recommendedAction: "MAINTAIN OR PROTECT", tone: "red" }
      ]
    },
    regions: {
      table: [
        { region: "Seville", baseAlloc: "1,200", recAlloc: "1,800", change: "+600", reason: "Heatwave and low local cover", action: "EXPEDITE SHIPMENT", tone: "green" },
        { region: "Madrid", baseAlloc: "1,400", recAlloc: "1,800", change: "+400", reason: "Sunny temperature rise", action: "INCREASE BULK", tone: "green" },
        { region: "Valencia", baseAlloc: "1,000", recAlloc: "1,200", change: "+200", reason: "Normal warm summer start", action: "MAINTAIN", tone: "blue" },
        { region: "Barcelona", baseAlloc: "1,300", recAlloc: "1,300", change: "0", reason: "Stable tourist demand", action: "MAINTAIN", tone: "gray" },
        { region: "Bilbao", baseAlloc: "900", recAlloc: "1,100", change: "+200", reason: "Delayed spring warming", action: "MAINTAIN", tone: "blue" }
      ]
    },
    inventory: {
      table: [
        { region: "Seville", currentStock: "850", weeklyVelocity: "280", weeksCover: "3.0w", risk: "HIGH STOCKOUT RISK", recommendation: "increase replenishment", tone: "red" },
        { region: "Madrid", currentStock: "1,100", weeklyVelocity: "210", weeksCover: "5.2w", risk: "HEALTHY", recommendation: "maintain normal speed", tone: "green" },
        { region: "Valencia", currentStock: "420", weeklyVelocity: "180", weeksCover: "2.3w", risk: "WATCH RISK", recommendation: "replenish immediately", tone: "orange" },
        { region: "Barcelona", currentStock: "980", weeklyVelocity: "160", weeksCover: "6.1w", risk: "HEALTHY", recommendation: "maintain", tone: "green" },
        { region: "Bilbao", currentStock: "650", weeklyVelocity: "90", weeksCover: "7.2w", risk: "SLIGHTLY HIGH", recommendation: "restrict replenishment", tone: "orange" }
      ]
    }
  },
  "linen-shirts": {
    slug: "linen-shirts",
    title: "Linen Shirts",
    baseVsRecommended: "12,000 -> 13,800 (+1,800 units (15.0%))",
    recommendationText: "INCREASE",
    confidence: "High 88%",
    decisionType: "Weather Event Adjustment",
    overview: {
      text: "Score: 85. Based on weather (95%) & search trends (85%). Increase buy and pull forward allocation in warm regions. This adjusts for immediate term weather volatility while securing margin in historically reliable clusters.",
      bullets: [
        "Similarity models show high elasticity to early season stockouts based on 2024 performance of lightweight synthetics.",
        "Weather data predicts a +3°C heatwave accelerating summer transition by 14 days in southern EU markets.",
        "Current baseline allocation leaves northern stores under-serviced during their peak rain season in late August."
      ],
      benefit: "+14.2% Sell-through | -$420k Weather Markdown Risk"
    },
    plc: {
      advice: "Overall actual sales are pacing slightly above the median, driven by a pull-forward in early summer demand. The forecasted trajectory indicates an overall cluster-level stockout risk around Week 8 if unadjusted.",
      current: [100, 92, 83, 75, 68],
      lastYear: [97, 89, 80, 72, 65, 58, 52, 45, 38, 30, 22, 14],
      max: [100, 95, 88, 81, 74, 67, 60, 52, 44, 35, 26, 16],
      min: [90, 81, 72, 63, 55, 47, 40, 32, 25, 18, 11, 4],
      middle: [95, 86, 78, 70, 62, 54, 46, 38, 30, 22, 14, 8]
    },
    similarItems: {
      scores: [
        { label: "VISUAL", value: "88%" },
        { label: "MATERIAL", value: "92%" },
        { label: "TEXT", value: "81%" },
        { label: "PRICE-BAND", value: "95%" },
        { label: "CUSTOMER-PERC.", value: "85%" }
      ],
      table: [
        { year: "2024", name: "Light Nylon Jacket", scores: "V:88% M:92% P:95%", outcome: "Stockout W6", note: "Under-planned, missed upside" },
        { year: "2024", name: "Rain Shell Shirt Jacket", scores: "V:75% M:85% P:90%", outcome: "MD 15%", note: "Overbought in South" },
        { year: "2023", name: "Compact Windbreaker", scores: "V:82% M:70% P:85%", outcome: "Clean clearance", note: "Good baseline" },
        { year: "2023", name: "Thin Utility Jacket", scores: "V:65% M:75% P:80%", outcome: "High return rate", note: "Fit issue early season" }
      ]
    },
    weather: {
      bullets: [
        { type: "up", label: "Demand increases when temperature is above 22°C" },
        { type: "up", label: "Demand increases when sunny sky probability is above 60%" },
        { type: "down", label: "Demand decreases when temperature stays below 18°C for 3 consecutive days" },
        { type: "down", label: "Demand decreases when unseasonal rain/cool weather continues" }
      ],
      table: [
        { region: "Seville", forecast: "+4.2°C dry", demandImpact: "+32%", recommendedAction: "EXPEDITE LOGISTICS", tone: "green" },
        { region: "Madrid", forecast: "+2.1°C dry", demandImpact: "+18%", recommendedAction: "STRENGTHEN ALLOCATION", tone: "green" },
        { region: "Valencia", forecast: "warm + light rain", demandImpact: "+5%", recommendedAction: "MAINTAIN", tone: "green" },
        { region: "Barcelona", forecast: "normal", demandImpact: "+3%", recommendedAction: "MAINTAIN", tone: "gray" },
        { region: "Bilbao", forecast: "rain + cooler", demandImpact: "-12%", recommendedAction: "REDUCE EARLY ALLOCATION", tone: "red" }
      ]
    },
    regions: {
      table: [
        { region: "Seville", baseAlloc: "2,100", recAlloc: "2,900", change: "+800", reason: "heat lowers jacket/expands linen demand", action: "EXPEDITE ALLOCATION", tone: "green" },
        { region: "Madrid", baseAlloc: "1,800", recAlloc: "2,200", change: "+400", reason: "dry warm forecast", action: "STRENGTHEN DISPLAY", tone: "green" },
        { region: "Valencia", baseAlloc: "1,600", recAlloc: "1,700", change: "+100", reason: "normal weather progression", action: "MAINTAIN", tone: "blue" },
        { region: "Barcelona", baseAlloc: "1,900", recAlloc: "1,900", change: "0", reason: "stable tourist demand", action: "MAINTAIN", tone: "gray" },
        { region: "Bilbao", baseAlloc: "1,200", recAlloc: "900", change: "-300", reason: "rainy and cooler weather", action: "REDUCE ALLOCATION", tone: "red" }
      ]
    },
    inventory: {
      table: [
        { region: "Seville", currentStock: "1,850", weeklyVelocity: "325", weeksCover: "5.7w", risk: "HEALTHY", recommendation: "maintain normal speed", tone: "green" },
        { region: "Madrid", currentStock: "1,420", weeklyVelocity: "220", weeksCover: "6.4w", risk: "HEALTHY", recommendation: "maintain", tone: "green" },
        { region: "Valencia", currentStock: "860", weeklyVelocity: "290", weeksCover: "3.0w", risk: "STOCKOUT RISK", recommendation: "trigger replenishment", tone: "red" },
        { region: "Barcelona", currentStock: "940", weeklyVelocity: "310", weeksCover: "3.0w", risk: "STOCKOUT RISK", recommendation: "trigger replenishment", tone: "red" },
        { region: "Bilbao", currentStock: "1,200", weeklyVelocity: "150", weeksCover: "8.0w", risk: "OVERSTOCK RISK", recommendation: "stop replenishment", tone: "red" }
      ]
    }
  },
  "lightweight-dresses": {
    slug: "lightweight-dresses",
    title: "Lightweight Dresses",
    baseVsRecommended: "8,000 -> 8,900 (+900 units (11.2%))",
    recommendationText: "SELECTIVE INCREASE",
    confidence: "Medium 79%",
    decisionType: "Regional Hot Spring Opportunity",
    overview: {
      text: "Score: 78. Based on weather patterns (90%) and material search index in Mediterranean markets. Highly seasonal; earlier demand shift is predicted in coastal regions.",
      bullets: [
        "Lightweight structures show positive engagement under sunny triggers (+18% in Barcelona and Seville).",
        "SS24 stock clearance was extremely clean but understocked during peak tourist months.",
        "A 14-day earlier summer window is highly likely in Seville and Valencia based on meteorology."
      ],
      benefit: "+11.5% Sell-through | -$180K Carryover Markdown"
    },
    plc: {
      advice: "Overall demand is accelerating early this season. Current actuals are trending above target boundaries. Forecast points to stock running thin by Week 9.",
      current: [100, 94, 86, 79, 72],
      lastYear: [97, 91, 82, 75, 68, 61, 54, 47, 40, 31, 23, 14],
      max: [100, 96, 89, 82, 75, 68, 61, 53, 45, 36, 27, 18],
      min: [92, 84, 75, 66, 58, 50, 42, 34, 27, 20, 13, 6],
      middle: [96, 88, 80, 72, 64, 56, 48, 40, 32, 24, 16, 10]
    },
    similarItems: {
      scores: [
        { label: "VISUAL", value: "86%" },
        { label: "MATERIAL", value: "94%" },
        { label: "TEXT", value: "79%" },
        { label: "PRICE-BAND", value: "88%" },
        { label: "CUSTOMER-PERC.", value: "80%" }
      ],
      table: [
        { year: "2024", name: "Sleeveless Linen Dress", scores: "V:86% M:94% P:88%", outcome: "Sold out W9", note: "Strong sales in Barcelona and Seville" },
        { year: "2023", name: "Summer Strap Dress", scores: "V:81% M:90% P:82%", outcome: "Clean clearance", note: "Solid baseline data" }
      ]
    },
    weather: {
      bullets: [
        { type: "up", label: "Demand climbs quickly when temp rises above 24°C" },
        { type: "down", label: "Overly high relative humidity has a negative drag in Madrid" }
      ],
      table: [
        { region: "Seville", forecast: "+3.9°C dry", demandImpact: "+26%", recommendedAction: "INCREASE ALLOCATION", tone: "green" },
        { region: "Barcelona", forecast: "+2.5°C sunny", demandImpact: "+19%", recommendedAction: "REINFORCE STORES", tone: "green" },
        { region: "Valencia", forecast: "sunny coastal", demandImpact: "+12%", recommendedAction: "MAINTAIN", tone: "blue" },
        { region: "Madrid", forecast: "normal dry", demandImpact: "+2%", recommendedAction: "MAINTAIN", tone: "gray" },
        { region: "Bilbao", forecast: "cool rain", demandImpact: "-8%", recommendedAction: "REDUCE EARLY ALLOC", tone: "red" }
      ]
    },
    regions: {
      table: [
        { region: "Seville", baseAlloc: "1,500", recAlloc: "1,900", change: "+400", reason: "Strong coastal tourism potential", action: "EXPEDITE DRUM", tone: "green" },
        { region: "Barcelona", baseAlloc: "1,700", recAlloc: "2,050", change: "+350", reason: "Tourist hot spots peak acceleration", action: "INCREASE STOCK", tone: "green" },
        { region: "Valencia", baseAlloc: "1,300", recAlloc: "1,450", change: "+150", reason: "Slight humidity surge offset", action: "MAINTAIN", tone: "blue" },
        { region: "Madrid", baseAlloc: "1,600", recAlloc: "1,600", change: "0", reason: "Slightly low dry interest", action: "MAINTAIN", tone: "gray" },
        { region: "Bilbao", baseAlloc: "1,000", recAlloc: "900", change: "-100", reason: "Rain forecast delay", action: "REDUCE", tone: "red" }
      ]
    },
    inventory: {
      table: [
        { region: "Seville", currentStock: "980", weeklyVelocity: "185", weeksCover: "5.3w", risk: "HEALTHY", recommendation: "maintain and watch", tone: "green" },
        { region: "Barcelona", currentStock: "620", weeklyVelocity: "240", weeksCover: "2.5w", risk: "CRITICALカバー", recommendation: "expedite transfer", tone: "red" },
        { region: "Valencia", currentStock: "540", weeklyVelocity: "135", weeksCover: "4.0w", risk: "HEALTHY", recommendation: "maintain", tone: "green" },
        { region: "Madrid", currentStock: "1,100", weeklyVelocity: "160", weeksCover: "6.8w", risk: "SLIGHTLY HIGH", recommendation: "monitor velocity", tone: "orange" },
        { region: "Bilbao", currentStock: "850", weeklyVelocity: "75", weeksCover: "11.3w", risk: "OVERSTOCK RISK", recommendation: "restrain replen", tone: "red" }
      ]
    }
  },
  "crochet-tops": {
    slug: "crochet-tops",
    title: "Crochet Tops",
    baseVsRecommended: "2,000 -> 2,500 (+500 units (25.0%))",
    recommendationText: "INCREASE",
    confidence: "Medium 74%",
    decisionType: "New Trend Wave Capture",
    overview: {
      text: "Score: 74. Driven by rapid social media-backed search indexing on lightweight textured tops. Early season signals in Ibiza and Barcelona show highly positive conversion rates.",
      bullets: [
        "Search trends for 'crochet sleeveless' in Spain rose +67% in last 3 weeks.",
        "High affinity with young demographics in coastal metropolitan zones.",
        "Supply pipeline has a 4-week lead time; taking action now secures prime summer stock."
      ],
      benefit: "+25.3% Margin Uplift | -$45K Stockout Penalty"
    },
    plc: {
      advice: "Sales are tracing a steep initial ramp, currently above middle estimates. Order-up-to is recommended to avoid missing the trend crest at Week 7. Standard lifecycle decay is shown on the curves.",
      current: [100, 93, 85, 78, 70],
      lastYear: [96, 88, 79, 71, 63, 55, 48, 41, 33, 25, 18, 9],
      max: [100, 94, 86, 79, 72, 64, 56, 48, 40, 31, 23, 14],
      min: [90, 80, 71, 62, 53, 45, 37, 30, 23, 16, 10, 3],
      middle: [95, 85, 76, 68, 59, 51, 43, 35, 27, 20, 13, 8]
    },
    similarItems: {
      scores: [
        { label: "VISUAL", value: "91%" },
        { label: "MATERIAL", value: "85%" },
        { label: "TEXT", value: "94%" },
        { label: "PRICE-BAND", value: "90%" },
        { label: "CUSTOMER-PERC.", value: "82%" }
      ],
      table: [
        { year: "2024", name: "Knit Halter Crop Top", scores: "V:91% M:85% P:90%", outcome: "Sold out W7", note: "Highly viral style; ran out of tan colorway" },
        { year: "2023", name: "Macrame Summer Top", scores: "V:78% M:72% P:81%", outcome: "Clean clearance", note: "Solid baseline" }
      ]
    },
    weather: {
      bullets: [
        { type: "up", label: "Early hot transitions yield double-digit search interest boosts" },
        { type: "down", label: "Damp cold weather significantly dampens metropolitan checkout flow" }
      ],
      table: [
        { region: "Seville", forecast: "+4.1°C dry", demandImpact: "+18%", recommendedAction: "INCREASE BULK ALLOC", tone: "green" },
        { region: "Barcelona", forecast: "+2.3°C coastal", demandImpact: "+15%", recommendedAction: "INCREASE BULK ALLOC", tone: "green" },
        { region: "Valencia", forecast: "sunny coastal", demandImpact: "+8%", recommendedAction: "MAINTAIN", tone: "blue" },
        { region: "Madrid", forecast: "normal dry", demandImpact: "+5%", recommendedAction: "MAINTAIN", tone: "gray" },
        { region: "Bilbao", forecast: "wet + cooler", demandImpact: "-5%", recommendedAction: "MAINTAIN OR COUPLING", tone: "red" }
      ]
    },
    regions: {
      table: [
        { region: "Seville", baseAlloc: "400", recAlloc: "550", change: "+150", reason: "heatwave accelerates premium knit peak", action: "COUPLE REPLENISH", tone: "green" },
        { region: "Barcelona", baseAlloc: "500", recAlloc: "650", change: "+150", reason: "coastal social trend acceleration", action: "INCREASE STOCK", tone: "green" },
        { region: "Valencia", baseAlloc: "300", recAlloc: "380", change: "+80", reason: "stable demand escalation", action: "MAINTAIN", tone: "blue" },
        { region: "Madrid", baseAlloc: "500", recAlloc: "550", change: "+50", reason: "moderate metropolitan interest", action: "MAINTAIN", tone: "blue" },
        { region: "Bilbao", baseAlloc: "300", recAlloc: "270", change: "-30", reason: "prolonged gray cool window", action: "REDUCE", tone: "red" }
      ]
    },
    inventory: {
      table: [
        { region: "Seville", currentStock: "210", weeklyVelocity: "60", weeksCover: "3.5w", risk: "HEALTHY", recommendation: "maintain", tone: "green" },
        { region: "Barcelona", currentStock: "120", weeklyVelocity: "65", weeksCover: "1.8w", risk: "CRITICAL COVER", recommendation: "replenish immediately", tone: "red" },
        { region: "Valencia", currentStock: "180", weeklyVelocity: "42", weeksCover: "4.2w", risk: "HEALTHY", recommendation: "maintain", tone: "green" },
        { region: "Madrid", currentStock: "350", weeklyVelocity: "55", weeksCover: "6.3w", risk: "HEALTHY", recommendation: "maintain", tone: "green" },
        { region: "Bilbao", currentStock: "280", weeklyVelocity: "20", weeksCover: "14.0w", risk: "OVERSTOCK RISK", recommendation: "stop replenishment", tone: "red" }
      ]
    }
  },
  "wide-leg-pants": {
    slug: "wide-leg-pants",
    title: "Wide Leg Pants",
    baseVsRecommended: "4,200 -> 4,600 (+400 units (9.5%))",
    recommendationText: "SELECTIVE INCREASE",
    confidence: "Medium 73%",
    decisionType: "Urban Core Demand Alignment",
    overview: {
      text: "Score: 73. Backed by solid baseline performance (88%) in core urban stores (Madrid & Barcelona). Elasticity is high in central business district branches.",
      bullets: [
        "Search indices for 'wide leg linen trousers' are up +35% in Madrid central.",
        "Sell-through velocities are stable but stock depth is thin in metropolitan locations.",
        "Selective regional increase in core hubs minimizes overstock risk in northern warehouses."
      ],
      benefit: "+9.2% Sell-through | -$28K Overstock Carryover"
    },
    plc: {
      advice: "Actual sales trace a stable, slow lifecycle curve. Current sales align with the target median trajectory. Selected increases keep stock healthy during major city holidays. Descending PLC is integrated.",
      current: [100, 95, 90, 85, 81],
      lastYear: [98, 92, 86, 80, 74, 68, 62, 56, 49, 41, 31, 20],
      max: [100, 96, 91, 85, 80, 74, 68, 62, 54, 46, 36, 25],
      min: [90, 84, 78, 71, 65, 59, 52, 45, 38, 30, 21, 12],
      middle: [95, 90, 84, 78, 72, 66, 60, 53, 46, 38, 29, 18]
    },
    similarItems: {
      scores: [
        { label: "VISUAL", value: "85%" },
        { label: "MATERIAL", value: "90%" },
        { label: "TEXT", value: "89%" },
        { label: "PRICE-BAND", value: "92%" },
        { label: "CUSTOMER-PERC.", value: "81%" }
      ],
      table: [
        { year: "2024", name: "Utility Wide Cargo Pants", scores: "V:85% M:90% P:92%", outcome: "Sold out W11", note: "Stable sales, clean runout" },
        { year: "2023", name: "Relaxed Trouser Pant", scores: "V:75% M:80% P:85%", outcome: "Clean clearance", note: "Solid background index" }
      ]
    },
    weather: {
      bullets: [
        { type: "up", label: "Stable urban demand; mildly responsive to warm pleasant afternoons" },
        { type: "down", label: "Intense heat spikes (>35°C) slightly drag down long pants purchases" }
      ],
      table: [
        { region: "Madrid", forecast: "+2.1°C dry", demandImpact: "+14%", recommendedAction: "STRENGTHEN BULK ALLOC", tone: "green" },
        { region: "Barcelona", forecast: "stable normal", demandImpact: "+10%", recommendedAction: "REINFORCE STORES", tone: "green" },
        { region: "Seville", forecast: "+4.5°C hot", demandImpact: "-5%", recommendedAction: "MAINTAIN OR LOWER", tone: "red" },
        { region: "Valencia", forecast: "stable warm", demandImpact: "+5%", recommendedAction: "MAINTAIN", tone: "gray" },
        { region: "Bilbao", forecast: "normal rain", demandImpact: "+2%", recommendedAction: "MAINTAIN", tone: "gray" }
      ]
    },
    regions: {
      table: [
        { region: "Madrid", baseAlloc: "1,200", recAlloc: "1,450", change: "+250", reason: "urban business district interest surge", action: "INCREASE STOCK", tone: "green" },
        { region: "Barcelona", baseAlloc: "1,100", recAlloc: "1,250", change: "+150", reason: "metropolitan fashion trend", action: "INCREASE STOCK", tone: "green" },
        { region: "Seville", baseAlloc: "700", recAlloc: "650", change: "-50", reason: "extreme afternoon temperatures drag pants", action: "REDUCE ALLOC", tone: "red" },
        { region: "Valencia", baseAlloc: "800", recAlloc: "800", change: "0", reason: "stable city baseline", action: "MAINTAIN", tone: "gray" },
        { region: "Bilbao", baseAlloc: "400", recAlloc: "450", change: "+50", reason: "mild coastal breeze interest", action: "MAINTAIN", tone: "blue" }
      ]
    },
    inventory: {
      table: [
        { region: "Madrid", currentStock: "450", weeklyVelocity: "95", weeksCover: "4.7w", risk: "HEALTHY", recommendation: "maintain", tone: "green" },
        { region: "Barcelona", currentStock: "210", weeklyVelocity: "80", weeksCover: "2.6w", risk: "WATCH RISK", recommendation: "replenish soon", tone: "orange" },
        { region: "Seville", currentStock: "480", weeklyVelocity: "45", weeksCover: "10.6w", risk: "SLIGHT OVERSTOCK", recommendation: "stop replenishment", tone: "orange" },
        { region: "Valencia", currentStock: "320", weeklyVelocity: "60", weeksCover: "5.3w", risk: "HEALTHY", recommendation: "maintain", tone: "green" },
        { region: "Bilbao", currentStock: "190", weeklyVelocity: "40", weeksCover: "4.7w", risk: "HEALTHY", recommendation: "maintain", tone: "green" }
      ]
    }
  }
};
