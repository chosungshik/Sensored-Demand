# Security Specification: Fashion Demand Intelligence Firestore DB

## 1. Data Invariants
- **Authentication Requirement**: No unauthenticated reads or writes are permitted anywhere in the database.
- **State Integrity**:
  - `budgetAllocated` must be a positive number.
  - `projectedSellThrough` must be a number between 0 and 100.
  - `dataHealthScore` must be a number between 0 and 100.
- **Terminal State Locking**:
  - If a scenario has its status set to `"Confirmed"`, it is locked and cannot be edited by standard client writes.
- **Field Immutability**:
  - `createdAt` values for items must be fixed at document creation and never changed.
- **Value Constraints**:
  - `status` for `actions` must only be one of `"Pending"`, `"Sent"`, `"Dismissed"`.
  - `status` for `scenarioItems` must only be `"Included"`, `"Excluded"`.

---

## 2. The "Dirty Dozen" Malicious Payloads

1. **Unauthenticated Read**: An anonymous attacker tries to read planning scenarios.
2. **Resource Poisoning (Long ID)**: Writing a document with an ID larger than 128 characters or containing illegal directory-traversal characters.
3. **Negative Budget Injection**: Creating a scenario with `budgetAllocated = -500000`.
4. **Invalid Sell Through Value**: Creating a scenario with `projectedSellThrough = 150` (exceeding 100%).
5. **Arbitrary Status Mod**: Setting `scenarioItems` status to `"Destroyed"` instead of `"Included"` or `"Excluded"`.
6. **Shadow Fields Injection**: Creating a scenario document with unmapped keys (`hackedField: true`).
7. **Bypassing Terminal State Locking**: Updating the `budgetAllocated` of a Scenario whose status is already `'Confirmed'`.
8. **Malicious ID reference**: Assigning a `scenarioId` with invalid string characters (e.g., `../../../etc/passwd`).
9. **Malicious Date Spoofing**: Setting `createdAt` to a future year 2045 instead of rules-mandated server time.
10. **Denial of Wallet String Sizing**: Creating an action item with a 1MB arbitrary string in the description.
11. **Privilege Escalation**: Adding an field `role: "admin"` to a standard dataSetup record to try to gain custom claims.
12. **Bypassing Status Enumeration**: Modifying an action's status to `"Approved"` (illegal state transition).

---

## 3. Test Runner Schema (firestore.rules.test.ts)
The verification tests will assert that each of the "Dirty Dozen" attempts fails with `PERMISSION_DENIED` status. 
All queries and updates must enforce proper checks against authenticated user states.
