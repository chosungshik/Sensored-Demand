import { execSync } from 'child_process';
import * as fs from 'fs';
import * as https from 'https';

const zipUrl = 'https://raw.githubusercontent.com/chosungshik/Sensored-Demand/main/Demand%20Navigator.zip';
const zipPath = './Demand_Navigator.zip';
const extractDir = './Lovable_Source';

function downloadFile(url: string, dest: string): Promise<void> {
  return new Promise((resolve, reject) => {
    https.get(url, (response) => {
      if (response.statusCode === 302 || response.statusCode === 301) {
        // Handle redirect
        downloadFile(response.headers.location!, dest).then(resolve).catch(reject);
        return;
      }
      if (response.statusCode !== 200) {
        reject(new Error(`Failed to download: ${response.statusCode}`));
        return;
      }
      const file = fs.createWriteStream(dest);
      response.pipe(file);
      file.on('finish', () => {
        file.close();
        resolve();
      });
    }).on('error', (err) => {
      fs.unlinkSync(dest);
      reject(err);
    });
  });
}

async function run() {
  console.log('Downloading zip file...');
  try {
    await downloadFile(zipUrl, zipPath);
    console.log('Downloaded successfully. Extracting...');
    
    // Try to unzip using the OS command utility (which is faster and simpler)
    try {
      execSync(`mkdir -p ${extractDir} && unzip -o ${zipPath} -d ${extractDir}`);
      console.log('Extraction completed successfully using OS unzip.');
    } catch (err: any) {
      console.error('OS unzip failed or was not available, trying adm-zip or native tools:', err.message);
      // Fallback or print file info
    }
  } catch (err) {
    console.error('Extraction script error:', err);
  }
}

run();
