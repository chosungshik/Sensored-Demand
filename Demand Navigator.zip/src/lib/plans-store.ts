import { useSyncExternalStore } from "react";

export type PlanStatus = "Saved" | "Draft" | "Ready" | "Exported";
export type PlanItem = { name: string; status: PlanStatus };

type PlansState = {
  scenarios: PlanItem[];
  scenarioName: string;
  scenarioSaved: boolean;
  actionPlans: PlanItem[];
  actionPlanName: string;
  actionPlanSaved: boolean;
};

let state: PlansState = {
  scenarios: [
    { name: "SS25 Spain Planning Scenario", status: "Saved" },
    { name: "SS25 Spain Warm Weather Upside", status: "Draft" },
    { name: "SS25 Spain Conservative Buy", status: "Draft" },
    { name: "SS25 Spain Exported Plan", status: "Exported" },
  ],
  scenarioName: "SS25 Spain Planning Scenario",
  scenarioSaved: false,
  actionPlans: [
    { name: "Seville Warm-Weather Response", status: "Saved" },
    { name: "Valencia Linen Shirt Recovery", status: "Draft" },
    { name: "Spain Low Cover Response", status: "Ready" },
    { name: "Madrid Markdown Risk Actions", status: "Exported" },
  ],
  actionPlanName: "Seville Warm-Weather Response",
  actionPlanSaved: false,
};

const listeners = new Set<() => void>();
function emit() { for (const l of listeners) l(); }

function upsertPlan(list: PlanItem[], name: string, status: PlanStatus): PlanItem[] {
  const i = list.findIndex((p) => p.name === name);
  if (i === -1) return [{ name, status }, ...list];
  const next = [...list];
  next[i] = { name, status };
  return next;
}

export const plansStore = {
  getState: () => state,
  subscribe(l: () => void) { listeners.add(l); return () => listeners.delete(l); },
  saveScenario(name: string) {
    const trimmed = name.trim() || state.scenarioName;
    state = {
      ...state,
      scenarioName: trimmed,
      scenarioSaved: true,
      scenarios: upsertPlan(state.scenarios, trimmed, "Saved"),
    };
    emit();
  },
  selectScenario(name: string) {
    state = { ...state, scenarioName: name, scenarioSaved: true };
    emit();
  },
  saveActionPlan(name: string) {
    const trimmed = name.trim() || state.actionPlanName;
    state = {
      ...state,
      actionPlanName: trimmed,
      actionPlanSaved: true,
      actionPlans: upsertPlan(state.actionPlans, trimmed, "Saved"),
    };
    emit();
  },
  selectActionPlan(name: string) {
    state = { ...state, actionPlanName: name, actionPlanSaved: true };
    emit();
  },
};

export function usePlansState() {
  return useSyncExternalStore(plansStore.subscribe, plansStore.getState, plansStore.getState);
}