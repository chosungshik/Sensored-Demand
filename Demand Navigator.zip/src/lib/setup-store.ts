import { useSyncExternalStore } from "react";

type SetupState = {
  complete: boolean;
  profile: string;
  dataHealth: number;
};

const KEY = "fdi-setup-v1";

function load(): SetupState {
  if (typeof window === "undefined") {
    return { complete: false, profile: "Online + Offline Stores", dataHealth: 0 };
  }
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) return JSON.parse(raw) as SetupState;
  } catch {}
  return { complete: false, profile: "Online + Offline Stores", dataHealth: 0 };
}

let state: SetupState = load();
const listeners = new Set<() => void>();
function emit() {
  if (typeof window !== "undefined") {
    try { localStorage.setItem(KEY, JSON.stringify(state)); } catch {}
  }
  for (const l of listeners) l();
}

export const setupStore = {
  getState: () => state,
  subscribe(l: () => void) { listeners.add(l); return () => listeners.delete(l); },
  setProfile(profile: string) { state = { ...state, profile }; emit(); },
  completeSetup(dataHealth = 92) {
    state = { ...state, complete: true, dataHealth };
    emit();
  },
  reset() {
    state = { complete: false, profile: "Online + Offline Stores", dataHealth: 0 };
    emit();
  },
};

export function useSetupState() {
  return useSyncExternalStore(
    setupStore.subscribe,
    setupStore.getState,
    () => ({ complete: false, profile: "Online + Offline Stores", dataHealth: 0 }),
  );
}
