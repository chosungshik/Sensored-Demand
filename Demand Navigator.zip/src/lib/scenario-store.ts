import { useSyncExternalStore } from "react";

export type RegionBuy = { name: string; min: number; max: number; defaultInclude: boolean };

// Per-style region-level buy contribution. Keep here so both the drawer and
// the scenario summary read from a single source of truth.
export const STYLE_REGION_BUY: Record<string, RegionBuy[]> = {
  "RT-001-WHT": [
    { name: "Seville", min: 140, max: 190, defaultInclude: true },
    { name: "Valencia", min: 80, max: 130, defaultInclude: true },
    { name: "Barcelona", min: 40, max: 70, defaultInclude: true },
    { name: "Madrid", min: 0, max: 20, defaultInclude: false },
    { name: "Bilbao", min: 0, max: 10, defaultInclude: false },
  ],
};

// Approx euro upside per unit (matches the existing ~€80K @ 140 / €110K @ 190 ratio).
const EURO_PER_UNIT = 0.57; // in thousands of EUR

export type StyleAdjustment = {
  keepInScenario: boolean;
  regionInclude: Record<string, boolean>;
};

export function defaultAdjustment(sku: string): StyleAdjustment {
  const regions = STYLE_REGION_BUY[sku] ?? [];
  return {
    keepInScenario: true,
    regionInclude: Object.fromEntries(regions.map((r) => [r.name, r.defaultInclude])),
  };
}

export type TimingDecision = "applied" | "baseline";
type State = {
  adjustments: Record<string, StyleAdjustment>;
  timing: Record<string, TimingDecision>;
};
let state: State = { adjustments: {}, timing: {} };
const listeners = new Set<() => void>();

function emit() {
  for (const l of listeners) l();
}

export const scenarioStore = {
  getState: () => state,
  subscribe(listener: () => void) {
    listeners.add(listener);
    return () => listeners.delete(listener);
  },
  setAdjustment(sku: string, next: StyleAdjustment) {
    state = { ...state, adjustments: { ...state.adjustments, [sku]: next } };
    emit();
  },
  setTiming(region: string, next: TimingDecision | undefined) {
    const timing = { ...state.timing };
    if (next === undefined) delete timing[region];
    else timing[region] = next;
    state = { ...state, timing };
    emit();
  },
};

export function useScenarioState() {
  return useSyncExternalStore(scenarioStore.subscribe, scenarioStore.getState, scenarioStore.getState);
}

export type Contribution = { min: number; max: number; included: boolean };

export function styleContribution(sku: string, adj?: StyleAdjustment): Contribution {
  const regions = STYLE_REGION_BUY[sku];
  if (!regions) return { min: 0, max: 0, included: true };
  const a = adj ?? defaultAdjustment(sku);
  if (!a.keepInScenario) return { min: 0, max: 0, included: false };
  const on = regions.filter((r) => a.regionInclude[r.name]);
  return {
    min: on.reduce((s, r) => s + r.min, 0),
    max: on.reduce((s, r) => s + r.max, 0),
    included: true,
  };
}

export function defaultContribution(sku: string): Contribution {
  return styleContribution(sku, defaultAdjustment(sku));
}

function fmtUnits(n: number) {
  return n.toString();
}

export function fmtChangeRange(c: Contribution) {
  if (!c.included || (c.min === 0 && c.max === 0)) return "No increase";
  return `+${fmtUnits(c.min)} – +${fmtUnits(c.max)} units`;
}

export function fmtBuyRange(currentPlan: number, c: Contribution) {
  return `${currentPlan + c.min} – ${currentPlan + c.max}`;
}

export function upsideK(c: Contribution): { min: number; max: number } {
  return { min: Math.round(c.min * EURO_PER_UNIT), max: Math.round(c.max * EURO_PER_UNIT) };
}

export function fmtUpsideEuroK(c: Contribution) {
  if (!c.included || (c.min === 0 && c.max === 0)) return "€0 – €0";
  const u = upsideK(c);
  return `€${u.min}K – €${u.max}K`;
}

// --- Scenario-wide aggregation helpers ---

// Adjust a baseline numeric range by the delta caused by user toggles.
// baseRange is the value shown by default; we add (current - default) per tracked sku.
export function adjustedUnits(baseMin: number, baseMax: number, skus: string[]) {
  const adj = state.adjustments;
  let dMin = 0;
  let dMax = 0;
  for (const sku of skus) {
    const cur = styleContribution(sku, adj[sku]);
    const def = defaultContribution(sku);
    dMin += cur.min - def.min;
    dMax += cur.max - def.max;
  }
  return { min: baseMin + dMin, max: baseMax + dMax };
}

export function adjustedEuroK(baseMinK: number, baseMaxK: number, skus: string[]) {
  const adj = state.adjustments;
  let dMin = 0;
  let dMax = 0;
  for (const sku of skus) {
    const cur = upsideK(styleContribution(sku, adj[sku]));
    const def = upsideK(defaultContribution(sku));
    dMin += cur.min - def.min;
    dMax += cur.max - def.max;
  }
  return { min: baseMinK + dMin, max: baseMaxK + dMax };
}

export function includedStylesDelta(skus: string[]) {
  const adj = state.adjustments;
  let delta = 0;
  for (const sku of skus) {
    const a = adj[sku];
    if (a && !a.keepInScenario) delta -= 1;
  }
  return delta;
}

// --- Ribbed Tanks specific risk text ---
// Reflects style adjustments (which regions still included) and timing decisions
// for the per-region allocation timing page. Used by the Scenario Confirmation
// table and the Scenario Summary drawer.
const RT_SKU = "RT-001-WHT";

function regionIncluded(region: string): boolean {
  const adj = state.adjustments[RT_SKU] ?? defaultAdjustment(RT_SKU);
  if (!adj.keepInScenario) return false;
  // Region toggle may be absent — fall back to default.
  if (region in adj.regionInclude) return adj.regionInclude[region];
  const def = defaultAdjustment(RT_SKU);
  return def.regionInclude[region] ?? false;
}

function joinAnd(parts: string[]) {
  if (parts.length === 0) return "";
  if (parts.length === 1) return parts[0];
  if (parts.length === 2) return `${parts[0]} and ${parts[1]}`;
  return `${parts.slice(0, -1).join(", ")}, and ${parts[parts.length - 1]}`;
}

export function ribbedTanksRiskText(): string {
  const t = state.timing;
  // Earlier-timing regions: reduce early stockout when applied AND still included.
  const earlyRegions = (["Seville", "Valencia"] as const).filter(
    (r) => t[r] === "applied" && regionIncluded(r),
  );
  // Later-timing regions: reduce markdown risk when applied AND still included.
  const laterRegions = (["Bilbao"] as const).filter(
    (r) => t[r] === "applied" && regionIncluded(r),
  );
  const parts: string[] = [];
  if (earlyRegions.length) parts.push(`Early stockout in ${joinAnd([...earlyRegions])}`);
  if (laterRegions.length) parts.push(`Markdown risk in ${joinAnd([...laterRegions])}`);
  if (parts.length === 0) return "Baseline timing kept";
  return parts.join("; ");
}