export type SignalTone = "blue" | "red" | "green" | "purple" | "amber" | "teal" | "rose";

export const signalTone: Record<string, SignalTone> = {
  "Search trend": "blue",
  "Stockout": "red",
  "PLC growth": "green",
  "Early PLC": "green",
  "Regional demand": "purple",
  "Sell-through": "amber",
  "Weather-sensitive": "teal",
  "Ribbed": "purple",
  "Ribbed trend": "purple",
  "Warm weather": "amber",
  "Similarity match": "teal",
  "Similar SS24 items": "blue",
  "Search uplift": "blue",
  "Stockout risk": "red",
  "Early velocity": "green",
  "Regional concentration": "purple",
  "External driver": "teal",
  "Inventory risk": "red",
  "Early sell-through": "blue",
  "Demand signal": "blue",
  "Trend signal": "blue",
};

export interface ClusterRow {
  rank: number;
  slug: string;
  cluster: string;
  category: string;
  hiddenDemand: string;
  recommendedBuy: string;
  buyIncrease: string;
  opportunity: string;
  drivers: string[];
  needsReview: string;
}

export const clusters: ClusterRow[] = [
  { rank: 1, slug: "ribbed-tanks", cluster: "Ribbed Tanks", category: "Tops", hiddenDemand: "1.7K", recommendedBuy: "7.0K – 7.4K", buyIncrease: "+1.2K – +1.6K", opportunity: "€580K – €640K", drivers: ["Search trend", "Stockout", "PLC growth"], needsReview: "3 styles" },
  { rank: 2, slug: "linen-shirts", cluster: "Linen Shirts", category: "Shirts", hiddenDemand: "1.1K", recommendedBuy: "4.8K – 5.1K", buyIncrease: "+0.8K – +1.0K", opportunity: "€310K – €390K", drivers: ["Sell-through", "Search trend"], needsReview: "2 styles" },
  { rank: 3, slug: "lightweight-dresses", cluster: "Lightweight Dresses", category: "Dresses", hiddenDemand: "0.9K", recommendedBuy: "3.6K – 3.9K", buyIncrease: "+0.6K – +0.9K", opportunity: "€240K – €310K", drivers: ["Weather-sensitive", "Regional demand"], needsReview: "2 styles" },
  { rank: 4, slug: "crochet-tops", cluster: "Crochet Tops", category: "Tops", hiddenDemand: "0.6K", recommendedBuy: "2.4K – 2.7K", buyIncrease: "+0.4K – +0.6K", opportunity: "€150K – €210K", drivers: ["Search trend", "Early PLC"], needsReview: "1 style" },
  { rank: 5, slug: "wide-leg-pants", cluster: "Wide Leg Pants", category: "Bottoms", hiddenDemand: "0.4K", recommendedBuy: "2.1K – 2.3K", buyIncrease: "+0.3K – +0.5K", opportunity: "€110K – €150K", drivers: ["Stockout", "Sell-through"], needsReview: "1 style" },
  { rank: 6, slug: "ribbed-bodysuits", cluster: "Ribbed Bodysuits", category: "Tops", hiddenDemand: "0.3K", recommendedBuy: "1.7K – 1.9K", buyIncrease: "+0.2K – +0.3K", opportunity: "€80K – €120K", drivers: ["Similarity match", "Search trend"], needsReview: "1 style" },
  { rank: 7, slug: "utility-jackets", cluster: "Utility Jackets", category: "Outerwear", hiddenDemand: "0.2K", recommendedBuy: "1.2K – 1.4K", buyIncrease: "+0.1K – +0.2K", opportunity: "€60K – €90K", drivers: ["Weather-sensitive", "Stockout"], needsReview: "1 style" },
  { rank: 8, slug: "pleated-skirts", cluster: "Pleated Skirts", category: "Bottoms", hiddenDemand: "0.1K", recommendedBuy: "0.9K – 1.0K", buyIncrease: "+0.1K – +0.2K", opportunity: "€40K – €70K", drivers: ["Regional demand", "PLC growth"], needsReview: "1 style" },
];

export interface StyleRow {
  idx: number;
  sku: string;
  style: string;
  color: string;
  swatch: string; // hex
  hiddenDemand: number;
  recommendedBuy: string;
  buyIncrease: string;
  opportunity: string;
  drivers: string[];
}

export const ribbedTanksStyles: StyleRow[] = [
  { idx: 1, sku: "RT-001-WHT", style: "Rib Tank Top", color: "White", swatch: "#f5f5f0", hiddenDemand: 220, recommendedBuy: "360 – 410", buyIncrease: "+140 – +190", opportunity: "€80K – €110K", drivers: ["Search trend", "Stockout", "PLC growth"] },
  { idx: 2, sku: "RT-002-BEI", style: "Square Neck Rib", color: "Beige", swatch: "#e8d9c0", hiddenDemand: 180, recommendedBuy: "260 – 310", buyIncrease: "+80 – +130", opportunity: "€60K – €90K", drivers: ["Sell-through", "Search trend"] },
  { idx: 3, sku: "RT-003-BLK", style: "Rib Racer Tank", color: "Black", swatch: "#111111", hiddenDemand: 160, recommendedBuy: "240 – 280", buyIncrease: "+80 – +120", opportunity: "€50K – €80K", drivers: ["PLC growth", "Regional demand"] },
  { idx: 4, sku: "RT-004-NVY", style: "High Neck Rib", color: "Navy", swatch: "#1e3a5f", hiddenDemand: 120, recommendedBuy: "180 – 220", buyIncrease: "+60 – +100", opportunity: "€40K – €60K", drivers: ["Search trend", "Early PLC"] },
  { idx: 5, sku: "RT-005-OLV", style: "Rib Halter Tank", color: "Olive", swatch: "#6b7a43", hiddenDemand: 100, recommendedBuy: "140 – 180", buyIncrease: "+40 – +80", opportunity: "€30K – €50K", drivers: ["Weather-sensitive", "Sell-through"] },
  { idx: 6, sku: "RT-006-STR", style: "Striped Rib Tank", color: "Stripe", swatch: "#d9d4c5", hiddenDemand: 80, recommendedBuy: "120 – 150", buyIncrease: "+30 – +70", opportunity: "€25K – €40K", drivers: ["Similarity match", "Search trend"] },
];