import { useEffect, useState } from "react";
import { X } from "lucide-react";

export function SaveDialog({
  open,
  title,
  fieldLabel,
  helper,
  defaultValue,
  saveLabel,
  onCancel,
  onSave,
}: {
  open: boolean;
  title: string;
  fieldLabel: string;
  helper: string;
  defaultValue: string;
  saveLabel: string;
  onCancel: () => void;
  onSave: (name: string) => void;
}) {
  const [name, setName] = useState(defaultValue);

  useEffect(() => {
    if (open) setName(defaultValue);
  }, [open, defaultValue]);

  if (!open) return null;
  return (
    <>
      <div className="fixed inset-0 z-[60] bg-black/40 animate-in fade-in" onClick={onCancel} />
      <div className="fixed left-1/2 top-1/2 z-[70] w-[440px] max-w-[95vw] -translate-x-1/2 -translate-y-1/2 rounded-xl border border-border bg-card p-6 shadow-2xl animate-in fade-in zoom-in-95">
        <div className="flex items-start justify-between">
          <h3 className="text-lg font-semibold tracking-tight text-primary">{title}</h3>
          <button onClick={onCancel} className="rounded-md p-1 text-muted-foreground hover:bg-secondary">
            <X className="h-4 w-4" />
          </button>
        </div>

        <div className="mt-4">
          <label className="block text-xs font-medium text-muted-foreground">{fieldLabel}</label>
          <input
            type="text"
            autoFocus
            value={name}
            onChange={(e) => setName(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && name.trim()) onSave(name.trim());
              if (e.key === "Escape") onCancel();
            }}
            className="mt-1.5 w-full rounded-md border border-border bg-background px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-accent/30"
          />
          <p className="mt-2 text-xs text-muted-foreground">{helper}</p>
        </div>

        <div className="mt-5 flex items-center justify-end gap-2">
          <button
            onClick={onCancel}
            className="rounded-md border border-border bg-card px-4 py-2 text-sm font-medium hover:bg-secondary"
          >
            Cancel
          </button>
          <button
            onClick={() => name.trim() && onSave(name.trim())}
            disabled={!name.trim()}
            className="rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90 disabled:opacity-50"
          >
            {saveLabel}
          </button>
        </div>
      </div>
    </>
  );
}