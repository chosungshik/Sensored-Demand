import { useState } from "react";
import { ClipboardList, ChevronDown, Info, TrendingUp, Star, RefreshCw, Download, ChevronLeft, ChevronRight, X, Search, AlertTriangle, MapPin, Save, Users, Check } from "lucide-react";
import { GlobalFilters, ClusterContextChip } from "@/components/GlobalFilters";
import { ribbedTanksStyles, type StyleRow, type ClusterRow } from "@/lib/cockpit-data";
import ribTankWhite from "@/assets/rib-tank-white.jpg";
import { Switch } from "@/components/ui/switch";
import {
  STYLE_REGION_BUY,
  adjustedUnits,
  defaultAdjustment,
  scenarioStore,
  styleContribution,
  fmtChangeRange,
  fmtBuyRange,
  fmtUpsideEuroK,
  useScenarioState,
} from "@/lib/scenario-store";

function DecisionCard({
  icon, iconBg, title, children, subtitle, thumb,
}: { icon: React.ReactNode; iconBg: string; title: string; children: React.ReactNode; subtitle: string; thumb?: React.ReactNode; }) {
  return (
    <div className="flex h-full items-start gap-4 rounded-xl border border-border bg-card p-5 shadow-[var(--shadow-card)]">
      <div className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-full ${iconBg}`}>{icon}</div>
      <div className="min-w-0 flex-1">
        <div className="flex items-center gap-1.5 text-sm text-muted-foreground">
          {title}
          <Info className="h-3.5 w-3.5" />
        </div>
        <div className="mt-1.5 text-xl font-semibold tracking-tight text-primary">{children}</div>
        <div className="mt-1 text-xs text-muted-foreground">{subtitle}</div>
      </div>
      {thumb}
    </div>
  );
}

type DecisionType = "Included in scenario" | "Not included in scenario";
function DecisionPill({ decision }: { decision: DecisionType }) {
  const cls =
    decision === "Included in scenario"
      ? "bg-[color:var(--signal-green-bg)] text-[color:var(--signal-green)]"
      : "bg-secondary text-muted-foreground";
  return <span className={`inline-flex whitespace-nowrap rounded-md px-2.5 py-1 text-xs font-medium ${cls}`}>{decision}</span>;
}

type ConfidenceLevel = "High" | "Medium" | "Low";
function ConfidencePill({ level }: { level: ConfidenceLevel }) {
  const cls =
    level === "High"
      ? "bg-[color:var(--signal-green-bg)] text-[color:var(--signal-green)]"
      : level === "Medium"
      ? "bg-[color:var(--signal-amber-bg)] text-[color:var(--signal-amber)]"
      : "bg-[color:var(--signal-rose-bg)] text-[color:var(--signal-rose)]";
  return <span className={`inline-flex rounded-md px-2.5 py-1 text-xs font-medium ${cls}`}>{level}</span>;
}

function ProductThumb({ color, swatch }: { color: string; swatch: string }) {
  const isStripe = color === "Stripe";
  return (
    <div className="flex h-12 w-12 items-center justify-center rounded-md border border-border bg-secondary/40">
      <svg viewBox="0 0 32 36" className="h-9 w-9" aria-hidden>
        <defs>
          {isStripe && (
            <pattern id="stripe" patternUnits="userSpaceOnUse" width="4" height="4">
              <rect width="4" height="4" fill="#f0ebe0" />
              <rect width="4" height="2" fill="#8a7f6a" />
            </pattern>
          )}
        </defs>
        <path
          d="M8 4 L4 10 L8 12 L8 32 Q8 34 10 34 L22 34 Q24 34 24 32 L24 12 L28 10 L24 4 L20 4 Q20 8 16 8 Q12 8 12 4 Z"
          fill={isStripe ? "url(#stripe)" : swatch}
          stroke="#0a0a0a"
          strokeOpacity="0.15"
          strokeWidth="0.5"
        />
      </svg>
    </div>
  );
}

function StyleThumb({ row }: { row: StyleRow }) {
  if (row.sku === "RT-001-WHT") {
    return (
      <div className="flex h-12 w-12 items-center justify-center overflow-hidden rounded-md border border-border bg-secondary/40">
        <img src={ribTankWhite} alt="Rib Tank Top White" className="h-full w-full object-cover" />
      </div>
    );
  }
  return <ProductThumb color={row.color} swatch={row.swatch} />;
}

function ColorChip({ color, swatch }: { color: string; swatch: string }) {
  return (
    <div className="flex items-center gap-2">
      <span className="h-5 w-5 rounded border border-border" style={{ background: swatch }} />
      <span className="text-sm">{color}</span>
    </div>
  );
}

function StyleReviewDrawer({ row, onClose }: { row: StyleRow | null; onClose: () => void }) {
  if (!row) return null;
  return <StyleReviewDrawerContent row={row} onClose={onClose} />;
}

function DemandPill({ level }: { level: "High" | "Medium" | "Low" }) {
  const cls =
    level === "High"
      ? "bg-[color:var(--signal-green-bg)] text-[color:var(--signal-green)]"
      : level === "Medium"
      ? "bg-[color:var(--signal-amber-bg)] text-[color:var(--signal-amber)]"
      : "bg-[color:var(--signal-rose-bg)] text-[color:var(--signal-rose)]";
  return <span className={`inline-flex rounded-md px-2 py-0.5 text-xs font-medium ${cls}`}>{level}</span>;
}

type Region = { name: string; signal: "High" | "Medium" | "Low"; min: number; max: number; reason: string; defaultInclude: boolean };

function StyleReviewDrawerContent({ row, onClose }: { row: StyleRow; onClose: () => void }) {
  const sku = row.sku;
  const scenario = useScenarioState();
  const adj = scenario.adjustments[sku] ?? defaultAdjustment(sku);
  const keepInScenario = adj.keepInScenario;
  const regionInclude = adj.regionInclude;

  const setKeepInScenario = (v: boolean) =>
    scenarioStore.setAdjustment(sku, { ...adj, keepInScenario: v });
  const setRegionInclude = (name: string, v: boolean) =>
    scenarioStore.setAdjustment(sku, {
      ...adj,
      regionInclude: { ...adj.regionInclude, [name]: v },
    });

  const signalByRegion: Record<string, "High" | "Medium" | "Low"> = {
    Seville: "High", Valencia: "High", Barcelona: "Medium", Madrid: "Low", Bilbao: "Low",
  };
  const reasonByRegion: Record<string, string> = {
    Seville: "Strong demand and stockout risk",
    Valencia: "Strong demand and stockout risk",
    Barcelona: "Solid demand potential",
    Madrid: "Lower demand signal",
    Bilbao: "Lower demand signal",
  };
  const regions: Region[] = (STYLE_REGION_BUY[sku] ?? []).map((r) => ({
    name: r.name,
    min: r.min,
    max: r.max,
    defaultInclude: r.defaultInclude,
    signal: signalByRegion[r.name] ?? "Low",
    reason: reasonByRegion[r.name] ?? "",
  }));

  const contrib = styleContribution(sku, adj);
  const currentPlan = 220;

  const evidence = [
    { icon: <Users className="h-4 w-4 text-[color:var(--signal-blue)]" />, tone: "bg-[color:var(--signal-blue-bg)]", title: "Similar item evidence", body: "4 similar SS24 items sold faster than PLC" },
    { icon: <TrendingUp className="h-4 w-4 text-[color:var(--signal-green)]" />, tone: "bg-[color:var(--signal-green-bg)]", title: "Early velocity", body: "Similar items sold 74% of season volume by Week 4" },
    { icon: <Search className="h-4 w-4 text-[color:var(--signal-blue)]" />, tone: "bg-[color:var(--signal-blue-bg)]", title: "Demand signal", body: "Search trend +26% over last 4 weeks" },
    { icon: <AlertTriangle className="h-4 w-4 text-[color:var(--signal-rose)]" />, tone: "bg-[color:var(--signal-rose-bg)]", title: "Inventory risk", body: "Stockout risk concentrated in Seville and Valencia" },
    { icon: <MapPin className="h-4 w-4 text-[color:var(--signal-purple)]" />, tone: "bg-[color:var(--signal-purple-bg)]", title: "Regional concentration", body: "Strongest demand signal in Seville and Valencia" },
  ];

  return (
    <>
      <div className="fixed inset-0 z-40 bg-black/30 animate-in fade-in" onClick={onClose} />
      <aside className="fixed right-0 top-0 z-50 flex h-full w-[640px] max-w-[95vw] flex-col border-l border-border bg-card shadow-2xl animate-in slide-in-from-right">
        <div className="flex items-start justify-between px-6 py-3 border-b border-border">
          <h2 className="text-xl font-semibold tracking-tight text-primary">Style Review</h2>
          <button onClick={onClose} className="rounded-md p-1.5 text-muted-foreground hover:bg-secondary">
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto px-6 py-4">
          {/* Recommendation + decision */}
          <div className="rounded-lg border border-border p-4">
            <div className="flex items-center gap-1.5 text-sm font-semibold">
              Recommendation <Info className="h-3.5 w-3.5 text-muted-foreground" />
            </div>
            <p className="mt-2 text-sm text-foreground">
              {keepInScenario && (contrib.min > 0 || contrib.max > 0) ? (
                <>
                  Include this style in selected regions and increase buy by{" "}
                  <span className="font-semibold text-[color:var(--signal-green)]">
                    {fmtChangeRange(contrib)}
                  </span>
                </>
              ) : !keepInScenario ? (
                <>Excluded from scenario — no buy change applied.</>
              ) : (
                <>Include this style with no regional buy increase.</>
              )}
            </p>
            <div className="mt-3 flex items-center justify-between rounded-md border border-border bg-secondary/30 px-3 py-2">
              <div className="flex items-center gap-3">
                <Switch checked={keepInScenario} onCheckedChange={setKeepInScenario} />
                <span className="text-sm font-medium">Keep style in scenario</span>
              </div>
              <span
                className={`inline-flex rounded-md px-2 py-0.5 text-xs font-medium ${
                  keepInScenario
                    ? "bg-[color:var(--signal-green-bg)] text-[color:var(--signal-green)]"
                    : "bg-[color:var(--signal-rose-bg)] text-[color:var(--signal-rose)]"
                }`}
              >
                {keepInScenario ? "Included" : "Excluded"}
              </span>
            </div>
          </div>

          {/* Product summary */}
          <div className="mt-4 flex gap-4">
            <div className="flex h-[120px] w-[100px] shrink-0 items-center justify-center overflow-hidden rounded-md border border-border bg-secondary/40">
              <img src={ribTankWhite} alt="Rib Tank Top in White" className="h-full w-full object-cover" />
            </div>
            <dl className="grid flex-1 grid-cols-[auto,1fr] gap-x-5 gap-y-1.5 text-sm self-center">
              <dt className="text-muted-foreground">SKU / Product Code</dt><dd className="font-medium">{row.sku}</dd>
              <dt className="text-muted-foreground">Style</dt><dd className="font-medium">{row.style}</dd>
              <dt className="text-muted-foreground">Color</dt>
              <dd><ColorChip color={row.color} swatch={row.swatch} /></dd>
              <dt className="text-muted-foreground">Product Cluster</dt><dd className="font-medium">Ribbed Tanks</dd>
              <dt className="text-muted-foreground">Category</dt><dd className="font-medium">Tops</dd>
            </dl>
          </div>

          {/* Compact change metrics */}
          <div className="mt-4 grid grid-cols-4 gap-2 rounded-lg border border-border px-4 py-3">
            {[
              { k: "Current plan", v: `${currentPlan}`, u: "units" },
              { k: "Recommended buy", v: fmtBuyRange(currentPlan, contrib), u: "units" },
              {
                k: "Change",
                v: contrib.min === 0 && contrib.max === 0
                  ? "0"
                  : `+${contrib.min} – +${contrib.max}`,
                u: "units",
                tone:
                  contrib.min === 0 && contrib.max === 0
                    ? "text-muted-foreground"
                    : "text-[color:var(--signal-green)]",
              },
              { k: "Expected upside", v: fmtUpsideEuroK(contrib), u: "EUR" },
            ].map((m) => (
              <div key={m.k}>
                <div className="text-xs text-muted-foreground">{m.k}</div>
                <div className={`mt-0.5 text-sm font-semibold ${m.tone ?? ""}`}>{m.v}</div>
                <div className="text-xs text-muted-foreground">{m.u}</div>
              </div>
            ))}
          </div>

          {/* Why this style is recommended */}
          <div className="mt-4">
            <div className="mb-2 flex items-center gap-1.5 text-sm font-semibold">
              Why this style is recommended <Info className="h-3.5 w-3.5 text-muted-foreground" />
            </div>
            <div className="grid grid-cols-2 gap-2">
              {evidence.map((e) => (
                <div key={e.title} className="rounded-lg border border-border px-3 py-2">
                  <div className="flex items-center gap-2">
                    <span className={`flex h-6 w-6 items-center justify-center rounded-md ${e.tone}`}>{e.icon}</span>
                    <span className="text-xs font-semibold text-foreground">{e.title}</span>
                  </div>
                  <div className="mt-1 text-xs text-muted-foreground">{e.body}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Where to include */}
          <div className="mt-4">
            <div className="flex items-center gap-1.5 text-sm font-semibold">
              Where to include <Info className="h-3.5 w-3.5 text-muted-foreground" />
            </div>
            <div className="mt-2 overflow-hidden rounded-lg border border-border">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-border bg-secondary/30 text-center text-xs font-medium text-muted-foreground">
                    <th className="px-3 py-1.5 text-center">Region</th>
                    <th className="px-3 py-1.5 text-center">Demand signal</th>
                    <th className="px-3 py-1.5 text-center">Recommended Change</th>
                    <th className="px-3 py-1.5 text-center">Why it matters</th>
                    <th className="px-3 py-1.5 text-center">Include</th>
                  </tr>
                </thead>
                <tbody>
                  {regions.map((r) => (
                    <tr key={r.name} className="border-b border-border/60 last:border-0">
                      <td className="px-3 py-2 font-medium">{r.name}</td>
                      <td className="px-3 py-2"><DemandPill level={r.signal} /></td>
                      <td className="px-3 py-2 whitespace-nowrap">
                        {r.min === 0 && r.max === 0 ? `0 – ${r.max} units` : `+${r.min} – +${r.max} units`}
                      </td>
                      <td className="px-3 py-2 text-muted-foreground">{r.reason}</td>
                      <td className="px-3 py-2">
                        <div className="flex justify-center">
                          <Switch
                            checked={keepInScenario && regionInclude[r.name]}
                            onCheckedChange={(v) => setRegionInclude(r.name, v)}
                            disabled={!keepInScenario}
                          />
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div className="flex items-center justify-between gap-3 border-t border-border px-6 py-3 bg-card">
          <button onClick={onClose} className="rounded-md border border-border bg-card px-5 py-2 text-sm font-medium hover:bg-secondary">
            Cancel
          </button>
          <button onClick={onClose} className="inline-flex items-center gap-2 rounded-md bg-primary px-5 py-2 text-sm font-medium text-primary-foreground hover:opacity-90">
            <Save className="h-4 w-4" />
            Save style decision
          </button>
        </div>
      </aside>
    </>
  );
}

export function DemandOpportunityPage({ cluster }: { cluster: ClusterRow }) {
  const [reviewRow, setReviewRow] = useState<StyleRow | null>(null);
  const scenario = useScenarioState();

  // Buy increase KPI reflects scenario adjustments for Ribbed Tanks (the
  // cluster with per-style toggles wired). Other clusters stay static.
  const isRibbedTanks = cluster.cluster === "Ribbed Tanks";
  const baseMin = isRibbedTanks ? 1200 : 0;
  const baseMax = isRibbedTanks ? 1600 : 0;
  const buy = isRibbedTanks
    ? adjustedUnits(baseMin, baseMax, ["RT-001-WHT"])
    : { min: baseMin, max: baseMax };
  const fmtK = (n: number) => `${(n / 1000).toFixed(1)}K`;
  const buyIncreaseLabel = isRibbedTanks
    ? `+${fmtK(buy.min)} – +${fmtK(buy.max)} units`
    : "+1.2K – +1.6K units";

  type DisplayRow = {
    base: StyleRow;
    change: string;
    evidence: string;
    where: string;
    confidence: ConfidenceLevel;
  };

  const rows: DisplayRow[] = [
    { base: ribbedTanksStyles[0], change: "+260 – +390 units", evidence: "4 similar SS24 styles sold faster than PLC", where: "Seville, Valencia, Barcelona", confidence: "High" },
    { base: ribbedTanksStyles[1], change: "+80 – +130 units", evidence: "Fast early sell-through in SS24", where: "Seville", confidence: "High" },
    { base: ribbedTanksStyles[2], change: "+80 – +120 units", evidence: "Positive PLC signal, weaker regional signal", where: "Valencia-led", confidence: "Medium" },
    { base: ribbedTanksStyles[3], change: "+60 – +100 units", evidence: "Moderate similarity evidence", where: "Spain selected regions", confidence: "Medium" },
    { base: ribbedTanksStyles[5], change: "No increase", evidence: "Weak similarity and demand signal", where: "Limited focus", confidence: "Low" },
  ];

  const decisionFor = (sku: string): DecisionType => {
    const adj = scenario.adjustments[sku];
    if (adj && !adj.keepInScenario) return "Not included in scenario";
    return "Included in scenario";
  };

  return (
    <>
      <GlobalFilters />

      <div className="mb-5 flex items-start justify-between">
        <div>
          <ClusterContextChip cluster={cluster.cluster} />
          <h1 className="text-2xl font-semibold tracking-tight text-primary">Style Selection</h1>
        </div>
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <span>Last updated: May 20, 2025 09:30 AM</span>
          <RefreshCw className="h-3.5 w-3.5" />
        </div>
      </div>

      <div className="grid grid-cols-1 gap-5 md:grid-cols-3">
        <DecisionCard
          icon={<ClipboardList className="h-6 w-6 text-accent" />}
          iconBg="bg-[color:var(--signal-blue-bg)]"
          title="Recommended style decisions"
          subtitle="Included / not included in scenario"
        >
          <span>18 style decisions</span>
        </DecisionCard>
        <DecisionCard
          icon={<TrendingUp className="h-6 w-6 text-[color:var(--signal-green)]" />}
          iconBg="bg-[color:var(--signal-green-bg)]"
          title="Recommended buy increase"
          subtitle="vs. current plan"
        >
          <span className="text-[color:var(--signal-green)]">{buyIncreaseLabel}</span>
        </DecisionCard>
        <DecisionCard
          icon={<Star className="h-6 w-6 text-[color:var(--signal-purple)]" />}
          iconBg="bg-[color:var(--signal-purple-bg)]"
          title="Highest priority style"
          subtitle={""}
          thumb={
            <div className="ml-2 hidden h-16 w-14 shrink-0 overflow-hidden rounded-md border border-border bg-secondary/40 lg:block">
              <img src={ribTankWhite} alt="Rib Tank Top White" className="h-full w-full object-cover" />
            </div>
          }
        >
          <div className="leading-snug">Rib Tank Top <span className="text-muted-foreground">White</span></div>
          <div className="mt-1 text-xs font-medium text-[color:var(--signal-green)]">+260 – +390 units recommended</div>
        </DecisionCard>
      </div>

      <section className="mt-6 rounded-xl border border-border bg-card shadow-[var(--shadow-card)]">
        <div className="flex items-start justify-between border-b border-border px-6 py-5">
          <div className="flex items-center gap-3">
            <h2 className="text-base font-semibold">Style Decision List</h2>
            <span className="rounded-md bg-secondary px-2 py-0.5 text-xs font-medium text-muted-foreground">18 styles</span>
          </div>
          <div className="flex items-center gap-2">
            <button className="flex items-center gap-2 rounded-md border border-border bg-card px-3 py-1.5 text-sm font-medium hover:bg-secondary">
              Columns
              <ChevronDown className="h-4 w-4 text-muted-foreground" />
            </button>
            <button className="flex items-center gap-2 rounded-md border border-border bg-card px-3 py-1.5 text-sm font-medium hover:bg-secondary">
              <Download className="h-4 w-4" />
              Export
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border text-center text-xs font-medium text-muted-foreground">
                <th className="px-6 py-3 text-center">Decision</th>
                <th className="px-3 py-3 text-center">Product</th>
                <th className="px-3 py-3 text-center">SKU / Product Code</th>
                <th className="px-3 py-3 text-center">Style</th>
                <th className="px-3 py-3 text-center">Recommended Change<div className="text-[10px] font-normal text-muted-foreground/70">vs. current plan</div></th>
                <th className="px-3 py-3 text-center">Similar SS24 Evidence</th>
                <th className="px-3 py-3 text-center">Where to include</th>
                <th className="px-3 py-3 text-center">Confidence</th>
                <th className="px-3 py-3 text-center">Action</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => {
                const row = r.base;
                const isNoChange = r.change === "No increase";
                return (
                  <tr
                    key={row.sku}
                    onClick={() => setReviewRow(row)}
                    className="group h-[80px] cursor-pointer border-b border-border/60 last:border-0 hover:bg-secondary/40"
                  >
                    <td className="px-6 py-4 align-middle text-center"><DecisionPill decision={decisionFor(row.sku)} /></td>
                    <td className="px-3 py-4 align-middle text-center"><StyleThumb row={row} /></td>
                    <td className="px-3 py-4 align-middle text-center font-medium whitespace-nowrap">{row.sku}</td>
                    <td className="px-3 py-4 align-middle text-center whitespace-nowrap">{row.style}</td>
                    <td className={`px-3 py-4 align-middle text-center font-medium whitespace-nowrap ${isNoChange ? "text-muted-foreground" : "text-[color:var(--signal-green)]"}`}>{r.change}</td>
                    <td className="px-3 py-4 align-middle text-sm text-foreground">{r.evidence}</td>
                    <td className="px-3 py-4 align-middle text-center text-sm">{r.where}</td>
                    <td className="px-3 py-4 align-middle"><ConfidencePill level={r.confidence} /></td>
                    <td className="px-3 py-4 align-middle text-center">
                      <button
                        onClick={(e) => { e.stopPropagation(); setReviewRow(row); }}
                        className="inline-flex items-center gap-1 whitespace-nowrap rounded-md border border-accent/40 bg-card px-3 py-1.5 text-xs font-medium text-accent hover:bg-[color:var(--signal-blue-bg)]"
                      >
                        Review
                        <ChevronRight className="h-3.5 w-3.5" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        <div className="flex items-center justify-between border-t border-border px-6 py-3 text-xs text-muted-foreground">
          <span>Showing 1 to {rows.length} of 18 styles</span>
          <div className="flex items-center gap-2">
            <button className="flex items-center gap-1 rounded-md border border-border bg-card px-2 py-1 hover:bg-secondary">
              25 per page <ChevronDown className="h-3 w-3" />
            </button>
            <button className="rounded-md border border-border p-1 hover:bg-secondary"><ChevronLeft className="h-3.5 w-3.5" /></button>
            <span className="rounded-md border border-accent/40 bg-card px-2 py-0.5 text-accent">1</span>
            <button className="rounded-md border border-border p-1 hover:bg-secondary"><ChevronRight className="h-3.5 w-3.5" /></button>
          </div>
        </div>
      </section>

      <StyleReviewDrawer row={reviewRow} onClose={() => setReviewRow(null)} />
    </>
  );
}