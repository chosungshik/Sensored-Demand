import { ReactNode, useState } from "react";
import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { BarChart3, Calendar, Activity, LayoutGrid, TrendingUp, Clock, FileText, Bell, HelpCircle, ChevronRight, RefreshCw, X, ShoppingBag, Tag, Euro, Info, Save, Download, Check, Shield, ClipboardList, Database } from "lucide-react";
import {
  adjustedEuroK,
  adjustedUnits,
  includedStylesDelta,
  useScenarioState,
} from "@/lib/scenario-store";
import { plansStore, usePlansState } from "@/lib/plans-store";
import { PlanSelector } from "@/components/PlanSelector";
import { SaveDialog } from "@/components/SaveDialog";
import { DataHealthPopover } from "@/components/DataHealthPopover";
import { toast } from "sonner";

type TimingTone = "earlier" | "later" | "none";
function TimingBadge({ label, tone }: { label: string; tone: TimingTone }) {
  const cls =
    tone === "earlier"
      ? "bg-[color:var(--signal-green-bg)] text-[color:var(--signal-green)]"
      : tone === "later"
      ? "bg-[color:var(--signal-amber-bg)] text-[color:var(--signal-amber)]"
      : "bg-secondary text-muted-foreground";
  return <span className={`inline-flex rounded-md px-2 py-0.5 text-[11px] font-medium ${cls}`}>{label}</span>;
}

const TRACKED_SKUS = ["RT-001-WHT"];
const RIBBED_TANKS_DEFAULT_INCLUDED = 12;

function fmtK(n: number) {
  return `${(n / 1000).toFixed(1)}K`;
}
function fmtEuroK(n: number) {
  // n is in thousands of EUR
  if (n >= 1000) return `€${(n / 1000).toFixed(2)}M`;
  return `€${n}K`;
}

const seasonTabs = [
  { to: "/", label: "Buy Recommendations", icon: LayoutGrid },
  { to: "/demand-opportunity", label: "Style Selection", icon: TrendingUp },
  { to: "/scenario-plan", label: "Scenario Confirmation", icon: FileText },
] as const;

const opsTabs = [
  { to: "/operations-cockpit", label: "Operations Cockpit", icon: LayoutGrid },
  { to: "/recommended-actions", label: "Recommended Actions", icon: ClipboardList },
] as const;

const OPS_PATHS = opsTabs.map((t) => t.to) as readonly string[];
function isOpsPath(path: string) {
  return OPS_PATHS.some((p) => path === p || path.startsWith(p + "/"));
}
function isSetupPath(path: string) {
  return path === "/data-setup" || path.startsWith("/data-setup/");
}

export function AppShell({ children }: { children: ReactNode }) {
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [saveOpen, setSaveOpen] = useState(false);
  const path = useRouterState({ select: (s) => s.location.pathname });
  const navigate = useNavigate();
  const inOps = isOpsPath(path);
  const inSetup = isSetupPath(path);
  const tabs = inSetup ? [] : inOps ? opsTabs : seasonTabs;
  useScenarioState(); // re-render on scenario changes
  const plans = usePlansState();

  // Ribbed Tanks defaults (units): 2.3K - 2.6K total buy, +0.6K - +0.9K delta,
  // €150K - €210K opportunity. Recompute with current adjustments.
  const ribbedBuy = adjustedUnits(2300, 2600, TRACKED_SKUS);
  const ribbedDelta = adjustedUnits(600, 900, TRACKED_SKUS);
  const ribbedOpp = adjustedEuroK(150, 210, TRACKED_SKUS);
  const ribbedStylesDelta = includedStylesDelta(TRACKED_SKUS);

  // Scenario-wide totals
  const totalBuy = adjustedUnits(22000, 22800, TRACKED_SKUS);
  const totalOpp = adjustedEuroK(1390, 1700, TRACKED_SKUS);
  const includedStyles = 57 + ribbedStylesDelta;

  const fmtUnitsK = (min: number, max: number) =>
    min === 0 && max === 0
      ? "No change"
      : `${min >= 0 ? "+" : ""}${fmtK(min)} – ${max >= 0 ? "+" : ""}${fmtK(max)} units`;

  type SC = { name: string; styles: string; selMin: number; selMax: number; upMinK: number; upMaxK: number; reason: string; risk: string };
  const summaryClusters: SC[] = [
    {
      name: "Ribbed Tanks",
      styles: `${RIBBED_TANKS_DEFAULT_INCLUDED + ribbedStylesDelta} of 15`,
      selMin: ribbedDelta.min, selMax: ribbedDelta.max,
      upMinK: ribbedOpp.min, upMaxK: ribbedOpp.max,
      reason: "Similar SS24 item performance + stockout risk", risk: "Early stockout",
    },
    { name: "Linen Shirts", styles: "14 of 18", selMin: 800, selMax: 1000, upMinK: 310, upMaxK: 390, reason: "Early sell-through + search uplift", risk: "Low cover" },
    { name: "Lightweight Dresses", styles: "16 of 20", selMin: 600, selMax: 800, upMinK: 240, upMaxK: 310, reason: "Weather-sensitive demand", risk: "Weather-driven missed demand" },
    { name: "Crochet Tops", styles: "15 of 19", selMin: 500, selMax: 700, upMinK: 150, upMaxK: 210, reason: "Early velocity", risk: "Slow reaction risk" },
    { name: "Wide Leg Pants", styles: "10 of 14", selMin: 300, selMax: 500, upMinK: 110, upMaxK: 150, reason: "Regional concentration", risk: "Missed regional demand" },
  ];
  const scaleUpside = (r: SC) => {
    const recMin = r.selMin; const recMax = r.selMax;
    const rMin = recMin === 0 ? 0 : r.selMin / recMin;
    const rMax = recMax === 0 ? 0 : r.selMax / recMax;
    return { min: Math.round(r.upMinK * rMin), max: Math.round(r.upMaxK * rMax) };
  };

  const totalDelta = adjustedUnits(3800, 4600, TRACKED_SKUS);
  const topMetrics = [
    { icon: ShoppingBag, label: "Included clusters", value: "4 of 8", tone: "text-accent", bg: "bg-[color:var(--signal-blue-bg)]" },
    { icon: Tag, label: "Included styles", value: `${includedStyles} of 72`, tone: "text-accent", bg: "bg-[color:var(--signal-blue-bg)]" },
    { icon: TrendingUp, label: "Recommended buy increase", value: `+${fmtK(totalDelta.min)} – +${fmtK(totalDelta.max)} units`, tone: "text-[color:var(--signal-green)]", bg: "bg-[color:var(--signal-green-bg)]" },
    { icon: Euro, label: "Expected upside", value: `${fmtEuroK(totalOpp.min)} – ${fmtEuroK(totalOpp.max)}`, tone: "text-[color:var(--signal-purple)]", bg: "bg-[color:var(--signal-purple-bg)]" },
  ];

  return (
    <div className="min-h-screen bg-background text-foreground pb-20">
      {/* Top header */}
      <header className="border-b border-border bg-card">
        <div className="mx-auto flex h-16 max-w-[1560px] items-center justify-between px-8">
          <div className="flex items-center gap-2.5">
            <div className="flex h-8 w-8 items-center justify-center rounded-md bg-accent/10">
              <BarChart3 className="h-5 w-5 text-accent" />
            </div>
            <span className="text-[17px] font-semibold tracking-tight text-primary">Fashion Demand Intelligence</span>
          </div>

          <div className="flex items-center gap-1 rounded-lg border border-border bg-secondary/40 p-1">
            <button
              onClick={() => navigate({ to: "/data-setup" })}
              className={`flex items-center gap-2 rounded-md px-4 py-2 text-sm font-medium ${
                inSetup
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Database className="h-4 w-4" />
              Data Setup
            </button>
            {!inSetup && (
            <button
              onClick={() => navigate({ to: "/" })}
              className={`flex items-center gap-2 rounded-md px-4 py-2 text-sm font-medium ${
                !inOps && !inSetup
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Calendar className="h-4 w-4" />
              Season Planning
            </button>
            )}
            {!inSetup && (
            <button
              onClick={() => navigate({ to: "/operations-cockpit" })}
              className={`flex items-center gap-2 rounded-md px-4 py-2 text-sm font-medium ${
                inOps
                  ? "bg-primary text-primary-foreground shadow-sm"
                  : "text-muted-foreground hover:text-foreground"
              }`}
            >
              <Activity className="h-4 w-4" />
              In-season Operations
            </button>
            )}
          </div>

          <div className="flex items-center gap-4">
            <DataHealthPopover />
            <button className="rounded-md p-2 text-muted-foreground hover:bg-secondary hover:text-foreground">
              <Bell className="h-5 w-5" />
            </button>
            <button className="rounded-md p-2 text-muted-foreground hover:bg-secondary hover:text-foreground">
              <HelpCircle className="h-5 w-5" />
            </button>
            <div className="flex h-9 w-9 items-center justify-center rounded-full bg-primary text-xs font-semibold text-primary-foreground">JM</div>
          </div>
        </div>

        {/* Tabs */}
        <div className="mx-auto max-w-[1560px] px-8">
          <nav className="flex gap-8">
            {tabs.map((t) => {
              const active = t.to === "/" ? path === "/" : path.startsWith(t.to);
              const Icon = t.icon;
              return (
                <Link
                  key={t.to}
                  to={t.to}
                  className={`relative flex items-center gap-2 border-b-2 py-3 text-sm font-medium transition-colors ${
                    active ? "border-accent text-accent" : "border-transparent text-muted-foreground hover:text-foreground"
                  }`}
                >
                  <Icon className="h-4 w-4" />
                  {t.label}
                </Link>
              );
            })}
          </nav>
        </div>
      </header>

      <main className="mx-auto max-w-[1560px] px-8 py-6">{children}</main>

      {/* Sticky bottom bar */}
      {inSetup ? null : inOps ? (
        <div className="fixed inset-x-0 bottom-0 z-30 border-t border-border bg-card">
          <div className="mx-auto flex max-w-[1560px] items-center justify-between px-8 py-3 text-sm">
            <div className="flex items-center gap-8">
              <div><span className="text-muted-foreground">Baseline: </span><span className="font-medium">Uploaded SS25 in-season plan</span></div>
              <PlanSelector
                label="Action Plan"
                current={plans.actionPlanName}
                items={plans.actionPlans}
                onSelect={(n) => plansStore.selectActionPlan(n)}
                suffix={
                  plans.actionPlanSaved ? (
                    <span className="text-xs text-[color:var(--signal-green)]">· Saved just now</span>
                  ) : null
                }
              />
            </div>
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2 text-muted-foreground"><span>Last updated: May 20, 2025 09:30 AM</span><RefreshCw className="h-3.5 w-3.5" /></div>
            </div>
          </div>
        </div>
      ) : (
      <div className="fixed inset-x-0 bottom-0 z-30 border-t border-border bg-card">
        <div className="mx-auto flex max-w-[1560px] items-center justify-between px-8 py-3 text-sm">
          <div className="flex items-center gap-8">
            <div><span className="text-muted-foreground">Baseline Plan: </span><span className="font-medium">Uploaded SS25 buy & allocation plan</span></div>
            <PlanSelector
              label="Scenario"
              current={plans.scenarioName}
              items={plans.scenarios}
              onSelect={(n) => plansStore.selectScenario(n)}
              suffix={
                plans.scenarioSaved ? (
                  <span className="text-xs text-[color:var(--signal-green)]">· Saved just now</span>
                ) : null
              }
            />
          </div>
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-2 text-muted-foreground"><span>Last updated: May 20, 2025 09:30 AM</span><RefreshCw className="h-3.5 w-3.5" /></div>
            <button
              onClick={() => setDrawerOpen(true)}
              className="flex items-center gap-2 rounded-md border border-border bg-card px-4 py-2 text-sm font-medium hover:bg-secondary"
            >
              <LayoutGrid className="h-4 w-4" />
              View summary
              <ChevronRight className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
      )}

      {/* Drawer */}
      {drawerOpen && !inOps && (
        <>
          <div className="fixed inset-0 z-40 bg-black/30 animate-in fade-in" onClick={() => setDrawerOpen(false)} />
          <aside className="fixed right-0 top-0 z-50 flex h-full w-[780px] max-w-[95vw] flex-col border-l border-border bg-card shadow-2xl animate-in slide-in-from-right">
            <div className="flex items-start justify-between px-7 pt-5 pb-4">
              <div>
                <h2 className="text-xl font-semibold tracking-tight text-primary">Scenario Summary</h2>
              <div className="mt-1.5 text-sm font-medium">{plans.scenarioName}</div>
              {plans.scenarioSaved ? (
                <div className="mt-1.5 flex items-center gap-1.5 text-xs font-medium text-[color:var(--signal-green)]">
                  <span className="h-2 w-2 rounded-full bg-[color:var(--signal-green)]" />
                  Saved just now
                </div>
              ) : (
                <div className="mt-1.5 flex items-center gap-1.5 text-xs font-medium text-[color:var(--signal-amber)]">
                  <span className="h-2 w-2 rounded-full bg-[color:var(--signal-amber)]" />
                  Unsaved changes
                </div>
              )}
              </div>
              <button onClick={() => setDrawerOpen(false)} className="rounded-md p-1.5 text-muted-foreground hover:bg-secondary">
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto px-7 pb-5">
              {/* Decision message */}
              <div className="rounded-lg border border-border bg-[color:var(--signal-blue-bg)]/40 px-4 py-3">
                <div className="flex gap-3">
                  <span className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-[color:var(--signal-blue-bg)]">
                    <ShoppingBag className="h-3.5 w-3.5 text-accent" />
                  </span>
                  <div className="text-sm text-foreground">
                    Current scenario increases the uploaded <span className="font-semibold">SS25 Spain</span> baseline plan by{" "}
                    <span className="font-semibold">+{fmtK(totalDelta.min)} – +{fmtK(totalDelta.max)} units</span>, focused on{" "}
                    <span className="font-semibold">4 priority clusters</span> and <span className="font-semibold">{includedStyles} selected styles</span>.
                    <div className="mt-2 flex items-center gap-1.5 text-xs text-muted-foreground">
                      <Shield className="h-3.5 w-3.5" />
                      Main risk reduced: early stockout in Seville and Valencia.
                    </div>
                  </div>
                </div>
              </div>

              {/* Compact metrics row */}
              <div className="mt-5 grid grid-cols-5 gap-3">
                {topMetrics.map((m) => {
                  const Icon = m.icon;
                  return (
                    <div key={m.label} className="flex items-start gap-2">
                      <span className={`flex h-7 w-7 shrink-0 items-center justify-center rounded-full ${m.bg}`}>
                        <Icon className={`h-3.5 w-3.5 ${m.tone}`} />
                      </span>
                      <div className="min-w-0">
                        <div className="text-[10px] uppercase tracking-wide text-muted-foreground leading-tight">{m.label}</div>
                        <div className={`mt-1 text-[13px] font-semibold leading-tight ${m.tone}`}>{m.value}</div>
                      </div>
                    </div>
                  );
                })}
              </div>

              {/* Impact table */}
              <div className="mt-6">
                <div className="mb-2 text-sm font-semibold">Scenario Impact Summary</div>
                <div className="overflow-hidden rounded-lg border border-border">
                  <table className="w-full text-[12px]">
                    <thead>
                      <tr className="border-b border-border bg-secondary/40 text-left text-[10px] font-medium uppercase tracking-wide text-muted-foreground">
                        <th className="px-2.5 py-2">Product Cluster</th>
                        <th className="px-2.5 py-2">Included Styles</th>
                        <th className="px-2.5 py-2">Change vs. Baseline</th>
                        <th className="px-2.5 py-2">Expected Upside</th>
                        <th className="px-2.5 py-2">Main Reason</th>
                        <th className="px-2.5 py-2">Main Risk Reduced</th>
                      </tr>
                    </thead>
                    <tbody>
                      {summaryClusters.map((c) => (
                        <tr key={c.name} className="border-b border-border/60 last:border-0">
                          <td className="px-2.5 py-2.5 font-medium text-accent">{c.name}</td>
                          <td className="px-2.5 py-2.5">{c.styles}</td>
                          <td className="px-2.5 py-2.5 text-[color:var(--signal-green)]">{fmtUnitsK(c.selMin, c.selMax)}</td>
                          <td className="px-2.5 py-2.5">{(() => { const u = scaleUpside(c); return `${fmtEuroK(u.min)} – ${fmtEuroK(u.max)}`; })()}</td>
                          <td className="px-2.5 py-2.5 text-foreground">{c.reason}</td>
                          <td className="px-2.5 py-2.5">
                            <span className="inline-flex rounded-md bg-secondary px-2 py-0.5 text-[11px] font-medium text-foreground">
                              {c.risk}
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              <div className="mt-5 flex items-start gap-2 rounded-lg border border-border bg-secondary/30 px-4 py-3 text-sm text-muted-foreground">
                <Info className="mt-0.5 h-4 w-4 shrink-0" />
                <span>Review the current scenario before saving or exporting. You can still adjust style decisions or allocation timing before confirmation.</span>
              </div>
            </div>

            <div className="flex items-center gap-3 border-t border-border px-7 py-4">
              <button
                onClick={() => setSaveOpen(true)}
                className="inline-flex flex-1 items-center justify-center gap-2 rounded-md bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground hover:opacity-90"
              >
                {plans.scenarioSaved ? <Check className="h-4 w-4" /> : <Save className="h-4 w-4" />}
                {plans.scenarioSaved ? "Scenario Saved" : "Save Scenario"}
              </button>
              <button
                onClick={() => toast("Scenario export ready")}
                className="inline-flex flex-1 items-center justify-center gap-2 rounded-md border border-border bg-card px-5 py-2.5 text-sm font-medium hover:bg-secondary"
              >
                <Download className="h-4 w-4" />
                Export Scenario
              </button>
            </div>
          </aside>
        </>
      )}

      <SaveDialog
        open={saveOpen}
        title="Save scenario"
        fieldLabel="Scenario name"
        helper="Name this scenario so you can reopen or export it later."
        defaultValue={plans.scenarioName}
        saveLabel="Save Scenario"
        onCancel={() => setSaveOpen(false)}
        onSave={(name) => {
          plansStore.saveScenario(name);
          setSaveOpen(false);
          toast("Scenario saved");
        }}
      />
    </div>
  );
}