import { useEffect, useRef, useState } from "react";
import { ChevronDown, Filter, X } from "lucide-react";

const MARKETS = ["Spain", "Portugal", "France", "Italy", "Germany", "United Kingdom", "Netherlands"];
const REGIONS = ["All", "Seville", "Valencia", "Barcelona", "Madrid", "Bilbao", "Malaga", "Zaragoza"];
const CATEGORIES = ["All", "Tops", "Shirts", "Dresses", "Bottoms", "Outerwear", "Knitwear", "Accessories"];
const SEASONS = ["SS25", "AW25", "SS24", "AW24", "SS26"];

// Season Planning More filters
const SCENARIO_INCLUSION = ["All", "Included in scenario", "Not included in scenario"];
const CONFIDENCE = ["All", "High", "Medium", "Low"];
const SEASON_REASON = [
  "All",
  "Similar SS24 item performance",
  "Early sell-through",
  "Search uplift",
  "Stockout risk",
  "Weather-sensitive demand",
  "Regional concentration",
  "Low confidence signal",
];

// In-season Operations top filters
const ACTION_TYPES = ["All", "DC replenishment", "Store transfer", "Visual merchandising", "Size / color adjustment", "Markdown recovery"];
const ACTION_WINDOWS = ["Next 7 days", "Next 2 weeks", "Next 4 weeks", "This month"];

// In-season Operations More filters
const QUEUE_STATUS = ["All", "Added to queue", "Not added to queue"];
const PRIORITY = ["All", "High", "Medium", "Low"];
const OPS_REASON = [
  "All",
  "Low stock cover",
  "Fast sell-through",
  "Weather shift",
  "Low visibility",
  "Store imbalance",
  "Markdown risk",
  "Size / color gap",
];

function useOutside<T extends HTMLElement>(onClose: () => void) {
  const ref = useRef<T>(null);
  useEffect(() => {
    const fn = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) onClose();
    };
    document.addEventListener("mousedown", fn);
    return () => document.removeEventListener("mousedown", fn);
  }, [onClose]);
  return ref;
}

function Dropdown({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: string;
  options: readonly string[];
  onChange: (v: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const ref = useOutside<HTMLDivElement>(() => setOpen(false));
  return (
    <div ref={ref} className="relative flex items-center gap-2">
      <span className="text-sm text-muted-foreground">{label}:</span>
      <button
        onClick={() => setOpen((o) => !o)}
        className="flex items-center gap-2 rounded-md border border-border bg-card px-3 py-1.5 text-sm font-medium hover:bg-secondary"
      >
        {value}
        <ChevronDown className="h-4 w-4 text-muted-foreground" />
      </button>
      {open && (
        <div className="absolute left-0 top-full z-30 mt-1 min-w-[180px] overflow-hidden rounded-md border border-border bg-card py-1 shadow-lg">
          {options.map((opt) => (
            <button
              key={opt}
              onClick={() => {
                onChange(opt);
                setOpen(false);
              }}
              className={`block w-full px-3 py-1.5 text-left text-sm hover:bg-secondary ${
                opt === value ? "font-medium text-accent" : "text-foreground"
              }`}
            >
              {opt}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

function PopoverSelect({
  label,
  value,
  options,
  onChange,
}: {
  label: string;
  value: string;
  options: readonly string[];
  onChange: (v: string) => void;
}) {
  const [open, setOpen] = useState(false);
  const ref = useOutside<HTMLDivElement>(() => setOpen(false));
  return (
    <div ref={ref} className="relative">
      <label className="block text-xs font-medium text-muted-foreground">{label}</label>
      <button
        onClick={() => setOpen((o) => !o)}
        className="mt-1 flex w-full items-center justify-between gap-2 rounded-md border border-border bg-card px-3 py-2 text-sm font-medium hover:bg-secondary"
      >
        <span className={value === "All" ? "text-foreground" : "text-accent"}>{value}</span>
        <ChevronDown className="h-4 w-4 text-muted-foreground" />
      </button>
      {open && (
        <div className="absolute left-0 right-0 top-full z-30 mt-1 max-h-64 overflow-y-auto rounded-md border border-border bg-card py-1 shadow-lg">
          {options.map((opt) => (
            <button
              key={opt}
              onClick={() => {
                onChange(opt);
                setOpen(false);
              }}
              className={`block w-full px-3 py-1.5 text-left text-sm hover:bg-secondary ${
                opt === value ? "font-medium text-accent" : "text-foreground"
              }`}
            >
              {opt}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

type MoreState = Record<string, string>;

type FilterDef = { key: string; label: string; options: readonly string[]; default: string };

const SEASON_TOP: FilterDef[] = [
  { key: "market", label: "Market", options: MARKETS, default: "Spain" },
  { key: "region", label: "Region", options: REGIONS, default: "All" },
  { key: "category", label: "Category", options: CATEGORIES, default: "All" },
  { key: "season", label: "Planning Season", options: SEASONS, default: "SS25" },
];
const SEASON_MORE: FilterDef[] = [
  { key: "inclusion", label: "Scenario inclusion", options: SCENARIO_INCLUSION, default: "All" },
  { key: "confidence", label: "Confidence", options: CONFIDENCE, default: "All" },
  { key: "reason", label: "Main reason", options: SEASON_REASON, default: "All" },
];

const OPS_TOP: FilterDef[] = [
  { key: "market", label: "Market", options: MARKETS, default: "Spain" },
  { key: "region", label: "Region", options: REGIONS, default: "All" },
  { key: "actionType", label: "Action Type", options: ACTION_TYPES, default: "All" },
  { key: "actionWindow", label: "Action Window", options: ACTION_WINDOWS, default: "Next 2 weeks" },
];
const OPS_MORE: FilterDef[] = [
  { key: "queueStatus", label: "Queue status", options: QUEUE_STATUS, default: "All" },
  { key: "priority", label: "Priority", options: PRIORITY, default: "All" },
  { key: "reason", label: "Main reason", options: OPS_REASON, default: "All" },
];

function defaultsFor(defs: FilterDef[]): MoreState {
  return Object.fromEntries(defs.map((d) => [d.key, d.default]));
}

export function GlobalFilters({ variant = "season" }: { variant?: "season" | "ops" }) {
  const topDefs = variant === "ops" ? OPS_TOP : SEASON_TOP;
  const moreDefs = variant === "ops" ? OPS_MORE : SEASON_MORE;

  const [top, setTop] = useState<MoreState>(() => defaultsFor(topDefs));
  const [more, setMore] = useState<MoreState>(() => defaultsFor(moreDefs));
  const [draft, setDraft] = useState<MoreState>(() => defaultsFor(moreDefs));
  const [open, setOpen] = useState(false);
  const popRef = useOutside<HTMLDivElement>(() => setOpen(false));

  const activeMore = moreDefs.reduce((n, d) => n + (more[d.key] !== d.default ? 1 : 0), 0);

  return (
    <div className="mb-6 flex flex-wrap items-center gap-x-8 gap-y-3">
      {topDefs.map((d) => (
        <Dropdown
          key={d.key}
          label={d.label}
          value={top[d.key]}
          options={d.options}
          onChange={(v) => setTop({ ...top, [d.key]: v })}
        />
      ))}

      <div ref={popRef} className="relative ml-auto">
        <button
          onClick={() => {
            setDraft(more);
            setOpen((o) => !o);
          }}
          className="flex items-center gap-2 rounded-md border border-border bg-card px-3 py-1.5 text-sm font-medium hover:bg-secondary"
        >
          <Filter className="h-4 w-4" />
          More filters
          {activeMore > 0 && (
            <span className="inline-flex h-5 min-w-[20px] items-center justify-center rounded-full bg-accent px-1.5 text-[10px] font-semibold text-primary-foreground">
              {activeMore}
            </span>
          )}
        </button>
        {open && (
          <div className="absolute right-0 top-full z-40 mt-2 w-[360px] rounded-xl border border-border bg-card p-4 shadow-xl">
            <div className="flex items-center justify-between">
              <h4 className="text-sm font-semibold text-primary">More filters</h4>
              <button onClick={() => setOpen(false)} className="rounded-md p-1 text-muted-foreground hover:bg-secondary">
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="mt-3 grid grid-cols-1 gap-3">
              {moreDefs.map((d) => (
                <PopoverSelect
                  key={d.key}
                  label={d.label}
                  value={draft[d.key]}
                  options={d.options}
                  onChange={(v) => setDraft({ ...draft, [d.key]: v })}
                />
              ))}
            </div>

            <div className="mt-4 flex items-center justify-between gap-2">
              <button
                onClick={() => {
                  const d = defaultsFor(moreDefs);
                  setDraft(d);
                  setMore(d);
                }}
                className="rounded-md px-3 py-1.5 text-sm font-medium text-muted-foreground hover:bg-secondary hover:text-foreground"
              >
                Clear filters
              </button>
              <button
                onClick={() => {
                  setMore(draft);
                  setOpen(false);
                }}
                className="rounded-md bg-primary px-4 py-1.5 text-sm font-medium text-primary-foreground hover:opacity-90"
              >
                Apply filters
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export function ClusterContextChip({ cluster }: { cluster: string }) {
  return (
    <div className="mb-3 inline-flex items-center gap-2 rounded-md border border-border bg-secondary/50 px-3 py-1.5 text-xs font-medium">
      <span className="text-muted-foreground">Product Cluster:</span>
      <span className="text-accent">{cluster}</span>
    </div>
  );
}