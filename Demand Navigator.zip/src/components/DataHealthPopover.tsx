import { useEffect, useRef, useState } from "react";
import { X, ChevronDown, ChevronUp, CheckCircle2, AlertTriangle, Database } from "lucide-react";

function useOutside<T extends HTMLElement>(onClose: () => void) {
  const ref = useRef<T>(null);
  useEffect(() => {
    const fn = (e: MouseEvent) => {
      if (ref.current && !ref.current.contains(e.target as Node)) onClose();
    };
    document.addEventListener("mousedown", fn);
    return () => document.removeEventListener("mousedown", fn);
  }, [onClose]);
  return ref;
}

type Status = "Ready" | "Partial" | "Needs attention";

interface HealthItem {
  name: string;
  weight: string;
  score: number;
  status: Status;
  description: string;
}

const healthItems: HealthItem[] = [
  {
    name: "Baseline plan",
    weight: "25%",
    score: 100,
    status: "Ready",
    description: "SS25 buy and allocation plans uploaded",
  },
  {
    name: "Historical sales / PLC",
    weight: "25%",
    score: 96,
    status: "Ready",
    description: "SS24 sell-through and weekly PLC patterns loaded",
  },
  {
    name: "Inventory data",
    weight: "20%",
    score: 94,
    status: "Ready",
    description: "Store stock cover and replenishment data updated",
  },
  {
    name: "External signals",
    weight: "15%",
    score: 78,
    status: "Partial",
    description: "Search and weather signals available for priority regions",
  },
  {
    name: "Similar item matching",
    weight: "15%",
    score: 90,
    status: "Ready",
    description: "SS25 styles matched to similar SS24 items using image, material, text, and price similarity",
  },
];

const dataSources = [
  "Uploaded SS25 buy plan",
  "Uploaded SS25 allocation plan",
  "SS24 historical sales",
  "Current inventory snapshot",
  "Search trend feed",
  "Weather signal feed",
  "Similar item matching table",
];

function StatusBadge({ status }: { status: Status }) {
  if (status === "Ready") {
    return (
      <span className="inline-flex items-center gap-1 rounded-md bg-[color:var(--signal-green-bg)] px-2 py-0.5 text-[11px] font-medium text-[color:var(--signal-green)]">
        <CheckCircle2 className="h-3 w-3" />
        Ready
      </span>
    );
  }
  if (status === "Partial") {
    return (
      <span className="inline-flex items-center gap-1 rounded-md bg-[color:var(--signal-amber-bg)] px-2 py-0.5 text-[11px] font-medium text-[color:var(--signal-amber)]">
        <AlertTriangle className="h-3 w-3" />
        Partial
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1 rounded-md bg-red-100 px-2 py-0.5 text-[11px] font-medium text-red-700">
      <AlertTriangle className="h-3 w-3" />
      Needs attention
    </span>
  );
}

function ScoreBar({ score }: { score: number }) {
  const width = `${score}%`;
  return (
    <div className="h-1.5 w-full overflow-hidden rounded-full bg-secondary">
      <div
        className="h-full rounded-full bg-accent transition-all"
        style={{ width }}
      />
    </div>
  );
}

export function DataHealthPopover() {
  const [open, setOpen] = useState(false);
  const [showSources, setShowSources] = useState(false);
  const ref = useOutside<HTMLDivElement>(() => setOpen(false));

  return (
    <div ref={ref} className="relative">
      <button
        onClick={() => setOpen((o) => !o)}
        className="flex items-center gap-2 rounded-md border border-border bg-card px-3 py-1.5 text-sm hover:bg-secondary"
      >
        <span className="text-muted-foreground">Data Health</span>
        <span className="font-semibold">92%</span>
        <span className="h-2 w-2 rounded-full bg-[color:var(--signal-green)]" />
      </button>

      {open && (
        <div className="absolute right-0 top-full z-50 mt-2 w-[420px] rounded-xl border border-border bg-card p-5 shadow-xl">
          {/* Header */}
          <div className="flex items-start justify-between">
            <div>
              <h4 className="text-sm font-semibold text-primary">Data Health</h4>
              <div className="mt-1 flex items-center gap-2">
                <span className="text-lg font-bold">92%</span>
                <span className="text-sm text-muted-foreground">· Ready for recommendation</span>
              </div>
            </div>
            <button
              onClick={() => setOpen(false)}
              className="rounded-md p-1 text-muted-foreground hover:bg-secondary"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          {/* Explanation */}
          <p className="mt-3 text-sm leading-relaxed text-foreground">
            This score reflects whether the data needed to generate current recommendations is complete, recent, and usable.
          </p>

          <div className="mt-2 rounded-md border border-border bg-secondary/40 px-3 py-2 text-[12px] text-muted-foreground">
            <span className="font-medium text-foreground">Important:</span>{" "}
            Data Health is not model accuracy. It measures recommendation readiness based on data completeness, freshness, and coverage.
          </div>

          {/* Score breakdown */}
          <div className="mt-4 space-y-3">
            {healthItems.map((item) => (
              <div key={item.name} className="flex items-start gap-3">
                <div className="mt-0.5 min-w-[56px] text-[11px] text-muted-foreground">
                  {item.weight}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-sm font-medium text-foreground">{item.name}</span>
                    <StatusBadge status={item.status} />
                  </div>
                  <div className="mt-1 flex items-center gap-3">
                    <div className="flex-1">
                      <ScoreBar score={item.score} />
                    </div>
                    <span className="text-[12px] font-semibold text-foreground">{item.score}</span>
                  </div>
                  <p className="mt-1 text-[11px] text-muted-foreground">{item.description}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Formula helper */}
          <p className="mt-4 text-[11px] text-muted-foreground">
            Weighted readiness score based on completeness, freshness, and coverage.
          </p>

          {/* Bottom note */}
          <div className="mt-3 rounded-md border border-border bg-secondary/30 px-3 py-2 text-[12px] text-muted-foreground">
            Recommendations combine uploaded plans, historical sales, inventory, external demand signals, and similar item evidence.
          </div>

          {/* View data sources */}
          <button
            onClick={() => setShowSources((s) => !s)}
            className="mt-3 flex w-full items-center justify-between rounded-md border border-border bg-card px-3 py-2 text-sm font-medium text-foreground hover:bg-secondary"
          >
            <span className="flex items-center gap-2">
              <Database className="h-4 w-4 text-muted-foreground" />
              View data sources
            </span>
            {showSources ? (
              <ChevronUp className="h-4 w-4 text-muted-foreground" />
            ) : (
              <ChevronDown className="h-4 w-4 text-muted-foreground" />
            )}
          </button>

          {showSources && (
            <div className="mt-2 space-y-1.5 rounded-md border border-border bg-secondary/30 p-3">
              {dataSources.map((source) => (
                <div key={source} className="flex items-center gap-2 text-sm text-foreground">
                  <CheckCircle2 className="h-3.5 w-3.5 text-[color:var(--signal-green)]" />
                  {source}
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
