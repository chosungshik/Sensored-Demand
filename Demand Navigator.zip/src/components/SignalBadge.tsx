import { TrendingUp, AlertTriangle, Sparkles, Globe2, ShoppingBag, CloudSun, Layers, Zap } from "lucide-react";
import { signalTone, type SignalTone } from "@/lib/cockpit-data";

const toneStyles: Record<SignalTone, string> = {
  blue: "bg-[color:var(--signal-blue-bg)] text-[color:var(--signal-blue)]",
  red: "bg-[color:var(--signal-red-bg)] text-[color:var(--signal-red)]",
  green: "bg-[color:var(--signal-green-bg)] text-[color:var(--signal-green)]",
  purple: "bg-[color:var(--signal-purple-bg)] text-[color:var(--signal-purple)]",
  amber: "bg-[color:var(--signal-amber-bg)] text-[color:var(--signal-amber)]",
  teal: "bg-[color:var(--signal-teal-bg)] text-[color:var(--signal-teal)]",
  rose: "bg-[color:var(--signal-rose-bg)] text-[color:var(--signal-rose)]",
};

const iconMap: Record<string, React.ComponentType<{ className?: string }>> = {
  "Search trend": TrendingUp,
  "Stockout": AlertTriangle,
  "PLC growth": Sparkles,
  "Early PLC": Sparkles,
  "Regional demand": Globe2,
  "Sell-through": ShoppingBag,
  "Weather-sensitive": CloudSun,
  "Ribbed": Layers,
  "Similarity match": Zap,
};

export function SignalBadge({ label, muted }: { label: string; muted?: boolean }) {
  const tone = signalTone[label] ?? "blue";
  const Icon = iconMap[label] ?? TrendingUp;
  const cls = muted
    ? "bg-secondary text-muted-foreground"
    : toneStyles[tone];
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-md px-2 py-1 text-xs font-medium ${cls}`}>
      <Icon className="h-3.5 w-3.5" />
      {label}
    </span>
  );
}