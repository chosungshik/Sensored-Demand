import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { GlobalFilters } from "@/components/GlobalFilters";
import {
  AlertOctagon,
  Store,
  Euro,
  Info,
  ChevronRight,
  Truck,
  ArrowLeftRight,
  LayoutGrid,
  Shield,
  RefreshCw,
} from "lucide-react";

export const Route = createFileRoute("/operations-cockpit")({ component: Page });

type Priority = "High" | "Medium";
function PriorityPill({ level }: { level: Priority }) {
  const cls =
    level === "High"
      ? "bg-[color:var(--signal-rose-bg)] text-[color:var(--signal-rose)]"
      : "bg-[color:var(--signal-amber-bg)] text-[color:var(--signal-amber)]";
  return (
    <span className={`inline-flex whitespace-nowrap rounded-md px-2.5 py-0.5 text-[11px] font-medium ${cls}`}>
      {level}
    </span>
  );
}

type ChipTone = "muted" | "blue" | "green" | "amber" | "purple" | "rose";
function EvidenceChip({ label, tone = "muted" }: { label: string; tone?: ChipTone }) {
  const toneMap: Record<ChipTone, string> = {
    muted: "bg-secondary text-foreground",
    blue: "bg-[color:var(--signal-blue-bg)] text-[color:var(--signal-blue)]",
    green: "bg-[color:var(--signal-green-bg)] text-[color:var(--signal-green)]",
    amber: "bg-[color:var(--signal-amber-bg)] text-[color:var(--signal-amber)]",
    purple: "bg-[color:var(--signal-purple-bg)] text-[color:var(--signal-purple)]",
    rose: "bg-[color:var(--signal-rose-bg)] text-[color:var(--signal-rose)]",
  };
  return (
    <span className={`inline-flex whitespace-nowrap rounded-md px-2 py-0.5 text-[11px] font-medium ${toneMap[tone]}`}>
      {label}
    </span>
  );
}

function evidenceTone(label: string): ChipTone {
  const k = label.toLowerCase();
  if (k.includes("heat") || k.includes("weather")) return "amber";
  if (k.includes("low stock") || k.includes("low cover") || k.includes("stockout") || k.includes("shortage")) return "rose";
  if (k.includes("sell-through") || k.includes("fast")) return "green";
  if (k.includes("visibility") || k.includes("display")) return "blue";
  if (k.includes("excess") || k.includes("markdown")) return "purple";
  if (k.includes("store") || k.includes("risk")) return "muted";
  return "muted";
}

type Row = {
  priority: Priority;
  decision: string;
  location: string;
  stores: string;
  cluster: string;
  action: string;
  actionIcon: typeof Truck;
  reason: string;
  evidence: string[];
  risk: string;
  impact: string;
  impactTone: "green" | "blue";
  next: string;
};

const rows: Row[] = [
  {
    priority: "High",
    decision: "Replenish now",
    location: "Seville",
    stores: "7 stores",
    cluster: "Ribbed Tanks",
    action: "DC replenishment",
    actionIcon: Truck,
    reason: "Heat spike + low stock cover",
    evidence: ["Heat spike", "Low stock cover"],
    risk: "May run low within\u00a02\u00a0weeks",
    impact: "€42K protected",
    impactTone: "green",
    next: "Review 3 actions",
  },
  {
    priority: "High",
    decision: "Transfer stock",
    location: "Valencia",
    stores: "5 stores",
    cluster: "Linen Shirts",
    action: "Transfer from other stores",
    actionIcon: ArrowLeftRight,
    reason: "Fast sell-through + low cover",
    evidence: ["Fast sell-through", "Low cover"],
    risk: "Missed sales risk",
    impact: "€24K uplift",
    impactTone: "green",
    next: "Review 2 actions",
  },
  {
    priority: "Medium",
    decision: "Improve display",
    location: "Barcelona",
    stores: "6 stores",
    cluster: "Lightweight Dresses",
    action: "Move to front display",
    actionIcon: LayoutGrid,
    reason: "Rain forecast + low visibility",
    evidence: ["Weather shift", "Low visibility"],
    risk: "Slower sell-through",
    impact: "€18K uplift",
    impactTone: "green",
    next: "Review 2 actions",
  },
  {
    priority: "Medium",
    decision: "Replenish selected stores",
    location: "Bilbao",
    stores: "3 stores",
    cluster: "Cotton Tees",
    action: "DC replenishment",
    actionIcon: Truck,
    reason: "Size shortage in key stores",
    evidence: ["Size shortage", "Store risk"],
    risk: "Localized stockout risk",
    impact: "€12K protected",
    impactTone: "green",
    next: "Review 2 actions",
  },
  {
    priority: "Medium",
    decision: "Recover excess stock",
    location: "Madrid",
    stores: "4 stores",
    cluster: "Summer Dresses",
    action: "Transfer to outlet stores",
    actionIcon: ArrowLeftRight,
    reason: "Excess stock creating markdown risk",
    evidence: ["Excess stock", "Markdown risk"],
    risk: "Markdown risk",
    impact: "€9K recovery",
    impactTone: "green",
    next: "Review 2 actions",
  },
];

function DecisionCard({
  icon,
  iconBg,
  iconTone,
  title,
  value,
  valueTone,
  subtitle,
  signal,
}: {
  icon: React.ReactNode;
  iconBg: string;
  iconTone?: string;
  title: string;
  value: React.ReactNode;
  valueTone: string;
  subtitle: string;
  signal?: string;
}) {
  return (
    <div className="rounded-xl border border-border bg-card p-5 shadow-[var(--shadow-card)]">
      <div className="flex items-start gap-4">
        <span className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-full ${iconBg} ${iconTone ?? ""}`}>
          {icon}
        </span>
        <div className="min-w-0">
          <div className="flex items-center gap-1.5 text-sm font-medium text-primary">
            {title}
            <Info className="h-3.5 w-3.5 text-muted-foreground" />
          </div>
          <div className={`mt-1 text-[22px] font-semibold leading-tight ${valueTone}`}>{value}</div>
          <div className="mt-1.5 text-xs text-muted-foreground">{subtitle}</div>
          {signal && <div className="mt-1 text-xs text-muted-foreground">{signal}</div>}
        </div>
      </div>
    </div>
  );
}

function Page() {
  const navigate = useNavigate();

  const goToActions = (location: string, cluster: string) =>
    navigate({ to: "/recommended-actions", search: { location, cluster } as never });

  return (
    <AppShell>
      <GlobalFilters variant="ops" />

      {/* Title + last updated */}
      <div className="mb-1 flex items-start justify-between">
        <h1 className="text-2xl font-semibold tracking-tight text-primary">Operations Cockpit</h1>
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <span>Last updated: May 20, 2025 09:30 AM</span>
          <RefreshCw className="h-3.5 w-3.5" />
        </div>
      </div>
      {/* Top decision message */}
      <div className="mb-5 flex items-start gap-3 rounded-xl border border-border bg-[color:var(--signal-blue-bg)]/40 px-5 py-4">
        <Info className="mt-0.5 h-5 w-5 shrink-0 text-accent" />
        <div className="text-sm leading-relaxed">
          <ul className="list-disc space-y-1 pl-4 text-foreground marker:text-accent">
            <li>5 urgent store actions recommended for the next 2 weeks — led by Ribbed Tanks in Seville</li>
            <li>Prioritized by stock cover, sell-through speed, weather shift, and store-level demand signals</li>
            <li>Goal: protect sales and reduce stockout risk across the network</li>
          </ul>
        </div>
      </div>

      {/* Decision cards */}
      <div className="mt-5 grid grid-cols-1 gap-5 md:grid-cols-3">
        <DecisionCard
          icon={<AlertOctagon className="h-6 w-6 text-[color:var(--signal-rose)]" />}
          iconBg="bg-[color:var(--signal-rose-bg)]"
          title="Urgent actions"
          value={<span>5 actions</span>}
          valueTone="text-[color:var(--signal-rose)]"
          subtitle="Need review within 48 hours"
          signal="Main risk: early stockout"
        />
        <DecisionCard
          icon={<Store className="h-6 w-6 text-primary" />}
          iconBg="bg-secondary"
          title="Where to act first"
          value={<span>Seville · 7 stores</span>}
          valueTone="text-primary"
          subtitle="Main issue: Ribbed Tanks low cover"
        />
        <DecisionCard
          icon={<Euro className="h-6 w-6 text-[color:var(--signal-green)]" />}
          iconBg="bg-[color:var(--signal-green-bg)]"
          title="Potential impact if implemented"
          value={<span>€186K – €220K</span>}
          valueTone="text-[color:var(--signal-green)]"
          subtitle="Protected sales / uplift / recovery"
        />
      </div>

      {/* Table */}
      <section className="mt-6 rounded-xl border border-border bg-card shadow-[var(--shadow-card)]">
        <div className="border-b border-border px-6 py-4">
          <h2 className="text-base font-semibold">Recommended Store Action Decisions</h2>
          <p className="mt-1 text-xs text-muted-foreground">
            Grouped by location and product cluster for the next 2 weeks.
          </p>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border text-left text-xs font-medium text-muted-foreground">
                <th className="px-4 py-3">
                  <span className="inline-flex items-center gap-1">Priority <Info className="h-3 w-3" /></span>
                </th>
                <th className="px-3 py-3">Decision</th>
                <th className="px-3 py-3">Affected Location</th>
                <th className="px-3 py-3">
                  <span className="inline-flex items-center gap-1">Product Cluster <Info className="h-3 w-3" /></span>
                </th>
                <th className="px-3 py-3">Recommended Action</th>
                <th className="px-3 py-3">Main Reason</th>
                <th className="px-3 py-3">Risk if ignored</th>
                <th className="px-3 py-3">
                  <span className="inline-flex items-center gap-1">Potential Impact <Info className="h-3 w-3" /></span>
                </th>
                <th className="px-3 py-3">Next Step</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => {
                const ActionIcon = r.actionIcon;
                return (
                  <tr
                    key={r.location + r.cluster}
                    onClick={() => goToActions(r.location, r.cluster)}
                    className="group h-[88px] cursor-pointer border-b border-border/60 last:border-0 align-middle hover:bg-secondary/40"
                  >
                    <td className="px-4 py-4 align-middle">
                      <PriorityPill level={r.priority} />
                    </td>
                    <td className="px-3 py-4 align-middle font-medium text-foreground">{r.decision}</td>
                    <td className="px-3 py-4 align-middle text-sm">
                      <div className="font-medium">{r.location}</div>
                      <div className="text-xs text-muted-foreground">{r.stores}</div>
                    </td>
                    <td className="px-3 py-4 align-middle font-medium text-accent">{r.cluster}</td>
                    <td className="px-3 py-4 align-middle">
                      <div className="flex items-start gap-2 text-sm">
                        <ActionIcon className="mt-0.5 h-4 w-4 shrink-0 text-muted-foreground" />
                        <span>{r.action}</span>
                      </div>
                    </td>
                    <td className="px-3 py-4 align-middle">
                      <div className="flex flex-wrap gap-1.5">
                        {r.evidence.map((e) => (
                          <EvidenceChip key={e} label={e} tone={evidenceTone(e)} />
                        ))}
                      </div>
                      <div className="mt-1.5 text-xs text-muted-foreground">{r.reason}</div>
                    </td>
                    <td className="px-3 py-4 align-middle text-sm leading-snug text-muted-foreground">
                      <div className="flex items-start gap-1.5">
                        <Shield className="mt-0.5 h-3.5 w-3.5 shrink-0 text-muted-foreground" />
                        <span>{r.risk}</span>
                      </div>
                    </td>
                    <td className="px-3 py-4 align-middle text-sm font-medium text-[color:var(--signal-green)]">
                      {r.impact}
                    </td>
                    <td className="px-3 py-4 align-middle">
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          goToActions(r.location, r.cluster);
                        }}
                        className="inline-flex items-center gap-1 whitespace-nowrap text-sm font-medium text-accent hover:underline"
                      >
                        {r.next}
                        <ChevronRight className="h-4 w-4" />
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </section>
    </AppShell>
  );
}