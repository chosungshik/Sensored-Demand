import { useState } from "react";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import {
  Upload,
  Plug,
  Check,
  ChevronRight,
  ChevronLeft,
  Database,
  Store,
  ShoppingBag,
  Building2,
  FileSpreadsheet,
  Info,
  ShieldCheck,
  Sparkles,
} from "lucide-react";
import { setupStore, useSetupState } from "@/lib/setup-store";
import { toast } from "sonner";

export const Route = createFileRoute("/data-setup")({ component: Page });

type Step = 0 | 1 | 2 | 3 | 4;

const profiles = [
  { id: "Online-only Brand", icon: ShoppingBag, desc: "DTC ecommerce, single channel" },
  { id: "Online + Offline Stores", icon: Store, desc: "Ecommerce plus physical retail network" },
  { id: "Large Basic-item Brand", icon: Database, desc: "High-volume, replenishment-heavy assortment" },
  { id: "Enterprise ERP-integrated Brand", icon: Building2, desc: "ERP, POS, WMS connected at enterprise scale" },
];

const requiredSources = [
  "Product master",
  "Store master",
  "Sales history",
  "Inventory data",
  "Baseline buy plan",
  "Baseline allocation plan",
];
const optionalSources = [
  "Search trend feed",
  "Weather signal feed",
  "Promotion / discount history",
];

const mappings = [
  { src: "SKU", field: "sku" },
  { src: "Product ID", field: "product_id" },
  { src: "Store code", field: "store_id" },
  { src: "Sales quantity", field: "sales_qty" },
  { src: "Stock quantity", field: "stock_qty" },
  { src: "Date", field: "date" },
];

const validation = [
  { name: "Product master", status: "Ready" as const },
  { name: "Sales history", status: "Ready" as const },
  { name: "Inventory data", status: "Ready" as const },
  { name: "Baseline plans", status: "Ready" as const },
  { name: "External signals", status: "Partial" as const },
];

function Page() {
  const navigate = useNavigate();
  const setup = useSetupState();
  const [step, setStep] = useState<Step>(0);
  const [source, setSource] = useState<"files" | "api">("files");

  const goDashboard = () => {
    setupStore.completeSetup(92);
    toast("Setup complete — Data Health 92%");
    navigate({ to: "/" });
  };

  const stepLabels = ["Data sources", "Mapping", "Validation", "Activation"];

  return (
    <AppShell>
      <div className="mx-auto max-w-[1080px]">
        {step === 0 && (
          <div className="rounded-xl border border-border bg-card p-8 shadow-[var(--shadow-card)]">
            <div className="flex items-start gap-4">
              <span className="flex h-12 w-12 items-center justify-center rounded-full bg-[color:var(--signal-blue-bg)]">
                <Sparkles className="h-6 w-6 text-accent" />
              </span>
              <div>
                <h1 className="text-2xl font-semibold tracking-tight text-primary">
                  Set up Fashion Demand Intelligence
                </h1>
                <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
                  Connect your baseline plans, sales history, inventory, product data, and external
                  signals to activate planning and operations recommendations.
                </p>
                <div className="mt-3 flex items-start gap-2 rounded-md border border-border bg-secondary/30 px-3 py-2 text-xs text-muted-foreground">
                  <Info className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                  <span>
                    Connect data once through uploaded files or API integrations. After setup is
                    complete, planners and operators can use recommendations without repeating this
                    step.
                  </span>
                </div>
              </div>
            </div>

            <div className="mt-6 grid grid-cols-1 gap-4 md:grid-cols-2">
              {[
                { id: "files" as const, icon: Upload, title: "Upload planning and sales files", desc: "CSV or XLSX uploads for baseline plans and history" },
                { id: "api" as const, icon: Plug, title: "Connect API / ERP / POS / WMS integration", desc: "Direct integration with enterprise systems" },
              ].map((o) => {
                const Icon = o.icon;
                const active = source === o.id;
                return (
                  <button
                    key={o.id}
                    onClick={() => setSource(o.id)}
                    className={`flex items-start gap-3 rounded-lg border p-4 text-left transition-colors ${
                      active ? "border-accent bg-[color:var(--signal-blue-bg)]/40" : "border-border bg-card hover:bg-secondary/50"
                    }`}
                  >
                    <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-secondary">
                      <Icon className="h-5 w-5 text-foreground" />
                    </span>
                    <div>
                      <div className="text-sm font-semibold">{o.title}</div>
                      <div className="mt-1 text-xs text-muted-foreground">{o.desc}</div>
                    </div>
                  </button>
                );
              })}
            </div>

            <div className="mt-6">
              <div className="mb-2 text-sm font-semibold">Retail profile</div>
              <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
                {profiles.map((p) => {
                  const Icon = p.icon;
                  const active = setup.profile === p.id;
                  return (
                    <button
                      key={p.id}
                      onClick={() => setupStore.setProfile(p.id)}
                      className={`flex flex-col items-start gap-2 rounded-lg border p-3 text-left transition-colors ${
                        active ? "border-accent bg-[color:var(--signal-blue-bg)]/40" : "border-border bg-card hover:bg-secondary/50"
                      }`}
                    >
                      <span className="flex h-8 w-8 items-center justify-center rounded-full bg-secondary">
                        <Icon className="h-4 w-4" />
                      </span>
                      <div className="text-sm font-semibold leading-tight">{p.id}</div>
                      <div className="text-[11px] text-muted-foreground">{p.desc}</div>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="mt-6 rounded-lg border border-border bg-secondary/30 p-4">
              <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                Active modules
              </div>
              <div className="mt-2 flex flex-wrap gap-2">
                {[
                  "Season Planning",
                  "Style Selection",
                  "In-season Operations",
                  "Store Actions",
                  "Similar Item Matching",
                  "Data Health",
                ].map((m) => (
                  <span key={m} className="inline-flex items-center gap-1 rounded-md bg-card border border-border px-2.5 py-1 text-xs font-medium">
                    <Check className="h-3 w-3 text-[color:var(--signal-green)]" />
                    {m}
                  </span>
                ))}
              </div>
              <div className="mt-3 text-xs text-muted-foreground">
                Next step: connect baseline data sources or use mock data for demo.
              </div>
            </div>

            <div className="mt-6 flex items-center justify-end gap-3">
              <button
                onClick={goDashboard}
                className="rounded-md border border-border bg-card px-5 py-2.5 text-sm font-medium hover:bg-secondary"
              >
                Use Demo Data
              </button>
              <button
                onClick={() => setStep(1)}
                className="inline-flex items-center gap-2 rounded-md bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground hover:opacity-90"
              >
                Continue Setup <ChevronRight className="h-4 w-4" />
              </button>
            </div>
          </div>
        )}

        {step > 0 && (
          <div className="rounded-xl border border-border bg-card p-8 shadow-[var(--shadow-card)]">
            {/* Stepper */}
            <div className="mb-6 flex items-center justify-between gap-2">
              {stepLabels.map((l, i) => {
                const active = step === (i + 1);
                const done = step > (i + 1);
                return (
                  <div key={l} className="flex flex-1 items-center gap-2">
                    <span
                      className={`flex h-6 w-6 items-center justify-center rounded-full text-[11px] font-semibold ${
                        done ? "bg-[color:var(--signal-green)] text-white" : active ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"
                      }`}
                    >
                      {done ? <Check className="h-3.5 w-3.5" /> : i + 1}
                    </span>
                    <span className={`text-xs font-medium ${active || done ? "text-foreground" : "text-muted-foreground"}`}>{l}</span>
                    {i < stepLabels.length - 1 && <span className="flex-1 border-t border-dashed border-border" />}
                  </div>
                );
              })}
            </div>

            {step === 1 && (
              <div>
                <h2 className="text-lg font-semibold text-primary">Data sources</h2>
                <p className="mt-1 text-sm text-muted-foreground">Select which sources to connect.</p>
                <div className="mt-4 grid grid-cols-1 gap-4 md:grid-cols-2">
                  <div>
                    <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Required</div>
                    <ul className="mt-2 space-y-1.5">
                      {requiredSources.map((s) => (
                        <li key={s} className="flex items-center gap-2 rounded-md border border-border bg-card px-3 py-2 text-sm">
                          <FileSpreadsheet className="h-4 w-4 text-accent" />
                          <span className="flex-1">{s}</span>
                          <span className="rounded-md bg-[color:var(--signal-green-bg)] px-2 py-0.5 text-[11px] font-medium text-[color:var(--signal-green)]">Connected</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div>
                    <div className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Optional</div>
                    <ul className="mt-2 space-y-1.5">
                      {optionalSources.map((s) => (
                        <li key={s} className="flex items-center gap-2 rounded-md border border-border bg-card px-3 py-2 text-sm">
                          <FileSpreadsheet className="h-4 w-4 text-muted-foreground" />
                          <span className="flex-1">{s}</span>
                          <span className="rounded-md bg-secondary px-2 py-0.5 text-[11px] font-medium text-muted-foreground">Optional</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            )}

            {step === 2 && (
              <div>
                <h2 className="text-lg font-semibold text-primary">Mapping</h2>
                <p className="mt-1 text-sm text-muted-foreground">Map your source columns to system fields.</p>
                <div className="mt-4 overflow-hidden rounded-lg border border-border">
                  <table className="w-full text-sm">
                    <thead>
                      <tr className="border-b border-border bg-secondary/40 text-left text-[11px] font-medium uppercase tracking-wide text-muted-foreground">
                        <th className="px-4 py-2">Source column</th>
                        <th className="px-4 py-2">System field</th>
                        <th className="px-4 py-2">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {mappings.map((m) => (
                        <tr key={m.src} className="border-b border-border/60 last:border-0">
                          <td className="px-4 py-2.5">{m.src}</td>
                          <td className="px-4 py-2.5 font-mono text-xs">{m.field}</td>
                          <td className="px-4 py-2.5">
                            <span className="inline-flex rounded-md bg-[color:var(--signal-green-bg)] px-2 py-0.5 text-[11px] font-medium text-[color:var(--signal-green)]">Mapped</span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            {step === 3 && (
              <div>
                <h2 className="text-lg font-semibold text-primary">Validation</h2>
                <p className="mt-1 text-sm text-muted-foreground">Data quality check across connected sources.</p>
                <div className="mt-4 space-y-2">
                  {validation.map((v) => (
                    <div key={v.name} className="flex items-center gap-3 rounded-md border border-border bg-card px-4 py-2.5 text-sm">
                      <span className="flex-1 font-medium">{v.name}</span>
                      <span
                        className={`rounded-md px-2 py-0.5 text-[11px] font-medium ${
                          v.status === "Ready"
                            ? "bg-[color:var(--signal-green-bg)] text-[color:var(--signal-green)]"
                            : "bg-[color:var(--signal-amber-bg)] text-[color:var(--signal-amber)]"
                        }`}
                      >
                        {v.status}
                      </span>
                    </div>
                  ))}
                </div>
                <div className="mt-4 flex items-start gap-2 rounded-lg border border-border bg-[color:var(--signal-green-bg)]/30 px-4 py-3 text-sm">
                  <ShieldCheck className="mt-0.5 h-4 w-4 shrink-0 text-[color:var(--signal-green)]" />
                  <span>Data quality meets minimum requirements for recommendation generation.</span>
                </div>
              </div>
            )}

            {step === 4 && (
              <div>
                <h2 className="text-lg font-semibold text-primary">Activation</h2>
                <p className="mt-1 text-sm text-muted-foreground">System ready.</p>
                <div className="mt-4 rounded-lg border border-border bg-[color:var(--signal-green-bg)]/30 p-4">
                  <div className="flex items-center gap-2 text-sm font-semibold text-[color:var(--signal-green)]">
                    <Check className="h-4 w-4" /> System ready
                  </div>
                  <div className="mt-3 text-xs font-medium uppercase tracking-wide text-muted-foreground">Activated modules</div>
                  <div className="mt-2 flex flex-wrap gap-2">
                    {["Season Planning", "In-season Operations", "Data Health", "Similar Item Matching"].map((m) => (
                      <span key={m} className="inline-flex items-center gap-1 rounded-md border border-border bg-card px-2.5 py-1 text-xs font-medium">
                        <Check className="h-3 w-3 text-[color:var(--signal-green)]" />
                        {m}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
            )}

            <div className="mt-6 flex items-center justify-between gap-3">
              <button
                onClick={() => setStep(Math.max(1, step - 1) as Step)}
                className="inline-flex items-center gap-2 rounded-md border border-border bg-card px-5 py-2.5 text-sm font-medium hover:bg-secondary"
                disabled={step === 1}
              >
                <ChevronLeft className="h-4 w-4" /> Back
              </button>
              {step < 4 ? (
                <button
                  onClick={() => setStep((step + 1) as Step)}
                  className="inline-flex items-center gap-2 rounded-md bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground hover:opacity-90"
                >
                  Continue <ChevronRight className="h-4 w-4" />
                </button>
              ) : (
                <button
                  onClick={goDashboard}
                  className="inline-flex items-center gap-2 rounded-md bg-primary px-5 py-2.5 text-sm font-medium text-primary-foreground hover:opacity-90"
                >
                  Enter Dashboard <ChevronRight className="h-4 w-4" />
                </button>
              )}
            </div>
          </div>
        )}
      </div>
    </AppShell>
  );
}
