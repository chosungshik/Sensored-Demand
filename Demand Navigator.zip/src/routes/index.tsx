import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Info, TrendingUp, Target, ShieldCheck, ChevronRight, X } from "lucide-react";
import { AppShell } from "@/components/AppShell";
import { GlobalFilters } from "@/components/GlobalFilters";
import { SignalBadge } from "@/components/SignalBadge";
import { useSetupState } from "@/lib/setup-store";

export const Route = createFileRoute("/")({
  component: Index,
});

function DecisionCard({
  icon, iconBg, title, value, valueSize, subtitle, signals,
}: { icon: React.ReactNode; iconBg: string; title: string; value: string; valueSize?: string; subtitle: string; signals: string[]; }) {
  return (
    <div className="flex h-full flex-col rounded-xl border border-border bg-card p-5 shadow-[var(--shadow-card)]">
      <div className="flex items-start gap-4">
        <div className={`flex h-12 w-12 shrink-0 items-center justify-center rounded-full ${iconBg}`}>{icon}</div>
        <div className="min-w-0 flex-1">
          <div className="text-sm text-muted-foreground">{title}</div>
          <div className={`mt-1 font-semibold tracking-tight text-primary ${valueSize ?? "text-3xl"}`}>{value}</div>
          <div className="mt-1 text-sm text-muted-foreground">{subtitle}</div>
        </div>
      </div>
      <div className="mt-auto pt-5">
        <div className="text-xs font-medium text-muted-foreground">Evidence</div>
        <div className="mt-2 flex flex-wrap gap-1.5">
          {signals.map((s) => <SignalBadge key={s} label={s} />)}
        </div>
      </div>
    </div>
  );
}

type DecisionTone = "strong" | "increase" | "selective";
function DecisionBadge({ label, tone }: { label: string; tone: DecisionTone }) {
  const cls =
    tone === "strong"
      ? "border-transparent bg-[color:var(--signal-green-bg)] text-[color:var(--signal-green)]"
      : tone === "increase"
      ? "border-transparent bg-[color:var(--signal-green-bg)]/60 text-[color:var(--signal-green)]"
      : "border-transparent bg-[color:var(--signal-amber-bg)] text-[color:var(--signal-amber)]";
  return <span className={`inline-flex whitespace-nowrap rounded-md border px-2.5 py-1 text-xs font-medium ${cls}`}>{label}</span>;
}

type ConfTone = "high" | "medium" | "low";
function ConfidenceDot({ label, tone }: { label: string; tone: ConfTone }) {
  const dot =
    tone === "high"
      ? "bg-[color:var(--signal-green)]"
      : tone === "medium"
      ? "bg-[color:var(--signal-amber)]"
      : "bg-[color:var(--signal-rose)]";
  return (
    <span className="inline-flex items-center gap-2 whitespace-nowrap text-sm font-medium">
      {label}
      <span className={`h-2 w-2 rounded-full ${dot}`} />
    </span>
  );
}

const priorityRing = [
  "bg-[color:var(--signal-rose-bg)] text-[color:var(--signal-rose)]",
  "bg-[color:var(--signal-amber-bg)] text-[color:var(--signal-amber)]",
  "bg-secondary text-foreground",
  "bg-secondary text-muted-foreground",
  "bg-secondary text-muted-foreground",
];

type Row = {
  priority: number;
  slug: string;
  decision: string;
  decisionTone: DecisionTone;
  cluster: string;
  change: string;
  reason: string;
  evidence: string[];
  confidence: string;
  confTone: ConfTone;
  upside: string;
  nextStep: string;
};

const rows: Row[] = [
  { priority: 1, slug: "ribbed-tanks", decision: "Strong increase", decisionTone: "strong", cluster: "Ribbed Tanks", change: "+1.2K – +1.6K units", reason: "Faster sell-through than PLC; early stockout risk.", evidence: ["Similar SS24 items", "Search uplift", "Stockout risk"], confidence: "High", confTone: "high", upside: "€580K – €640K", nextStep: "Review 3 styles" },
  { priority: 2, slug: "linen-shirts", decision: "Increase", decisionTone: "increase", cluster: "Linen Shirts", change: "+0.8K – +1.0K units", reason: "Early sell-through with search growth.", evidence: ["Early sell-through", "Search uplift"], confidence: "High", confTone: "high", upside: "€310K – €390K", nextStep: "Review 2 styles" },
  { priority: 3, slug: "lightweight-dresses", decision: "Selective increase", decisionTone: "selective", cluster: "Lightweight Dresses", change: "+0.6K – +0.9K units", reason: "Weather-driven uplift in warm regions.", evidence: ["Weather-sensitive", "Regional concentration"], confidence: "Medium", confTone: "medium", upside: "€240K – €310K", nextStep: "Review 2 styles" },
  { priority: 4, slug: "crochet-tops", decision: "Increase", decisionTone: "increase", cluster: "Crochet Tops", change: "+0.4K – +0.6K units", reason: "Early trend signal; positive PLC.", evidence: ["Trend signal", "PLC growth"], confidence: "Medium", confTone: "medium", upside: "€150K – €210K", nextStep: "Review 1 style" },
  { priority: 5, slug: "wide-leg-pants", decision: "Selective increase", decisionTone: "selective", cluster: "Wide Leg Pants", change: "+0.3K – +0.5K units", reason: "Strong sell-through; concentrated region.", evidence: ["Sell-through", "Regional concentration"], confidence: "Medium", confTone: "medium", upside: "€110K – €150K", nextStep: "Review 1 style" },
];

function HowCalculatedModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  if (!open) return null;
  return (
    <>
      <div className="fixed inset-0 z-40 bg-black/40" onClick={onClose} />
      <div className="fixed left-1/2 top-1/2 z-50 w-[480px] -translate-x-1/2 -translate-y-1/2 rounded-xl border border-border bg-card p-6 shadow-2xl">
        <div className="flex items-start justify-between">
          <h3 className="text-lg font-semibold">How recommendations are generated</h3>
          <button onClick={onClose} className="rounded-md p-1 hover:bg-secondary"><X className="h-4 w-4" /></button>
        </div>
        <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
          Recommendations combine uploaded baseline buy plan, similar SS24 item performance, PLC velocity,
          current search uplift, stockout risk, regional concentration, and external drivers.
        </p>
        <div className="mt-5 flex justify-end">
          <button onClick={onClose} className="rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:opacity-90">Got it</button>
        </div>
      </div>
    </>
  );
}

function Index() {
  const navigate = useNavigate();
  const setup = useSetupState();
  useEffect(() => {
    if (!setup.complete) navigate({ to: "/data-setup" });
  }, [setup.complete, navigate]);
  const [modalOpen, setModalOpen] = useState(false);

  return (
    <AppShell>
      <GlobalFilters />

      {/* Title */}
      <div className="mb-5">
        <h1 className="text-2xl font-semibold tracking-tight text-primary">Buy Recommendations</h1>
      </div>

      {/* Top decision message */}
      <div className="mb-5 flex items-start gap-3 rounded-xl border border-border bg-[color:var(--signal-blue-bg)]/40 px-5 py-4">
        <Info className="mt-0.5 h-5 w-5 shrink-0 text-accent" />
        <div className="text-sm leading-relaxed">
          <div className="text-foreground">
            Increase buy for 4 clusters; selectively review 2 more to reduce stockout risk.
          </div>
          <div className="mt-1 text-muted-foreground">
            Led by Ribbed Tanks, Linen Shirts, and Lightweight Dresses.
          </div>
        </div>
      </div>

      {/* Decision cards */}
      <div className="grid grid-cols-1 gap-5 md:grid-cols-3">
        <DecisionCard
          icon={<TrendingUp className="h-6 w-6 text-[color:var(--signal-green)]" />}
          iconBg="bg-[color:var(--signal-green-bg)]"
          title="Recommended buy increase"
          value="+3.8K – +4.6K"
          subtitle="units vs. baseline plan"
          signals={["Similar SS24 items", "Search uplift", "Stockout risk"]}
        />
        <DecisionCard
          icon={<Target className="h-6 w-6 text-[color:var(--signal-purple)]" />}
          iconBg="bg-[color:var(--signal-purple-bg)]"
          title="Where to act first"
          value="3 clusters"
          subtitle="Top priority clusters"
          signals={["Ribbed Tanks", "Linen Shirts", "Lightweight Dresses"]}
        />
        <DecisionCard
          icon={<ShieldCheck className="h-6 w-6 text-[color:var(--signal-blue)]" />}
          iconBg="bg-[color:var(--signal-blue-bg)]"
          title="Confidence / Risk"
          value="High confidence"
          subtitle="Top risk: Ribbed Tanks stockout"
          signals={["Inventory risk", "Early sell-through", "Demand signal"]}
        />
      </div>

      {/* Table */}
      <section className="mt-6 rounded-xl border border-border bg-card shadow-[var(--shadow-card)]">
        <div className="flex items-start justify-between border-b border-border px-6 py-5">
          <div>
            <h2 className="text-base font-semibold">Recommended Buy Decisions</h2>
            <p className="mt-1 text-sm text-muted-foreground">AI-recommended changes vs. baseline buy plan.</p>
          </div>
          <button
            onClick={() => setModalOpen(true)}
            className="flex items-center gap-1.5 text-sm font-medium text-accent hover:underline"
          >
            <Info className="h-4 w-4" />
            How recommendations are generated
          </button>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border text-center text-xs font-medium text-muted-foreground">
                <th className="px-6 py-3 text-center">Priority</th>
                <th className="px-3 py-3 text-center">Decision</th>
                <th className="px-3 py-3 text-center">Product Cluster</th>
                <th className="px-3 py-3 text-center">Change</th>
                <th className="px-3 py-3 text-center">Main Reason</th>
                <th className="px-3 py-3 text-center">Confidence</th>
                <th className="px-3 py-3 text-center">Upside <span className="font-normal text-muted-foreground/70">(EUR)</span></th>
                <th className="px-3 py-3 text-center">Next Step</th>
                <th className="px-6 py-3 text-center"></th>
              </tr>
            </thead>
            <tbody>
              {rows.map((row) => (
                <tr key={row.slug} className="group h-[88px] border-b border-border/60 last:border-0 hover:bg-secondary/40">
                  <td className="px-6 py-4 align-middle text-center">
                    <div className={`flex h-7 w-7 items-center justify-center rounded-full text-xs font-semibold ${priorityRing[row.priority - 1]}`}>{row.priority}</div>
                  </td>
                  <td className="px-3 py-4 align-middle text-center">
                    <DecisionBadge label={row.decision} tone={row.decisionTone} />
                  </td>
                  <td className="px-3 py-4 align-middle text-center">
                    <Link
                      to="/demand-opportunity/$cluster"
                      params={{ cluster: row.slug }}
                      className="font-medium text-accent hover:underline"
                    >
                      {row.cluster}
                    </Link>
                  </td>
                  <td className="px-3 py-4 align-middle text-center font-medium whitespace-nowrap">{row.change}</td>
                  <td className="px-3 py-4 align-middle">
                    <div className="max-w-[300px] truncate text-sm text-foreground" title={row.reason}>{row.reason}</div>
                    <div className="mt-1.5 flex flex-wrap gap-1.5">
                      {row.evidence.map((d) => <SignalBadge key={d} label={d} />)}
                    </div>
                  </td>
                  <td className="px-3 py-4 align-middle">
                    <ConfidenceDot label={row.confidence} tone={row.confTone} />
                  </td>
                  <td className="px-3 py-4 align-middle text-center font-medium whitespace-nowrap">{row.upside}</td>
                  <td className="px-3 py-4 align-middle text-center">
                    <Link
                      to="/demand-opportunity/$cluster"
                      params={{ cluster: row.slug }}
                      className="inline-flex items-center gap-1 whitespace-nowrap rounded-md border border-border bg-card px-3 py-1.5 text-xs font-medium text-accent hover:bg-secondary"
                    >
                      {row.nextStep}
                      <ChevronRight className="h-3.5 w-3.5" />
                    </Link>
                  </td>
                  <td className="px-6 py-4 align-middle text-center">
                    <Link
                      to="/demand-opportunity/$cluster"
                      params={{ cluster: row.slug }}
                      className="inline-flex h-7 w-7 items-center justify-center rounded-md text-muted-foreground transition-colors hover:bg-secondary hover:text-accent group-hover:text-accent"
                      aria-label={`Open ${row.cluster}`}
                    >
                      <ChevronRight className="h-4 w-4" />
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <HowCalculatedModal open={modalOpen} onClose={() => setModalOpen(false)} />
    </AppShell>
  );
}
