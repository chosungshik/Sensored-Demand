import { createFileRoute, notFound } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { DemandOpportunityPage } from "@/components/DemandOpportunityPage";
import { clusters } from "@/lib/cockpit-data";

export const Route = createFileRoute("/demand-opportunity/$cluster")({
  loader: ({ params }) => {
    const cluster = clusters.find((c) => c.slug === params.cluster);
    if (!cluster) throw notFound();
    return cluster;
  },
  component: ClusterPage,
  notFoundComponent: () => (
    <AppShell>
      <div className="py-20 text-center text-muted-foreground">Cluster not found.</div>
    </AppShell>
  ),
  errorComponent: () => (
    <AppShell>
      <div className="py-20 text-center text-muted-foreground">Something went wrong.</div>
    </AppShell>
  ),
});

function ClusterPage() {
  const c = Route.useLoaderData();
  return (
    <AppShell>
      <DemandOpportunityPage cluster={c} />
    </AppShell>
  );
}