import { createFileRoute } from "@tanstack/react-router";
import { AppShell } from "@/components/AppShell";
import { DemandOpportunityPage } from "@/components/DemandOpportunityPage";
import { clusters } from "@/lib/cockpit-data";

export const Route = createFileRoute("/demand-opportunity")({
  component: () => {
    const ribbed = clusters.find((c) => c.slug === "ribbed-tanks")!;
    return (
      <AppShell>
        <DemandOpportunityPage cluster={ribbed} />
      </AppShell>
    );
  },
});